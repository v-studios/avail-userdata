def app(): # pragma: no cover
    return None

def returns_app(): # pragma: no cover
    return app
