# Copyright (c) 2015 AVAIL Authors. See AUTHORS.txt in the root of the repo.
"""AVAIL User table and helpers."""

import logging

from zope.interface import implementer

from avail.interfaces import IUserDB

log = logging.getLogger(__name__)


class User:
    """A container class for return values from the UserDB."""

    def __init__(self, auid, center, roles):
        """Return a `User`.

        :param str auid: The user's NASA AUID.
        :param str center: The user's NASA center.
        :param list roles: The user's roles in this app.
        """
        # Initialize empty placeholders.
        self._auid = ''
        self._center = ''
        self._roles = []
        # Assign values through property setters.
        self.auid = auid
        self.center = center
        self.roles = roles

    @property
    def auid(self):
        """Return the user's AUID."""
        return self._auid

    @auid.setter
    def auid(self, new_auid):
        """
        Set the user's AUID.

        :param str new_auid: an AUID like 'jsmith' or 'rrabit'.
        """
        if not isinstance(new_auid, str):
            raise TypeError('new_auid must be a str, not a {}'.format(
                type(new_auid)))
        if not new_auid:
            raise ValueError('new_auid cannot be empty.')
        self._auid = new_auid

    @property
    def center(self):
        """Return the user's center."""
        return self._center

    @center.setter
    def center(self, new_center):
        """
        Set the user's center.

        :param str new_center: a center name like 'HQ' or 'JSC'.
        """
        if not isinstance(new_center, str):
            raise TypeError('new_center must be a str, not a {}'.format(
                type(new_center)))
        if not new_center:
            raise ValueError('new_center cannot be empty.')
        self._center = new_center

    @property
    def roles(self):
        """Return the user's roles."""
        return self._roles

    @roles.setter
    def roles(self, new_roles):
        """
        Set the user's roles.

        :param list new_roles: roles like ['group:admin', 'group:IEG'].
        """
        if not isinstance(new_roles, list):
            raise TypeError('new_roles must be a list, not a {}'.format(
                type(new_roles)))
        if not new_roles:
            raise ValueError('new_roles cannot be empty.')
        for i in new_roles:
            if not isinstance(i, str):
                raise TypeError('new_roles must be a list of strings,'
                                ' but found a {} ({})'.format(type(i), i))
        self._roles = new_roles

    def __str__(self):  # pragma: no cover
        """Return a human-readable repr of a User."""
        return '{}(auid={})'.format(self.__class__, self.auid)


@implementer(IUserDB)
class UserDB:
    """An interface for the dynamo User table."""

    def __init__(self, table):
        """
        Return a `UserDB`.

        :param table: A dynamodb table
        :type  table: `boto3.dynamodb.Table`
        """
        self._table = table

    def by_auid(self, auid):
        """
        Query for a User by their AUID.

        Return a `User` if there's a match. Otherwise, return ``None``.

        :param str auid: a user's NASA AUID.
        :raises ValueError: too many results or bad data
        :raises RuntimeError: couldn't query UserDB
        """
        try:
            result = self._table.get_item(Key={'auid': auid})
        except Exception as e:  # What is the real exception type?
            error_msg = 'Exception UserDB.get_item(userid={}): {}'.format(auid, e)
            log.critical(error_msg)
            raise RuntimeError(error_msg)
        if result['ResponseMetadata']['HTTPStatusCode'] != 200:
            error_msg = 'Bad respons UserDB.get_item(userid={}): {}'.format(
                auid, result)
            log.critical(error_msg)
            raise RuntimeError(error_msg)
        item = result.get('Item')
        if not item:
            return None
        try:
            user = User(item.get('auid'), item.get('center'),
                        item.get('roles'))
        except (TypeError, ValueError):
            error_msg = 'User with bad data userid={} center={} roles={}'.format(
                item.get('auid'), item.get('center'), item.get('roles'))
            log.critical(error_msg)
            raise ValueError(error_msg)
        return user
