""" Copyright 2015 AVAIL Authors.

All rights reserved. Use of this source code is governed by a
proprietary license that can be found in the LICENSE file.

``avail.rest`` imports are defined here.
"""

from .base import (METHODS, RESTBaseView, )

__all__ = (METHODS, RESTBaseView, )
