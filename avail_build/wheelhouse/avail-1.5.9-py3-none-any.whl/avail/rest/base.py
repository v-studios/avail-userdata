"""Copyright 2015 AVAIL Authors. See AUTHORS.txt in the root of the repo.

All rights reserved. Use of this source code is governed by a
proprietary license that can be found in the LICENSE file.

``avail.rest`` imports are defined here.
"""

from pyramid.httpexceptions import HTTPMethodNotAllowed
from pyramid.security import (ALL_PERMISSIONS, Allow)

METHODS = ("GET", "PUT", "POST", "DELETE", "HEAD", "PATCH", "OPTIONS")


class RESTBaseView:
    """The base class for AVAIL RestViews.

    :param request: The current ``pyramid.request.Request``.
    :param allowed: A list of allowed HTTP Methods for the endpoint this
                    represents.
    :param http_not_allowed: An HTTP Method Not Allowed ``exception``.
    """

    allowed = None
    http_not_allowed = HTTPMethodNotAllowed

    __acl__ = [
        (Allow, "group:IEG", ("edit", "view", )),
        (Allow, "group:UAT", ("edit", "view", )),
        (Allow, "group:admin", ALL_PERMISSIONS),
    ]

    def __init__(self, request):
        """The class constructor."""
        self.request = request
        self.matchdict = request.matchdict
        if not (
                self.allowed and isinstance(self.allowed, list) or
                isinstance(self.allowed, tuple)):

            raise TypeError("Got {}. Allowed must be list or tuple.".format(
                type(self.allowed)))

    def get(self, *args, **kwargs):
        """Default view for methods of this type.

        This should be overriden by actual implementations.
        """
        return self._method_not_allowed(*args, **kwargs)

    def put(self, *args, **kwargs):
        """Default view for methods of this type.

        This should be overriden by actual implementations.
        """
        return self._method_not_allowed(*args, **kwargs)

    def post(self, *args, **kwargs):
        """Default view for methods of this type.

        This should be overriden by actual implementations.
        """
        return self._method_not_allowed(*args, **kwargs)

    def delete(self, *args, **kwargs):
        """Default view for methods of this type.

        This should be overriden by actual implementations.
        """
        return self._method_not_allowed(*args, **kwargs)

    def head(self, *args, **kwargs):
        """Default view for methods of this type.

        This should be overriden by actual implementations.
        """
        return self._method_not_allowed(*args, **kwargs)

    def patch(self, *args, **kwargs):
        """Default view for methods of this type.

        This should be overriden by actual implementations.
        """
        return self._method_not_allowed(*args, **kwargs)

    def options(self, *args, **kwargs):
        """Default view for methods of this type.

        This should be overriden by actual implementations.
        """
        return self._method_not_allowed(*args, **kwargs)

    def _method_not_allowed(self, detail=None, headers=None, comment=None):
        """Return the provided not_allowed with args.

        These params are to provide to the proxied response via a
        ``pyramid.httpexceptions`` Exception or a JSON helper that provides the
        same interface WRT these arguments.
        :param detail: a plain-text override of the default detail.
        :param headers: a list of (k,v) header pairs.
        :param comment: a plain-text additional information which is usually
        stripped/hidden for end-users.
        """
        hlist = [("Allowed", ",".join(self.allowed))]
        if headers:
            hlist.extend(headers)
        return self.http_not_allowed(detail=detail,
                                     headers=hlist,
                                     comment=comment)
