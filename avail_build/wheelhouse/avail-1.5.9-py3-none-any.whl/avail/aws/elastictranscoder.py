"""AWS ElasticTranscoder implementation module.

Copyright (c) 2015 AVAIL Authors. See AUTHORS.txt in the root of the repo.
"""
import logging
import os.path

from datetime import datetime

import boto3

from botocore.exceptions import ClientError

from pyramid.events import (NewRequest, subscriber, )
from pyramid.exceptions import ConfigurationError

log = logging.getLogger(__name__)

# The same Pipeline is used for both audio and video jobs.
PIPELINE_ID_KEY = 'avail.aws.et.pipeline_id'

# Check the live preset details here:
#  https://console.aws.amazon.com/elastictranscoder/home?region=us-east-1#presets

SCALED_VIDEO_PRESETS = {
    'AVAIL-Scaled-Large1080': {'suffix': '~large.mp4'},
    'AVAIL-Scaled-Large720':  {'suffix': '~large.mp4'},
    'AVAIL-Scaled-Medium':    {'suffix': '~medium.mp4'},
    'AVAIL-Scaled-Small':     {'suffix': '~small.mp4'},
}

# TODO: if we can't use the AnimGIF we should nuke it here (and tests)

MANDATORY_VIDEO_PRESETS = {
    'AVAIL-Mandatory-Preview': {'suffix': '~preview.mp4'},
    'AVAIL-Mandatory-Mobile':  {'suffix': '~mobile.mp4'},
    # 'AVAIL-Mandatory-AnimGIF': {'suffix': '~anim.gif'},
}

SCALED_AUDIO_PRESETS = {
    '~128k.m4a':    {'preset_id': '1351620000001-100130'},  # AAC 128k
    '~64k.m4a':     {'preset_id': '1351620000001-100141'},  # AAC  64k
    '~128k.mp3':    {'preset_id': '1351620000001-300040'},  # MP3 128k
}

VIDEO_EXTENSIONS = ['avi', 'mov', 'mp4', 'mpg', 'mpeg', ]
AUDIO_EXTENSIONS = ['m4a', 'mid', 'mp3', 'mpa', 'wav', ]


class AVAILETPipeline:
    """
    Some syntactic sugar around the boto3 ElasticTranscoder client.

    Makes to make it easy for consumers to submit jobs to a single ET Pipeline.
    """

    def __init__(self, id_, region, client=None):
        """
        Return an instance of this class.

        :param id_: a `str`. The name of the ElasticTranscoder Pipeline
        to upload jobs to. Should usually be grabbed from a settings file by a
        method making one of these.
        :param client: (optional) a `unittest.mock.Mock`. Should only be
        needed for tests. Allows the caller to avoid real trips out to AWS to
        check for an ET Pipeline. (See `id.setter`.) Default: ``None``.
        """
        # init private attrs.
        self._client = None
        self._id = ''
        # set private attrs.
        if client:
            self._client = client
        else:
            self._client = boto3.client('elastictranscoder',
                                        region_name=region)
        self.id = id_

    @property
    def id(self):
        """Return a `str`: the Pipeline's ID."""
        rv = self._id
        return rv

    @id.setter
    def id(self, new_id):
        """
        Update the value of self.id after verifying the pipeline id exists.

        :param new_id: a `str`. The ID of an ET Pipeline.
        :raises ValueError: `new_id` doesn't exist
        :raises RuntimeError: problem reading pipeline
        """
        func_name = '`AVAILETPipeline.id.setter`'
        log.debug('In {}.'.format(func_name))
        # check to see if this pipeline exists.
        try:
            self._client.read_pipeline(Id=new_id)
        except ClientError as e:
            if e.response['Error']['Code'] == 'ResourceNotFoundException':
                error_tmpl = 'pipelineid={} does not exist.'
                error_msg = error_tmpl.format(new_id)
                log.error(error_msg)
                raise ValueError(error_msg)
            else:
                msg = "Could not read pipelineid={}".format(new_id)
                log.error(msg)
                raise RuntimeError(msg)
        log.debug('{} setting `_id` to pipelineid={}.'.format(func_name, new_id))
        self._id = new_id

    def __str__(self):
        """Return a log-friendly representation of this object."""
        rv = ''
        str_tmpl = '`{}` bound to ElasticTranscoder Pipeline ``{}``'
        rv = str_tmpl.format(self.__class__.__name__, self.id)
        return rv

    def _make_input_dict(self, input_key):
        """
        Return an Input `dict` for an ElasticTranscoder Job.

        The return `dict` will be populated with the minimum required
        parameters for an ET Input, as specified in the ET API docs.

        :param input_key: a `str` specifying the relative path to the input
        file in its S3 bucket, e.g., 'videos/foo.mp4'.
        """
        rv = {}
        rv['Key'] = input_key
        rv['FrameRate'] = 'auto'
        rv['Resolution'] = 'auto'
        rv['AspectRatio'] = 'auto'
        rv['Interlaced'] = 'auto'
        rv['Container'] = 'auto'
        return rv

    def _detect_input_type(self, input_key):
        """
        Return 'audio' or 'video', based on file ending of `input_key`.

        Raise a ``ValueError`` if the file ending of `input_key` doesn't match
        one of the values in `AUDIO_EXTENSIONS` or `VIDEO_EXTENSIONS`.

        :param input_key: a `str` specifying the relative path to the input
        file in its S3 bucket, e.g., 'videos/foo.mp4'.
        """
        func_name = '`AVAILETPipeline._detect_input_type`'
        log.debug('In {}.'.format(func_name))
        rv = ''
        fname = input_key.split('/')[-1]
        file_ending = fname.split('.')[-1].lower()
        if file_ending in AUDIO_EXTENSIONS:
            rv = 'audio'
        elif file_ending in VIDEO_EXTENSIONS:
            rv = 'video'
        else:
            error_tmpl = 'Could not decide whether filename={} is audio or video.'
            error_msg = error_tmpl.format(fname)
            log.error(error_msg)
            raise ValueError(error_msg)
        log.debug('{} returning ``{}``.'.format(func_name, rv))
        return rv

    def _make_output_key(self, input_key, suffix):
        """Return a `str` to be used as the Key for an ET Job Output `dict`.

        Derives the output key from input key's filename and the
        size/type suffix and extension from the Preset ID. E.g.::

          OUT/nid~small.jpg

        :param str input_key: s3 input key, e.g., 'videos/foo.mp4'.
        :param preset_id: a `str` specifying the ID of an ET Preset.

        """
        _dirs, fname = os.path.split(input_key)
        name, _ext = os.path.splitext(fname)
        return os.path.join("OUT", name.replace("~orig", "") + suffix)

    def _make_output_dict(self, input_key, preset_id, suffix):
        """Return an Output `dict` for an ElasticTranscoder Job.

        The return `dict` will be populated with the minimum required
        parameters for an ET Output, as specified in the ET API docs.

        If it's a video generate resolution-specific thumbnails for each.  ET
        will generate multiple thumbnails for each resolution with an embedded
        count number, with more thumbs for longer files; in my tests, the first
        has been black, likely due to the first video frame being a black
        signal.

        ET doesn't set predictable values for "{resolution}" based on
        preset, so to give the front-end a hope of finding thumbnails,
        we transform the video output key into a thumbnail key with
        the same in-fix, so "asset~full-hd.mp4" begets
        "asset~1080p_thumb_00001.png"

        :param str input_key: input s3 key path, e.g., 'videos/foo.mp4'.
        :param str preset_id: AWS ID of an ET Preset.
        :param str suffix: output key size suffix like `~large.mp4`
        """
        rv = {}

        rv['Key'] = self._make_output_key(input_key, suffix)  # OUT/nid~small.mp4
        rv['PresetId'] = preset_id
        input_type = self._detect_input_type(input_key)
        if input_type == 'video':
            rv['Rotate'] = 'auto'
            # ET adds .png suffix for our video presets
            path_file, _ext = os.path.splitext(rv['Key'])
            # CAUTION: If you change this pattern you MUST also change
            # avail_pipeline/transcoded to look for the thumb names
            rv["ThumbnailPattern"] = path_file + "_thumb_{count}"
        return rv

    def _make_output_dicts(self, input_key, orig_width, orig_height, orig_fps):
        """Return a `list` of Output `dict`s.

        Output dicts contain Preset ID's, so differ depending on
        whether this is an audio or a video asset.

        For video, we exclude presets which are bigger than the original;
        if both original width and height are smaller than preset, skip it.

        We've created custom video presets for AVAIL per Bryan Walls' direction:
        https://docs.google.com/document/d/1mc_bCPunNyP25Z0yMAWvP7zJO_jw1ofaZplJ5NyVi3s
        Based on input size (either dimention exceeds target) and framerate,
        we generate scaled version from presets AVAIL-Scaled-* per below:
        1. > 1920x1080:                       Small, Medium, Large1080
        2. 1280x720 - 1919x1079 and >= 45fps: Small, Medium, Large720
        3. 1280x720 - 1919x1079 and <  45fps: Small, Medium
        4. 640x480  - 1279x719:               Small
        5. < 640x480: no scaled outputs

        We also output mandatory presets which the UI expects to be there, for
        search preview videos and mobile.

        Example (with ~medium, ~large excluded due to limited size of input)::

          [{'Key': 'OUT/foo~small.mp4',
            'PresetId': '1351620000001-100040',
            'Rotate': 'auto',
            'ThumbnailPattern': 'OUT/foo~small_thumb_{count}'},
           {'Key': 'OUT/foo~preview.mp4',
            'PresetId': '1351620000001-000050',
            'Rotate': 'auto',
            'ThumbnailPattern': 'OUT/foo~preview_thumb_{count}'},
           {'Key': 'OUT/foo~mobile.mp4',
            'PresetId': '1351620000001-000061',
            'Rotate': 'auto',
            'ThumbnailPattern': 'OUT/foo~mobile_thumb_{count}'}]

        :param int input_key: source S3 key path
        :param int orig_width: source video width
        :param int orig_height: source video height
        :param int orig_fps: source video frames per second
        """
        input_type = self._detect_input_type(input_key)
        if input_type == 'audio':
            suffixes = SCALED_AUDIO_PRESETS.keys()
            log.info('inputkey={} audio presets to create: {}'.format(input_key, suffixes))
            return [self._make_output_dict(input_key, SCALED_AUDIO_PRESETS[s]['preset_id'], s)
                    for s in suffixes]

        if input_type == 'video':
            if not (isinstance(orig_width, int) and isinstance(orig_height, int) and
                    isinstance(orig_fps, int)):
                msg = 'Need int for orig_width={} orig_height={} orig_fps={}'.format(
                    orig_width, orig_height, orig_fps)
                log.critical(msg)
                raise ValueError(msg)

            # TODO: cache these on the method? the call takes a few seconds
            res = self._client.list_presets()
            scaled_name_id = {
                p['Name']: p['Id']
                for p in res['Presets'] if p['Name'] in SCALED_VIDEO_PRESETS}
            log.debug('scaled_name_id={}'.format(scaled_name_id))
            mandatory_name_id = {
                p['Name']: p['Id']
                for p in res['Presets'] if p['Name'] in MANDATORY_VIDEO_PRESETS}
            log.debug('mandatory_name_id={}'.format(mandatory_name_id))

            pnames = ()
            if orig_width >= 1920 and orig_height >= 1080:
                pnames = ('AVAIL-Scaled-Small', 'AVAIL-Scaled-Medium', 'AVAIL-Scaled-Large1080')
            elif orig_width >= 1280 and orig_width >= 720 and orig_fps >= 45:
                pnames = ('AVAIL-Scaled-Small', 'AVAIL-Scaled-Medium', 'AVAIL-Scaled-Large720')
            elif orig_width >= 1280 and orig_width >= 720 and orig_fps < 45:
                pnames = ('AVAIL-Scaled-Small', 'AVAIL-Scaled-Medium')
            elif orig_width >= 640 and orig_width >= 480:
                pnames = ('AVAIL-Scaled-Small',)
            log.info('inputkey={} video presets to create: {}'.format(input_key, pnames))

            scaled = [self._make_output_dict(input_key, scaled_name_id[pname],
                                             SCALED_VIDEO_PRESETS[pname]['suffix'])
                      for pname in pnames]
            mandatory = [self._make_output_dict(input_key, mandatory_name_id[pname],
                                                MANDATORY_VIDEO_PRESETS[pname]['suffix'])
                         for pname in MANDATORY_VIDEO_PRESETS]
            return scaled + mandatory

    def _make_output_key_prefix(self, input_key):
        """Return `str` to be prepended to the Key for an transcoded file.

        Derives the output key from the filename in the input key. E.g., for
        'videos/foo/bar.mp4', return 'videos/foo/'

        :param str input_key: s3 input key, e.g., 'videos/foo.mp4'.
        """
        rv = ''
        orig_path_components = input_key.split('/')[:-1]
        rv = '/'.join(orig_path_components) + '/'
        return rv

    def create_job(self, input_key, orig_width=None, orig_height=None, orig_fps=None, **kwargs):
        """
        Return a `dict` representing an ElasticTranscoder Job.

        Essentially a partial wrapping the boto3 ElasticTranscoder client's
        `create_job` method.

        :param input_key: a `str` specifying the relative path to the input
        file in its S3 bucket, e.g., 'videos/foo.mp4'.
        :param int orig_width: original video width, make none smaller than this
        :param int orig_height: original video height, make none smaller than this
        :param int orig_fps: original video frames per second, selects Large720 or Medium

        Note: Any other kwargs that the boto3 ElasticTranscoder Client's
        `create_job` method accepts can be passed in as kwargs and will be
        passed through, overriding the values this method would otherwise
        compute.
        """
        func_name = '`AVAILETPipeline.create_job`'
        log.debug('In {}.'.format(func_name))
        rv = {}
        _kwargs = {}
        # add required args to the kwargs dict.
        _kwargs['PipelineId'] = self.id
        _kwargs['Input'] = self._make_input_dict(input_key)

        # If the caller passed in any Outputs, then don't build the default Outputs.
        # TODO: is this anything more than theoretical? can we nuke it?
        #       I don't see anything using it, does some extransl re-transcoder util?
        if not ('Output' in kwargs or 'Outputs' in kwargs):
            _kwargs['Outputs'] = self._make_output_dicts(input_key,
                                                         orig_width, orig_height, orig_fps)
        # derive the output key prefix from the path in the input key.
        _kwargs['OutputKeyPrefix'] = self._make_output_key_prefix(input_key)
        # update the _kwargs dict w/ any kwargs passed in by the caller.
        _kwargs.update(kwargs)

        # submit the job to ET.
        resp = self._client.create_job(**_kwargs)
        # write ET's response to the info logger.
        job_dict = resp['Job']
        job_id = job_dict['Output']['Id']
        created_millis = job_dict['Timing']['SubmitTimeMillis']
        s = created_millis / 1000.0
        created_str = datetime.fromtimestamp(s).strftime(
            "%Y-%m-%dT%H:%M:%S.%fZ")
        log_tmpl = 'Created ET jobid={} in pipeineid={} at date={}.'
        log_msg = log_tmpl.format(job_id, self.id, created_str)
        log.debug(log_msg)
        # return the job
        rv = job_dict
        log.debug('{} returning ``{}``.'.format(func_name, rv))
        return rv

    def done(self, job_id):
        """Return True, False or raise RuntimeError on job completion status.

        We need to be able to inform the pipeline that an entire job
        (multiple outputs) is completed, not just submitted. Query the
        ET job status and return True if it's 'Completed', raise a
        RuntimeError if it's 'Error' or 'Canceled', and return False
        if anything else ('Submitted', 'Progressing')

        TODO: is it correct to treat 'Canceled' as Error? or should it
        be treated as done?

        :param str job_id: The ET job id
        :rtype: boolean
        :raises ValueError: if ET job is empty or cannot be found
        :raises KeyError: if we can't get status or state is not recognized
        :raises RuntimeError: if ET job has 'Error' status, caller needs this

        """
        if not job_id:
            msg = "No ET job id provided in call to AVAILETPipline.done."
            log.error(msg)
            raise ValueError(msg)
        try:
            job_state = self._client.read_job(Id=job_id)
        except ClientError as e:
            msg = ("Could not get ElasticTranscoder status for"
                   " jobid={} err={}".format(job_id, e))
            log.error(msg)
            raise ValueError(msg)
        try:
            status = job_state['Job']['Status']
        except KeyError as e:
            raise KeyError("Could not find Status key in ET status")
        if status in ('Error', 'Canceled'):
            # pipeine caller should handle and log this status if needed
            msg = "ElasticTranscoder jobid={} is in state={}".format(job_id, status)
            raise RuntimeError(msg)
        if status in ('Complete', ):
            return True
        if status in ('Submitted', 'Progressing'):
            return False
        raise KeyError("ET jobid={} Status={} is not known".format(job_id, status))


def get_et_pipeline_from_settings(settings, client=None):
    """
    Return an `AVAILETPipeline`.

    Construct an `AVAILETPipeline` using the settings in the application's .ini
    file.

    Raise a `ConfigurationError` if no Pipeline ID is found in the .ini file.

    :param settings: A `dict`. Typically gotten from
    ``event.request.registry.settings``.
    :param client: (optional) a `unittest.mock.Mock`. Should only be used for
    passing in a Mock object during testing. Default: ``None``.
    """
    func_name = '`get_et_pipeline_from_settings`'
    log.debug('In {}.'.format(func_name))
    rv = None
    pipeline_id = settings.get(PIPELINE_ID_KEY)
    if not pipeline_id:
        error_tmpl = 'No value for key={} in settings.'
        error_msg = error_tmpl.format(PIPELINE_ID_KEY)
        log.error(error_msg)
        log.debug("{} raising `ConfigurationError`".format(func_name))
        raise ConfigurationError(error_msg)
    region = settings.get("avail.aws.region", "us-east-1")
    rv = AVAILETPipeline(pipeline_id, region, client=client)
    log.debug('{} returning ``{}``.'.format(func_name, rv))
    return rv


@subscriber(NewRequest)
def add_et_pipeline(event):
    """
    Add a .et_pipeline attribute to each new request.

    :param event: A ``pyramid.event.NewRequest``.
    """
    func_name = '`add_et_pipeline`'
    log.debug('In {}.'.format(func_name))
    settings = event.request.registry.settings
    et_pipeline = get_et_pipeline_from_settings(settings)
    setattr(event.request, 'et_pipeline', et_pipeline)
    log_tmpl = '{} added `.et_pipeline` to ``{}``'
    log.debug(log_tmpl.format(func_name, event.request))
