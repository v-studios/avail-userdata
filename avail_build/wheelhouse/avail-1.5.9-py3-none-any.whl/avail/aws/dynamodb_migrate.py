#!/usr/bin/env python3
# Copyright (c) 2019 AVAIL Authors. See AUTHORS.txt in the root of the repo.

"""Migrate old DynamoDB models to new unified version.

Read exported JSON versions of AssetsDB, JobsDB, UsersDB and CloudSearch,
and using new models, populate the unified AvailDB.abs

Read JobsDB before AssetsDB because assets start life as jobs and not all jobs
become assets. We may have to worry about time-ordering the job entries so that
we don't have asset edits overwritten by earlier asset uploads or edits.

In prototyping, we've seen jobs change values from earlier entries, and
likewise with assets. We may have to investigate to ensure we're not populating
with bad/broken data, and determine how to resolve conflicts.

Table index on pk, sk:
pk=AID#aid  sk=NASAID#nasa_id   canonical asset details, GSI sk-data map nasaid->aid
pk=AID#aid  sk=EVENT#dt#state   asset history
pk=AID#aid  sk=SEARCH#cs_id     searchable metadata to feed CloudSearch
pk=AID#aid  sk=HITS#shard       for 'popular', GSI sk-data map shard to updated count
pk=AID#aid  sk=PUBLISHED#shard  for 'recent', GSI sk-data map shard to publish dt
pk=UID#uid  sk=AUID#auid        canonical user details, GSI sk-data map auid->uid

GSIs name format: pk-sk
* uid-state_dt  pk=uid  sk=state_dt  Assets for user by state sorted by time
* uid-dt_state  pk=uid  sk=dt_state  Assets for user sorted by time, with state
* sk-data       pk=sk   sk=data      Multi-use: auid->uid, nasa_id->aid, recent, popular

The GSI sk-data is overloaded to do a number of things. Most obviously it
maps our opaque UUIDs to NASA values for agency user id and nasa asset id:
auid->uid, nasa_id->aid. We also use it for the Popular HITS count and
Recent PUBLISHED dt value. Since the counter's value can NOT be updated if
it's in the pk or sk (e.g., PK=HITS#0 sk=00042#aid), we have to store the
count somewhere it can be updated, the data attribute, which is part of our
GSI sk-data; data is not part of the *table* index, we can update
it. So it looks like:
    pk=AID#aid sk=HITS#shard      data=0004
    pk=AID#aid sk=PUBLISHED#shard data=2019-12-16T10:51:30.000

Notes:
- The `aid` is opaque UUID mapped from nasa_id/asset_id because we cannot trust
  user-supplied values; `uid` is also opaque mapped from owner/auid because
  it might change (e.g., marriage) and we may want to map it from an Agency
  always-unique-no-we're-not-kidding-this-time-really ID we get from ICAM auth.
- The uid-* indexes rely on the cannonical ASSET item maintaining attributes
  named dt_state and state_dt, sync'd with the separate attributes dt and state
"""

import argparse
import hashlib
import json
import logging
import os
import time
from functools import lru_cache

import boto3

MAX_ADD_ASSETS = 9999
MAX_ADD_CLOUDSEARCH = 9999
MAX_ADD_JOBS = 9999
MAX_ADD_USERS = 9999
SHARDS = 5                     # TODO determine on throughput needs
TABLE = None                   # instantiated by get_table() and used as global
TERMINAL_STATES = ('Indexed', 'Error')

for suppress in ('boto3', 'botocore'):
    logging.getLogger(suppress).setLevel(logging.WARNING)
LOG = logging.getLogger(__file__)


###############################################################################
# Utilities

@lru_cache(maxsize=None)
def get_uuid(visible_id):
    """Return an opaque id for a given nasa_id or auid.

    We use an unlimited LRU cache so the same input gives us the same UUID,
    so that when consistently map nasa_id to UUID.

    Since we're going to be overwriting the same real DB in Dev,
    don't just generate uuid.uuid4() -- we need a repeatable one
    based on the input.
    """
    # return uuid.uuid4().hex
    return hashlib.md5(visible_id.encode('utf-8')).hexdigest()


def upsert(key, sets={}, removes=[]):
    """Update/insert item which may already have data, an "upsert", return changes.

    Use expression attribute names and values to avoid DynamoDB reserved words.

    Return old vals of any changed attrs.
    """
    changed = {}
    if sets:
        exps = []
        names = {}
        vals = {}
        for name, val in sets.items():
            exps.append('#' + name + '=:' + name)
            names['#' + name] = name
            vals[':' + name] = val
        exp = 'SET ' + ','.join(exps)
        res = TABLE.update_item(Key=key,
                                UpdateExpression=exp,
                                ExpressionAttributeNames=names,
                                ExpressionAttributeValues=vals,
                                ReturnConsumedCapacity='INDEXES',
                                # NONE, ALL_OLD, ALL_NEW, UPDATED_NEW, UPDATED_OLD
                                ReturnValues='UPDATED_OLD')
        # UPDATED_OLD gives attrs even if value was the same, only return value changes
        attrs = res.get('Attributes', {})
        for name, val in attrs.items():
            if sets[name] != val:
                changed[name] = val
    if removes:
        exps = []
        names = {}
        for name in removes:
            exps.append('#' + name)
            names['#' + name] = name
        exp = 'REMOVE ' + ','.join(exps)
        res = TABLE.update_item(Key=key,
                                UpdateExpression=exp,
                                ExpressionAttributeNames=names,
                                ReturnConsumedCapacity='INDEXES',
                                ReturnValues='UPDATED_OLD')
        removed = res.get('Attributes', {})
        if removed:
            changed['REMOVED'] = removed
    return changed


def upsert_aid_shard_data(aid, shard_prefix, data):
    """Update/insert the data value into a shard calculated from the aid.

    pk=AID#aid sk=PREFIX#shard data=data

    We use a shard number calculated from the aid since we know it, and don't
    want to store data in different shards. The aid is a UUID of 32 hex digits,
    so we can convert to int then mod against the number of shards.

    :param str aid: UUID as 32 hex digits
    :param str shard_prefix: the prefix for the shard
    :param str data: data to store, unchanged
    """
    shard = int(aid, 16) % SHARDS
    changed = upsert(key={'pk': 'AID#' + aid,
                          'sk': shard_prefix + '#' + str(shard)},
                     sets={'data': data})
    return changed


def upsert_aid_shard_hits(aid, hits):
    """Update/insert the data value for the aid's HITS#shard.

    pk=AID#aid sk=HITS#shard data=0000count

    :param str aid: UUID as 32 hex digits
    :param int/str hits: int count, or maybe asset popularity str
    """
    return upsert_aid_shard_data(aid, 'HITS', '%09d' % int(hits))


def upsert_aid_shard_published_dt(aid, dt):
    """Update/insert the dt value for the aid's PUBLISHED#shard.

    pk=AID#aid sk=PUBLISHED#shard data=2019-12-12T16:58.28.000

    :param str aid: UUID as 32 hex digits
    :param str dt: datetime stamp
    """
    return upsert_aid_shard_data(aid, 'PUBLISHED', dt)


###############################################################################
# Add data

def add_assets(assets):
    """Insert multiple items to track this asset.

    We get:
    * assetPrefix
    * captionsPath
    * deletedId
    * jobs: list of str
    * mtime: 2015-12-01T15:37:13.161722 (no timezone spec)
    * nasaId
    * owner
    * popularity: int

    Table:
    pk=AID#aid  sk=NASID#aid
    pk=AID#aid  sk=HITS#shard      GSI-sk:data=000hits
    pk=AID#aid  sk=PUBLISHED#shard GSI-sk:data=dt
    """
    # TODO: Ask CloudSearch about each asset; if it doesn't have any data, then
    # our asset is unfindable so probably should not be added to the DB. This
    # implies we have CS data keyed by nasaid.
    LOG.info('Adding assets=%d max=%d',  len(assets), MAX_ADD_ASSETS)
    for asset in assets[:MAX_ADD_ASSETS]:
        nasa_id = asset['nasaId']
        aid = get_uuid(nasa_id)
        pk = 'AID#' + aid
        sk = 'NASAID#' + nasa_id     # GSI sk-data map nasaId->aid
        key = {'pk': pk, 'sk': sk}
        dt = asset['mtime']
        media = asset['assetPrefix'].split('/')[0]
        popularity = asset['popularity']
        uid = get_uuid(asset['owner'])
        # TODO: Should we only store info that we didn't get from add_jobs?
        # JobDB has the 'fname' that is missing from AssetDB;
        # only 'popularity' and maybe this 'mtime' are uniquely found in AssetDB.
        # TODO: it's redundant to store AID# in 'data', find something else
        item = {
            '_FROM_ASSETS': 'yes',
            'aid': aid,              # should not need
            'auid': asset['owner'],  # same as 'owner' below, pick one
            'data': 'AID#' + aid,    # for GSI sk-data map nasaId->aid need something here
            'hits': popularity,      # int
            'media': media,
            'nasaId': nasa_id,       #
            'state': 'Indexed',      # it's from AssetDB, so we know it's indexed
            'update_dt': dt,         # this should be the same as what we had from jobs
            'uid': uid,
        }
        # For finished assets remove any processing and previous error attrs
        changes = upsert(key=key, sets=item, removes=('deadlettered', 'error', 'processing'))
        if changes:
            LOG.info('add_assets changes=%s', changes)  # TODO determine why dupes changes
        # Sharded PK for Popular and Recent queries.
        # Both live in sk=SHARDTYPE#shard data=value so we can update the value
        # and get sorted results from the GSI sk-data.
        # Caution: need to increment count on download and also update shard.
        if popularity and popularity > 0:
            upsert_aid_shard_hits(aid, popularity)
            # Caution: We'll need to remove this if the asset is ever deleted
        upsert_aid_shard_published_dt(aid, dt)
        # Return the last ids so we have valid values in our get tests.
    return nasa_id, aid, uid


def add_cloudsearch(items):
    """Add asset searchable details from the CloudSearch export.

    Table:
    pk=AID#aid  sk=SEARCH#date_created      fields_and_values...

    Each item has `id` then `fields` which contains:
    * album: list!
    * album_text: don't use, it's for CS matching
    * center
    * date_created
    * description
    * description_508
    * keywords: list of str
    * location
    * media_type
    * nasa_id
    * nasa_id_exact: don't use, it's for CS matching
    * owner
    * photographer
    * secondary_creator
    * title

    Some of these items we should already have from assets and jobs DB, e.g.,
    date_created, media_type, nasa_id, owner.  While it's tempting to remove
    them from sk=AID# or sk=SEARCH# data to avoid having to ensure they're
    synced correctly, it would mean we'd have to merge data from ASSET into
    SEARCH record on each update, so let's keep them separate.

    Of course we could have one SEARCH#attr record for every unique attr, but I
    don't think that's very helpful and probably just clutters the pk+sk.

    Trying to anticipate the most useful attr to use for sk suffix, and
    guessing that the date_created, nasa_id, or media_type might be it; we'll
    pick the data_created to give us something useful. I cannot see a use for
    `data` which has (or may have) a GSI on it, so leave it blank. It's
    tempting to put CloudSearch's `id` there, but that's nothing we'd query
    against, so just store it with the other attrs.

    We expect we'll eventually have a DynamoDB stream which feeds a Lambda that
    updates the Search engine. That Lambda should look for
    sk.startswith('SEARCH#') and only processes matching records.

    Since CloudSearch uses AID# + SEARCH# we don't need upsert() so can use
    batch put_item for speed. However, see dupe issue below.

    CloudSearch returns a couple fields we don't want on an asset, and every
    field is a list, even those it knows are scalars. Remove unwanted and
    scalarize as needed.

    TODO: date_created format "2014-01-05T00:00:00Z" with "Z" and no decimal
    places; I don't believe that will be a problem, though it's slightly
    different than the other dt format we use.

    TODO: In DAT403-R1 Rick Houlihan says it's fastest to store an item as a
    JSON blob. Since we don't need any of these attrs individually (?) for read
    or write, we might as well store as a JSON blob.

    """
    # TODO: ensure that every CS item has a *processed* asset.
    LOG.info('Adding cloudsearch=%d max=%d', len(items), MAX_ADD_CLOUDSEARCH)
    with TABLE.batch_writer() as batch:
        for item in items[:MAX_ADD_CLOUDSEARCH]:
            cs_id = item['id']
            cs_fields = item['fields']
            fields = {'pk': 'AID#' + get_uuid(cs_fields['nasa_id'][0]),
                      'sk': 'SEARCH#' + cs_id}
            for cs_key, cs_val in cs_fields.items():
                if cs_key in ('album_text', 'nasa_id_exact'):
                    continue
                if cs_key in ('album', 'keywords'):  # want lists
                    fields[cs_key] = cs_val
                else:                                # make scalar
                    fields[cs_key] = cs_val[0]
            batch.put_item(Item=fields)


def add_jobs(jobs):
    """Upsert all Job entries, creating events, and adding most asset details.

    We expect this to be called *before* add_assets() since not all jobs
    complete to become assets. We get most of our metadata about the canonical
    asset here, including attrs that are not in the assetDB (fname)

    If the job is in a non-terminal state, we set the 'processing' attr which
    is in a (sparse) GSI with a dt and state, and prefixed if it's in a WAIT
    for user input.

    We get:
    * assetId: I don't believe we have to worry about bullshit chars in nasaIds
    * auid
    * deadlettered: 0, 1; only insert if 1, true, and make str for future reason
    * error: 0, 1: only insert if 1, true, and make str for future reason
    * fname
    * history [[state, dt], ...]
    * incomplete: 0, 1; only insert if 1, true, and make str for future reason
    * job [do we care?]
    * job assetPath: save as jobAssetPath ? how relates to (un)published assets?
    * mediaType
    * mtime
    * state
    * states: [str, str, ...]

    Table:
    pk=AID#aid  sk=AID#aid
    pk=AID#aid  sk=EVENT#dt#state

    Count of states from our availdev DB:
       1     "state": "Published"
      32     "state": "Transcoded"
      54     "state": "Uploaded"
     240     "state": "Uploading"
    1701     "state": "Indexed"

    TODO: Danger: we may get multiple jobs for a single asset: once when
    uploaded and published, then later if its edited. How should we track this?
    There's no guarantee we get jobs back in dt order, so an edit update may
    come before an initial, and we don't want to store the earlier dt and
    event. Do I really have to do a get_item() first and compare timestamps?

    """
    LOG.info('Adding jobs=%d max=%d', len(jobs), MAX_ADD_JOBS)
    proc_pk = ''
    proc_uid = ''
    wait_pk = ''
    wait_uid = ''
    with TABLE.batch_writer() as batch:  # we can't batch upserts but will do put_item
        for job in jobs[:MAX_ADD_JOBS]:
            asset_id = job['assetId']
            aid = get_uuid(asset_id)
            auid = job['userId']
            dt = job['mtime']
            pk = 'AID#' + aid
            sk = 'NASAID#' + asset_id  # for GSI sk-data to map nasaId->aid
            state = job['state']
            uid = get_uuid(auid)
            # TODO: it's redundant to store AID# in 'data', find something else
            asset = {               # canonical asset
                '_FROM_JOBS': 'yes',
                'aid': aid,
                'auid': auid,
                'data': 'AID#' + aid,              # GSI sk-data map nasaId->aid val unimportant
                'dt_state': dt + '#' + state,      # GSI ... dt_state
                'fname': job['fname'],             # not available from AssetDB!
                'job': job['job'],                 # do we care about this?
                'jobAssetPath': job['assetPath'],  # do we care? relates to (un)published path?
                'jobMtime': job['mtime'],          # do we care?, only for unpublished?
                'media': job['mediaType'],
                'nasaId': job['assetId'],          #
                'state': state,
                'state_dt': state + '#' + dt,      # GSI
                'states': job['states'],           # [str, str, ...]
                'uid': uid,
            }

            # Store current booleans only if 1 (true), as str so we can store reason later
            # TODO are these XOR flags? if so make it if... elsif... elsif... fi
            # TODO: if we've got deadlettered, doesn't that imply Error?
            # TODO: I've got aid=834c51a71b8c3cca066197db43bb209d cs3.mp4
            #       with deadlettered=1 but NOT listed as an Error, in fact,
            #       it's state=Indexed, WTFO? See the JobDB JSON. It's not in AssetDB!
            if job['deadlettered']:
                asset['deadlettered'] = 'Deadlettered-after-' + state
                LOG.info('Job deadlettered: aid=%s nasaid=%s state=%s',
                         aid, asset_id, state)
            if job['error']:
                state = 'Error'  # need below for event history
                asset['state'] = 'Error'
                asset['error'] = 'Error-after-' + state
                LOG.info('Job error: aid=%s nasaid=%s state=%s',
                         aid, asset_id, state)
            if job['incomplete']:
                asset['incomplete'] = str(job['incomplete'])
                LOG.info('Job incomplete: aid=%s nasaid=%s state=%s',
                         aid, asset_id, state)

            if state not in TERMINAL_STATES:
                # Non-terminal items are still 'processing', mark them with a dt.
                # Check this only after we've checked for error/dead terminal states.
                # I'm going to treat items waiting for user input specially,
                # prefixin the dt with 'WAIT#' since they're important.  Let's
                # discuss whether this is more valuable than just querying
                # 'processing' then looking for items with state=wait_*.
                if job['incomplete'] != 0:
                    asset['processing'] = 'WAIT#' + dt + '#' + state
                    wait_pk = pk
                    wait_uid = uid
                else:
                    asset['processing'] = dt + '#' + state
                    proc_pk = pk
                    proc_uid = uid
                LOG.info('Job processing: aid=%s nasaid=%s state=%s processing=%s',
                         aid, asset_id, state, asset['processing'])

            changes = upsert(key={'pk': pk, 'sk': sk}, sets=asset)
            if changes:
                LOG.debug('add_jobs changes=%s', changes)  # TODO: examine why dupe data

            # Store history as separate events: state, dt
            # Is it useful to add separate state and dt attrs? add more data, info?
            # If we're in state Error, or are deadlettered, do we record that?
            # In current AVAIL, our 'history' does not include the current state,
            # so we'll add it as an event, which should be the final event.
            # What happens if the job completes then is edited? we'd get multiple
            # Indexed states in events, but that's as it should be.
            batch.put_item(Item={'pk': 'AID#' + aid,
                                 'sk': 'EVENT#' + dt + '#' + state})
            for event in job['history']:
                state = event[0]
                dt = event[1]
                batch.put_item(Item={'pk': 'AID#' + aid,
                                     'sk': 'EVENT#' + dt + '#' + state})
    return aid, state, dt, proc_pk, proc_uid,  wait_pk, wait_uid


def add_users(users):
    """Insert all Users keyed by UUID `uid`, along with their Agency User ID.

    We get:
    * auid
    * center
    * email
    * roles: list of strings

    Table:
    pk=UID#uid  sk=AUID#center  data=uid uid=... center=... email=... roles=[...]

    In future, we may want to track created_dt, updated_dt, lastlogin_dt.
    """
    LOG.info('Adding users=%d max=%d', len(users), MAX_ADD_USERS)
    with TABLE.batch_writer() as batch:
        for user in users[:MAX_ADD_USERS]:
            auid = user['auid']
            center = user['center']
            email = user['email']
            roles = user['roles']
            uid = get_uuid(auid)
            batch.put_item(Item={
                'pk': 'UID#' + uid,
                'sk': 'AUID#' + auid,  # for GSI sk-data to map auid->uid
                'auid': auid,          # Agency user id like `cshenton`
                'center': center,
                'data': uid,           # need something here to fill GSI sk-data
                'email': email,
                'roles': roles,        # list of strings
                'uid': uid,            # opaque user id, duped from pk for convenience
            })
    return uid, auid, center, email, roles  # for testing queries


def main():
    """Parse CLI args, and add content."""
    parser = argparse.ArgumentParser(
        description='Migrate AssetDB, JobDB, UserDB, Cloudsearch JSON to unified table',
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )

    parser.add_argument('-d', '--directory', help='Optional dir to find all JSON files',
                        default='../../../../vstudios/dynamodb_recipes/avail')
    parser.add_argument('-a', '--assets', help='Path to AssetDB JSON file',
                        default='availdev-AssetDB-1BEDI7BNOKS6S.json',
                        )  # required=True)
    parser.add_argument('-j', '--jobs', help='Path to JobDB JSON file',
                        default='availdev-JobStateDB-HXGK79MC2P3P.json',
                        )  # required=True)
    parser.add_argument('-u', '--users', help='Path to UserDB JSON file',
                        default='availdev-UserDB-1K0VJKXNSALON.json',
                        )  # required=True)
    parser.add_argument('-c', '--cloudsearch', help='Path to CloudSearch JSON file',
                        default='availdev-CloudSearch.json',
                        )  # required=True)
    parser.add_argument('-t', '--table', help='Name of extant unified DynamoDB table to write',
                        default='availdev-AvailDB-1AB61TQ1FOKZC',
                        )  # required=True)
    parser.add_argument('-v', '--verbose', help='Path to upload.py program that does the work',
                        default=False, action='store_true')
    # parser.add_argument('--wipe', help='Wipe existing DB data before writing new',
    #                     default=False)  # TODO how would I do this? scan and delete?
    args = parser.parse_args()

    level = logging.INFO
    if args.verbose:
        level = logging.DEBUG
    LOG.setLevel(level)
    logging.basicConfig(level=level)  # why do I have do it twice?

    global TABLE
    TABLE = boto3.resource('dynamodb').Table(args.table)
    print('table=%s state=%s' % (args.table, TABLE.table_status))

    # Open all the JSON files so we don't get partway through then fail
    # For Prod, this may be too large; worry about it then if need be.
    assets = json.loads(open(os.path.join(args.directory, args.assets)).read())
    jobs = json.loads(open(os.path.join(args.directory, args.jobs)).read())
    users = json.loads(open(os.path.join(args.directory, args.users)).read())
    cloudsearch = json.loads(open(os.path.join(args.directory, args.cloudsearch)).read())

    t_0 = time.time()
    add_users(users)
    t_users = time.time()
    add_jobs(jobs)
    t_jobs = time.time()
    add_assets(assets)
    t_assets = time.time()
    add_cloudsearch(cloudsearch)
    t_cloudsearch = time.time()
    LOG.info('Times: users=%.0fs jobs=%.0fs assets=%.0fs cloudsearch=%.0fs',
             t_users - t_0, t_jobs - t_users, t_assets - t_jobs, t_cloudsearch - t_assets)


if __name__ == '__main__':
    main()
