#!/usr/bin/env python3
"""AWS HealthCheck implementation module.

Copyright (c) 2018 - 2019 AVAIL Authors. See AUTHORS.txt in the root of the repo.
"""

import configparser
import json
import logging
import resource
import subprocess
import sys

import boto3

from botocore.client import ClientError

# Send logs to console, and set level to DEBUG when run on cli
log = logging.getLogger('HealthCheck')
log.setLevel(logging.DEBUG)

# Add console handler for logs, and set log level to DEBUG on console
console_handler = logging.StreamHandler()
console_handler.setFormatter(logging.Formatter('%(name)s - %(levelname)s - %(message)s'))
log.addHandler(console_handler)


def check_service(service, config_file, avail_service_name):
    """Check status of AWS or AVAIL services on an AVAIL instance.

    :param service: A listed AWS or avail service defined in the AVAIL ini file.
    :param config_file: full fs path to the AVAIL ini file.
    :param avail_service_name: name of supervisor service to check the status of.
    """
    # Read configuration file
    config = configparser.RawConfigParser()
    config.optionxform = lambda option: option
    config.read(config_file)

    region = config['app:main']['avail.aws.region']

    if service == 'sqs':
        sqs_queue_name = config['app:main']['avail_pipeline.queue_name']
        log.debug('Healthcheck got sqs queue name : {}'.format(sqs_queue_name))

        sqs = boto3.client('sqs', region_name=region)
        sqs_connectivity_result = False

        try:
            sqs_connectivity_result = sqs.get_queue_url(QueueName=sqs_queue_name)
        except ClientError:
            log.error('Healthcheck for SQS Queue Failed')
            return(1)
        else:
            log.debug('Healthcheck sqs connectivity result says QueueUrl is : {}'
                      .format(sqs_connectivity_result['QueueUrl']))
            log.info('SQS Queue Check OK')
            return(0)

    if service == 'dynamodb':
        dynamodb_table_name = config['app:main']['avail.aws.dynamodb.userdb.table_name']
        log.debug('Healthcheck got DynamoDB table name : {}'.format(dynamodb_table_name))

        dynamodb = boto3.client('dynamodb', region_name=region)
        dynamodb_connectivity_result = False

        try:
            dynamodb_connectivity_result = dynamodb.describe_table(
                TableName=dynamodb_table_name
            )
        except ClientError:
            log.error('Healthcheck for DynamoDB Failed')
            return(1)
        else:
            log.debug('dynamodb connectivity result says TableStatus is : {}'
                      .format(dynamodb_connectivity_result['Table']['TableStatus']))
            log.info('DynamoDB Table Check OK')
            return(0)

    elif service == 'et':

        et_pipeline_name = config['app:main']['avail.aws.et.pipeline_id']
        log.debug('Healthcheck got et pipeline id : {}'.format(et_pipeline_name))

        et = boto3.client('elastictranscoder', region_name=region)
        et_connectivity_result = False

        try:
            et_connectivity_result = et.read_pipeline(Id=et_pipeline_name)
        except ClientError:
            log.error('Healthcheck for ET Pipeline Failed')
            return(1)
        else:
            log.debug('et connectivity result says PipelineStatus is : {}'
                      .format(et_connectivity_result['Pipeline']['Status']))
            log.info('ET Pipeline Check OK')
            return(0)

    elif service == 's3':
        s3_bucket_name = config['app:main']['avail.aws.s3.tmp.bucket.name']
        log.debug('Healthcheck got S3 bucket name : {}'
                  .format(s3_bucket_name))

        s3 = boto3.client('s3', region_name=region)
        s3_connectivity_result = False

        try:
            s3_connectivity_result = s3.get_bucket_location(Bucket=s3_bucket_name)
        except ClientError:
            log.error('Healthcheck for S3 Failed')
            return(1)
        else:
            if s3_connectivity_result['ResponseMetadata']['HTTPStatusCode'] == 200:
                log.info('S3 Bucket Check OK for bucket=%s', s3_bucket_name)
                return(0)
            else:
                log.error('S3 bucket location check result: %s' % s3_connectivity_result)
                return(1)

    elif service == 'avail':
        cmd = ['supervisorctl', 'status', avail_service_name]
        if __name__ == "__main__":
            cmd = ['echo', 'RUNNING']
        try:
            out = subprocess.check_output(cmd)
        except Exception as err:  # saw: OSError: [Errno 12] Cannot allocate memory
            log.error('AVAIL supervisorctl failed with Exception: %s', err)
            return(10)
        if b'RUNNING' in out:
            log.info('AVAIL supervisorctl Check OK')
            return(0)
        log.error('AVAIL supervisorctl check failed: %s', out)
        return(-100)

    elif service == 'memory':
        # Does this tell us anything useful, or only this healthcheck script?
        # We really want to know our parent (uwsgi) and grandparent (nginx)
        # Don't return failures on any of these checks: learn first, kill later.
        log.debug('healthcheck memory maxrss self=%s children=%s',
                  resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                  resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss)
        cmd = ['free', '--human', '--mega']
        try:
            out = subprocess.check_output(cmd)
        except Exception as err:
            log.error('AVAIL subprocess failed command="%s" with  Exception: %s', cmd, err)
        else:
            log.debug('healthcheck memory free MB: %s', out.decode('utf-8'))
        cmd = ['vmstat', '--active', '--unit', 'M']
        try:
            out = subprocess.check_output(cmd)
        except Exception as err:
            log.error('AVAIL subprocess failed command="%s" with  Exception: %s', cmd, err)
        else:
            log.debug('healthcheck memory vmstat MB: %s', out.decode('utf-8'))
        # We don't have any test for memory problems yet, so just return success
        return 0

    else:
        log.error('healthcheck got unrecognized service="%s"', service)
        # Don't mark it as an healthcheck error (-100), it'd take the instance out of ELB
        return 0


def application(env, start_response, services, config_file, avail_service_name):
    """function invoked indirectly by uWSGI worker.

    Takes additional args which define the services to check.
    :param env: sets which avail op_env we're for expansion of the ini file name.
    :param start_response: var passed in by uWSGI for HTTP return code.
    :param services: A listed AWS or avail service defined in the AVAIL ini file.
    :param config_file: full fs path to the AVAIL ini file.
    :param avail_service_name: name of supervisor service to check the status of.
    """
    log = logging.getLogger(__name__)

    healthcheck_result = {}
    service_sum = 0
    service_result_sum = 0

    for service in services:
        service_sum = service_sum + 1
        healthcheck_result[service] = check_service(service, config_file, avail_service_name)

        log.debug('Healthcheck {} result is : {}'.format(service, healthcheck_result[service]))

    for service_name, service_result in healthcheck_result.items():
        service_result_sum = service_result_sum + service_result

    # Healthcheck results evaluation logic :
    # set AWS service errors to return 1, and AVAIL service errors to return 10
    # if we cannot determine status of AVAIL services return -100
    #
    # take the sum of all return values as service_result_sum
    # if service_result_sum is == 1, then all services are ok
    #   (return HTTP/200)
    # if service_result_sum is between 1 and 10, then we saw some error in AWS services
    #   (return HTTP/504)
    # so if service_result is >= 10, then we saw some error in AVAIL service errors
    #   (return HTTP/503)
    # if service_result_sum is < 1, then we could not determine status of AVAIL services
    #   (return HTTP/500)

    if service_result_sum > 0:
        if service_result_sum == 1:
            healthcheck_result["mesg"] = "Healthcheck detected error in a single AWS service"
            start_response('200 OK', [('Content-Type', 'application/json')])
        elif service_result_sum < 10:
            healthcheck_result["mesg"] = "Healthcheck detected error in multiple AWS services"
            start_response('504 Gateway Timeout', [('Content-Type', 'application/json')])
        else:
            healthcheck_result["mesg"] = "Healthcheck detected error in AVAIL services"
            start_response('503 Service Unavailable', [('Content-Type', 'application/json')])
    elif service_result_sum == 0:
        # if service_result_sum is 0, then we saw no errors
        healthcheck_result["mesg"] = "Healthcheck detected all services OK"
        start_response('200 OK', [('Content-Type', 'application/json')])
    else:
        # service_result_sum must be < 0 here, so give alternate 500 error
        healthcheck_result["mesg"] = "Error running Healthcheck"
        start_response('500 Internal Server Error', [('Content-Type', 'application/json')])

    http_body = json.dumps(healthcheck_result) + "\n"
    return http_body.encode("utf-8")


if __name__ == "__main__":
    # We can test this locally by copying the .ini file from pipeline here, then:
    #   ./healthcheck.py s3 dynamodb avail memory
    config_file = './uploaded-dev.ini'
    avail_service_name = 'avail_pipeline-uploaded'

    healthcheck_result = {}

    services = sys.argv[1:]
    env = 'uwsgi'
    start_response = 'http'

    for service in services:
        healthcheck_result[service] = check_service(service, config_file, avail_service_name)
        log.info('Healthcheck {} result is : {}'.format(service, healthcheck_result[service]))
