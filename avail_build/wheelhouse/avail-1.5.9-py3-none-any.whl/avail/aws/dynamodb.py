"""AWS DynamoDB implementation module.

Copyright (c) 2015 AVAIL Authors. See AUTHORS.txt in the root of the repo.
"""

import boto3

from botocore.client import ClientError

from pyramid.events import (NewRequest, subscriber, )
from pyramid.exceptions import ConfigurationError

from avail.asset import AssetDB
from avail.interfaces import (IAssetDB, IJobDB, IUserDB)
from avail.job import JobDB
from avail.user import UserDB


def get_assetdb(registry):
    """Get the asset table from the registry.

    :param registry: The `pyramid.registry.Registry`
    :type registry: `pyramid.registry.Registry`
    """
    return registry.getUtility(IAssetDB)


@subscriber(NewRequest)
def add_assetdb(event):
    """Add a handle to the Dynamo Asset table.

    :param event: A ``pyramid.event.NewRequest``.
    """
    event.request.assets = get_assetdb(event.request.registry)


def get_assetdb_table_from_settings(registry, asset_table=None):
    """
    Return connection to the AssetDB table.

    :param settings: A ``dict``. Typically gotten from
    ``event.request.registry.settings``.
    """
    settings = registry.settings
    region, table_name = (settings.get("avail.aws.region", "us-east-1"),
                          settings.get("avail.aws.dynamodb.assetdb.table_name",
                                       None))

    if table_name is None:
        raise ConfigurationError(
            "avail.aws.dynamodb.assetdb.table_name must be in settings.")
    if asset_table is None:  # pragma: no cover
        asset_table = boto3.resource("dynamodb",
                                     region_name=region).Table(table_name)
    try:
        assert asset_table.table_status == "ACTIVE"
    except ClientError as e:  # pragma: no cover
        # This cannot be tested unless we are using a real boto resource which
        # wants creds.
        raise RuntimeError(
            "There is a problem with the asset_table table {}: {}"
            .format(table_name, e))
    except AssertionError as e:
        raise RuntimeError(
            "The asset table needs to be 'ACTIVE', but it is: {}".format(
                asset_table.table_status))

    return AssetDB(asset_table)


def register_assets(config, asset_table=None):
    """Directive to load AssetDB into the registry.

    :type config: dict
    :param config: The deployment settings.
    :type asset_table: A ``boto3.dynamodb.Table`` of the asset_table variety i
        or a dummy for testing.
    :param asset_table: This is for testing.
    """
    try:
        assets = get_assetdb_table_from_settings(config.registry,
                                                 asset_table=asset_table)
    except ConfigurationError as e:
        raise e
    config.registry.registerUtility(assets, IAssetDB)
    return assets


def get_jobdb(registry):
    """Get the job table from the registry.

    :param registry: The `pyramid.registry.Registry`
    :type registry: `pyramid.registry.Registry`
    """
    return registry.getUtility(IJobDB)


@subscriber(NewRequest)
def add_jobdb(event):
    """Add a handle to the Dynamo Job table.

    :param event: A ``pyramid.event.NewRequest``.
    """
    event.request.jobs = get_jobdb(event.request.registry)


def get_jobdb_table_from_settings(registry, job_table=None):
    """
    Return connection to the JobDB table.

    :param settings: A ``dict``. Typically gotten from
    ``event.request.registry.settings``.
    """
    settings = registry.settings
    region, table_name = (settings.get("avail.aws.region", "us-east-1"),
                          settings.get("avail.aws.dynamodb.jobdb.table_name",
                                       None))

    if table_name is None:
        raise ConfigurationError(
            "avail.aws.dynamodb.jobdb.table_name must be in settings.")
    if job_table is None:  # pragma: no cover
        job_table = boto3.resource("dynamodb",
                                   region_name=region).Table(table_name)
    try:
        assert job_table.table_status == "ACTIVE"
    except ClientError as e:  # pragma: no cover
        # This cannot be tested unless w eare using a real boto resource which
        # wants creds.
        raise RuntimeError("There is a problem with the job_table table {}: {}"
                           .format(table_name, e))
    except AssertionError as e:
        raise RuntimeError(
            "The job table needs to be 'ACTIVE', but it is: {}".format(
                job_table.table_status))

    return JobDB(job_table)


def register_jobs(config, job_table=None):
    """Directive to load JobDB into the registry.

    :type config: dict
    :param config: The deployment settings.
    :type job_table: A ``boto3.dynamodb.Table`` of the job_table variety or
        a dummy for testing.
    :param job_table: This is for testing.
    """
    try:
        jobs = get_jobdb_table_from_settings(config.registry,
                                             job_table=job_table)
    except ConfigurationError as e:
        raise e
    config.registry.registerUtility(jobs, IJobDB)
    return jobs


def get_userdb(registry):
    """Get the user table from the registry.

    :param registry: The `pyramid.registry.Registry`
    :type registry: `pyramid.registry.Registry`
    """
    return registry.getUtility(IUserDB)


@subscriber(NewRequest)
def add_userdb(event):
    """Add a handle to the Dynamo User table.

    :param event: A ``pyramid.event.NewRequest``.
    """
    event.request.users = get_userdb(event.request.registry)


def get_userdb_table_from_settings(registry, user_table=None):
    """
    Return connection to the UserDB table.

    :param dict settings: Typically gotten from
    ``event.request.registry.settings``.
    """
    settings = registry.settings
    region = settings.get("avail.aws.region", "us-east-1")
    table_name = settings.get("avail.aws.dynamodb.userdb.table_name", None)

    if table_name is None:
        raise ConfigurationError(
            "avail.aws.dynamodb.userdb.table_name must be in settings.")
    if user_table is None:  # pragma: no cover
        user_table = boto3.resource("dynamodb",
                                    region_name=region).Table(table_name)
    try:
        assert user_table.table_status == "ACTIVE"
    except ClientError as e:  # pragma: no cover
        # This cannot be tested unless we are using a real boto resource which
        # wants creds.
        raise RuntimeError(
            "There is a problem with the user_table table {}: {}"
            .format(table_name, e))
    except AssertionError as e:
        raise RuntimeError(
            "The user table needs to be 'ACTIVE', but it is: {}".format(
                user_table.table_status))

    return UserDB(user_table)


def register_users(config, user_table=None):
    """Directive to load UserDB into the registry.

    :param dict config: The deployment settings.
    :type user_table: A ``boto3.dynamodb.Table`` of the user_table variety
        or a dummy for testing.
    :param user_table: This is for testing.
    """
    try:
        users = get_userdb_table_from_settings(config.registry,
                                               user_table=user_table)
    except ConfigurationError as e:
        raise e
    config.registry.registerUtility(users, IUserDB)
    return users
