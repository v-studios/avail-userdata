"""AWS SQS implementation module.

Copyright (c) 2015 AVAIL Authors. See AUTHORS.txt in the root of the repo.
"""

import boto3

from pyramid.exceptions import ConfigurationError

from avail.interfaces import (IPublishedQueue, ITranscodedQueue)

# TODO: it would be great for us to have an ordered list of SQS queues
# elsewhere, but this will do for now.
# we only want the first (upload) queue plus the error queue on each new
# request.

NEW_REQUEST_SQS_QUEUES = ['UploadedQueue', 'ErrorQueue']
SETTINGS_PREFIX = "avail.aws.sqs.queues."


def _get_queues_from_settings(settings):
    """Return dict of logical : AWS names for queues from ini data.

    We expect the .ini file will be in the pyramid format like::

    [app:main]
    # ... other settings here ...
    avail.aws.sqs.queues.UploadedQueue = avail-integ-uploaded
    avail.aws.sqs.queues.ErrorQueue    = avail-integ-errored

    :param dict settings: as configparser returns given an .ini file
    :returns: `dict` of SQS logical name and AWS physical name
    """
    queues = {}
    for k, v in settings.items():
        if k.startswith(SETTINGS_PREFIX):
            queues[k.replace(SETTINGS_PREFIX, "")] = v
    return queues


def add_sqs_queues(event):
    """Add dot attributes for NEW_REQUEST_SQS_QUEUES to each new request.

    :param event: A ``pyramid.event.NewRequest``.
    """
    settings = event.request.registry.settings
    settings_queues = _get_queues_from_settings(settings)
    for queue in NEW_REQUEST_SQS_QUEUES:
        try:
            queue_name = settings_queues[queue]
        except KeyError:
            raise KeyError("Could not get ini setting {}{}".format(
                SETTINGS_PREFIX, queue))
        sqs_queue = get_named_queue_from_settings(queue_name, settings)
        setattr(event.request, queue, sqs_queue)


# TODO: Unify these as a register_named_queue function.
def register_published_queue(config, sqs=None):
    # TODO: Write tests for this.
    """Register the published queue in the registry.

    We now need to put items in the queue. As of this writing only in the
    metadata PUT view.

    :type config: `pyramid.config.Configurator`
    :param config: The deployment settings.
    :type sqs: A ``boto3.resource`` of the sqs variety or a dummy for testing.
    :param sqs: This is for testing.
    """
    # TODO: Move this config from settings stuff to the from settings method
    qname = config.registry.settings.get("avail.aws.sqs.published")
    if qname is None:
        raise ConfigurationError(
            "'avail.aws.sqs.published' must be in the configuration file")
    try:
        queue = get_named_queue_from_settings(qname, config.registry.settings,
                                              sqs_resource=sqs)
    except ConfigurationError as e:
        raise e
    config.registry.registerUtility(queue, IPublishedQueue)
    return queue


def register_transcoded_queue(config, sqs=None):
    # TODO: Write tests for this.
    """Register the transcoded queue in the registry.

    We now need to put items in the queue. As of this writing only in the
    metadata PUT view.

    :type config: `pyramid.config.Configurator`
    :param config: The deployment settings.
    :type sqs: A ``boto3.resource`` of the sqs variety or a dummy for testing.
    :param sqs: This is for testing.
    """
    # TODO: Move this config from settings stuff to the from settings method
    qname = config.registry.settings.get("avail.aws.sqs.transcoded")
    if qname is None:
        raise ConfigurationError(
            "'avail.aws.sqs.transcoded' must be in the configuration file")
    try:
        queue = get_named_queue_from_settings(qname, config.registry.settings,
                                              sqs_resource=sqs)
    except ConfigurationError as e:
        raise e
    config.registry.registerUtility(queue, ITranscodedQueue)
    return queue


def get_named_queue_from_settings(name, settings, sqs_resource=None):
    """
    Return a boto3 sqs.Queue.

    Get an SQS queue by name, using the application settings dict to find AWS
    config.

    :param name: A ``string``. Should be suitable for use with boto3 as a
    QueueName.
    :param settings: A ``dict``. Typically gotten from
    ``event.request.registry.settings``.
    :param sqs_resource: (optional) A placeholder kwarg for a
    ``unittesting.Mock`` in unit tests. Default: ``None``.
    """
    region = settings.get("avail.aws.region", "us-east-1")
    if sqs_resource is None:  # pragma: no cover
        sqs_resource = boto3.resource("sqs", region_name=region)
    queue = sqs_resource.get_queue_by_name(QueueName=name)
    return queue
