"""Copyright 2015 AVAIL Authors.

All rights reserved. Use of this source code is governed by a
proprietary license that can be found in the LICENSE file.

``avail.aws`` imports are defined here.
"""

#  yapf: disable

from .cloudsearch import get_cloudsearch_from_settings

from .dynamodb import (
    add_assetdb,
    add_jobdb,
    add_userdb,
    get_assetdb_table_from_settings,
    get_jobdb_table_from_settings,
    get_userdb_table_from_settings,
    register_assets,
    register_jobs,
    register_users,
)

from .elastictranscoder import (
    AVAILETPipeline,
    add_et_pipeline,
    get_et_pipeline_from_settings,
)

from .s3 import (
    S3FileStore,
    S3TmpFileStore,
    add_fs,
    add_tmpfs,
    fs_from_settings,
    get_fs,
    get_tmpfs,
    register_fs,
    register_tmpfs,
    tmpfs_from_settings
)

from .sqs import (
    get_named_queue_from_settings,
    register_published_queue,
    register_transcoded_queue
)

__all__ = (
    "AVAILETPipeline",
    "S3FileStore",
    "S3TmpFileStore",
    "add_assetdb",
    "add_et_pipeline",
    "add_fs",
    "add_jobdb",
    "add_tmpfs",
    "add_userdb",
    "fs_from_settings",
    "get_assetdb_table_from_settings",
    "get_cloudsearch_from_settings",
    "get_et_pipeline_from_settings",
    "get_fs",
    "get_jobdb_table_from_settings",
    "get_named_queue_from_settings",
    "get_userdb_table_from_settings",
    "get_tmpfs",
    "register_assets",
    "register_fs",
    "register_jobs",
    "register_published_queue",
    "register_tmpfs",
    "register_users",
    "register_transcoded_queue",
    "tmpfs_from_settings",
)

#  yapf: enable
