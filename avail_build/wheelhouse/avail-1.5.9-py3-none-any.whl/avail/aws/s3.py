"""AWS S3 implementation module.

Copyright (c) 2015 AVAIL Authors. See AUTHORS.txt in the root of the repo.
"""
import logging
import os

from functools import partial
from mimetypes import guess_type

import boto3

from botocore.client import ClientError

from pyramid.events import subscriber
from pyramid.exceptions import ConfigurationError
from pyramid.interfaces import INewRequest

from zope.interface import implementer

# TODO: Move these constants somewhere more central so both this module and
# 'elastictranscoder' can import them. Same for `IMAGE_EXTENSIONS`, below.
from avail.aws.elastictranscoder import (AUDIO_EXTENSIONS, VIDEO_EXTENSIONS, )
from avail.interfaces import IObjectStore
from avail.interfaces import ITempObjectStore

IMAGE_EXTENSIONS = ['jpg', 'jpeg', 'tiff', 'tif', 'png', ]
CHUNK_SIZE = 4194304
log = logging.getLogger(__name__)


def get_fs(registry):
    """Get a file (object) store from the registry.

    :param  registry: A ``pyramid.registry.Registry``.
    """
    return registry.getUtility(IObjectStore)


def get_tmpfs(registry):
    """Get a temporary file (object) store from the registry.

    :param registry: A ``pyramid.registry.Registry``.
    """
    return registry.getUtility(ITempObjectStore)


@subscriber(INewRequest)
def add_fs(event):
    """Add the fs to the new request.

    :param event: A ``pyramid.event.INewRequest``
    """
    event.request.fs = get_fs(event.request.registry)


@subscriber(INewRequest)
def add_tmpfs(event):
    """Add the tempfs to the new request.

    :param event: A ``pyramid.event.INewRequest``
    """
    event.request.tmpfs = get_tmpfs(event.request.registry)


def fs_from_settings(registry, s3=None):
    """Get an fs object from the application settings.

    :param registry: A ``pyramid.registry.Registry``.
    """
    settings = registry.settings
    region, prod = (settings.get("avail.aws.region", "us-east-1"),
                    settings.get("avail.aws.s3.prod.bucket.name", None), )
    if prod is None:
        raise ConfigurationError(
            "avail.aws.s3.prod.bucket.name must be in settings.")
    if s3 is None:  # pragma: no cover
        s3 = boto3.resource("s3", region_name=region)
    try:
        s3.meta.client.head_bucket(Bucket=prod)
    except ClientError:
        raise ConfigurationError(
            "The production bucket does not exist, please create it and try"
            " again.")

    fs = S3FileStore(s3.Bucket(prod))
    return fs


def tmpfs_from_settings(registry, s3=None):
    """Get a tmpfs object from the application settings.

    :param registry: A ``pyramid.registry.Registry``.
    :param s3: This is for passing in a dummy when testing.
    """
    settings = registry.settings
    region, tmp = (settings.get("avail.aws.region", "us-east-1"),
                   settings.get("avail.aws.s3.tmp.bucket.name", None), )
    if tmp is None:
        raise ConfigurationError(
            "avail.aws.s3.tmp.bucket.name must be in settings.")
    if s3 is None:  # pragma: no cover
        s3 = boto3.resource("s3", region_name=region)
    try:
        s3.meta.client.head_bucket(Bucket=tmp)
    except ClientError:
        raise ConfigurationError(
            "The tmp bucket does not exist, please create it and try again")

    tmpfs = S3FileStore(s3.Bucket(tmp))
    return tmpfs


def register_fs(config, s3=None):
    """Directive to load the S3FileStore into the registry.

    :type config: dict
    :param config: The deployment settings.
    :type s3: A ``boto3.resource`` of the s3 variety or a dummy for testing.
    :param s3: This is for testing.
    """
    try:
        fs = fs_from_settings(config.registry, s3=s3)
    except ConfigurationError as e:
        raise e
    config.registry.registerUtility(fs, IObjectStore)
    return fs


def register_tmpfs(config, s3=None):
    """Directive to load the S3FileStore into the registry.

    :type config: dict
    :param config: The deployment settings.
    :type s3: A ``boto3.resource`` of the s3 variety or a dummy for testing.
    :param s3: This is for testing.
    """
    try:
        tmpfs = tmpfs_from_settings(config.registry, s3=s3)
    except ConfigurationError as e:
        raise e
    config.registry.registerUtility(tmpfs, ITempObjectStore)
    return tmpfs


@implementer(ITempObjectStore)
class S3TmpFileStore:
    """A :term:`object store` implementation.

    This provides an API for working with file objects in an :term:`object
    store`, specifically :term:`S3`.
    """

    # acl = "bucket-owner-full-control"
    acl = "private"

    def __init__(self, bucket):
        """Class intitializer."""
        self.bucket = bucket

    def get(self, key, iterable=False):
        """Get a file from production :term:`S3` :term:`bucket`.

        :param key: The object store key to fetch as a string.

        Returns a string, iterator tuple.
        """
        fname = os.path.basename(key)
        try:
            body = self.bucket.Object(key).get()["Body"]
        except ClientError as e:
            if e.response["Error"]["Code"] == "NoSuchKey":  # pramga: no cover
                raise KeyError("No such object {}: {}.".format(key, e))
            else:
                raise e
        return fname, iterbody(body) if iterable else body

    def put(self, key, fh,
            content_type=None,
            content_md5=None,
            content_length=None,
            metadata={},
            cache_control=''):
        """Put a file into the production :term:`S3` :term:`bucket`.

        :type key: string
        :param key: The key under which to store this object.
        :type fh: file handle
        :param fh: A file handle to the object content which is to be put into
            the object store.
        :type content_length: int
        :param content_length: The length of the content to be uploaded. Not
            always necessary.
        :type content_md5: string
        :param content_md5: A base64 encoded md5sum to validate the upload
            against.
        :type content_type: string
        :param content_type: The content type of the object. Will guess by
            extension if not provided.
        :type Metdata: dict
        :param Metdata: A dict with metadata relevant to the key to add to S3.
        :param str cache_control: A string to set on this object in S3 for cache behavior, e.g.,
        "public, max-age=300, s-maxage=600".

        Returns the key of the uploaded file.
        """
        kwargs = {}
        kwargs["ACL"] = self.acl
        kwargs["Body"] = fh
        if cache_control:
            kwargs["CacheControl"] = cache_control
        if metadata:
            kwargs["Metadata"] = metadata
        if content_type is None:
            content_type, encoding = guess_type(key)
            if content_type is None:
                content_type = ""
        kwargs["ContentType"] = content_type
        if content_md5 is not None:
            kwargs["ContentMD5"] = content_md5
        if content_length is not None:
            kwargs["ContentLength"] = content_length

        resp = self.bucket.Object(key).put(**kwargs)

        return resp

    def delete(self, key, prefix=""):
        """
        Delete objects from the file store.

        Return associated with the delete call(s).

        :type key: string
        :param key: The key of the object that is to be deleted.
        :param prefix: (optional) a `str` to use for the Prefix argument in S3
        calls. Functionally like a dir, only not a real one because there are
        no directories in S3. If prefix is specified, the key is ignored.
        :rtype: `dict` or `list` of `dicts`.
        """
        # If there's no prefix, then do a simple delete call for one key.
        if not prefix:
            resp = self.bucket.Object(key).delete()
            return resp
        # If there is a prefix, build a list of keys and then issue deletes for
        # each of them.
        responses = []
        objs = self.bucket.meta.client.list_objects(Bucket=self.bucket.name,
                                                    Prefix=prefix)
        keys = [obj["Key"] for obj in objs.get("Contents", [])]
        log.debug("Deleting {} keys with prefix={}".format(len(keys), prefix))
        for n, key in enumerate(keys, 1):
            log.debug("Deleting key #{}: key={}".format(n, key))
            responses.append(self.bucket.Object(key).delete())
        return responses

    def head(self, key):
        """Head the object in the file store at ``key``.

        :type key: string
        :param key: The key of the object we want to head.

        returns TODO: ??? prolly metadata
        """
        try:
            resp = self.bucket.meta.client.head_object(Bucket=self.bucket.name,
                                                       Key=key)
        except ClientError as e:
            if e.response["Error"]["Code"] == "404":  # pramga: no cover
                raise KeyError("No such object {}: {}.".format(key, e))
            else:
                raise e

        return resp

    def start_multipart(self,
                        content_type=None,
                        content_md5=None,
                        metadata={}):
        """Initiate a multipart upload.

        TODO: Complete this implementation.
        """
        raise NotImplementedError("Not done yet.")

    def put_multipart(self, key, fh, mpu_id):
        """Put a file into the production :term:`S3` :term:`bucket`.

        This differs from a regular put in that it performs a multipart upload.

        :type key: string
        :param key: The key under which to store this object.
        :type fh: file handle
        :param fh: A file handle to the object content which is to be put into
            the object store.
        :type mpu_id: string
        :param mpu_id: The id of the multipart upload to uplaod this part to.

        Returns the key of the uploaded file.
        """
        raise NotImplementedError("Not done yet.")

    def complete_multipart(self, mpu_id):
        """Finalize a multipart upload.

        :type mpu_id: string
        :param mpu_id: The id of the multipart upload to finalize.
        """
        raise NotImplementedError("Not done yet.")


@implementer(IObjectStore)
class S3FileStore(S3TmpFileStore):
    """A file store for intermediate, temporary storage."""

    acl = "public-read"

    def __init__(self, fs):
        """Class initializer."""
        super(S3FileStore, self).__init__(fs)

    def copy_from(self, key, src_bucket):
        """Copy a key from src_bucket to key in this bucket.

        :type key: string
        :param key: The object key to copy and put.
        :type src_bucket: An ``s3.Bucket``
        :param src_bucket: The bucket to copy the object to.

        returns TODO:????
        """
        raise NotImplementedError("Not done yet.")


def iterbody(body):
    """Iterate over a file body so we don't load into memory all at once."""
    for chunk in iter(partial(body.read, CHUNK_SIZE), b""):
        yield chunk

# TODO: refactor if/when there's time to refactor
# avail.aws.elastictranscoder to use os.path.splitext.

# It may seem overkill to have these little functions generating paths, but
# processes shouldn't assume knowledge of the shape of paths of assets,
# artifacts and metadata files. If we change the layout of the buckets, the
# processes shouldn't care. Avoid hardcoding info about job_id, asset_id,
# asset_fname, and artifact /OUT/ directories so consumers won't need to care.


def get_file_type_assetid_ext(asset_fname):
    """Return key parts (type, asset_id, extension) basedon asset file name.

    Determine type (audio, image, video) from extension.  Return parts
    type, asset_id, extension suitable for building an S3 key, using
    this order since that's how the S3 path is shaped.  .  Used to
    generate private and public bucket keys, which are nearly
    identical.

    Example:
        Input: '/path/to/nasaid9876.tiff'
        Output: ("image", "nasaid9876", "tiff")

    :param asset_fname: UNIX-style path to asset with extension
    : type asset_fname: str
    :rtype: tuple

    """
    path, filename = os.path.split(asset_fname)
    fbase, fext = os.path.splitext(filename)
    if not fext:
        error_tmpl = 'No file extension in filename={}'
        error_msg = error_tmpl.format(asset_fname)
        log.error(error_msg)
        raise ValueError(error_msg)
    # Make sure this file ending is one of the A/I/V formats we support.
    # Remove the leading '.' from `fext` because none of the _EXTENSIONS
    # constants include dots.
    fext = fext[1:]
    # figure out the file type based on the file ending.
    if fext.lower() in AUDIO_EXTENSIONS:
        ftype = 'audio'
    elif fext.lower() in IMAGE_EXTENSIONS:
        ftype = 'image'
    elif fext.lower() in VIDEO_EXTENSIONS:
        ftype = 'video'
    else:
        error_tmpl = 'filename={} has unsupported file ending ``{}``.'
        error_msg = error_tmpl.format(asset_fname, fext)
        log.error(error_msg)
        raise ValueError(error_msg)
    # add the asset's file type to the S3 key.
    return (ftype, fbase, fext)


def get_private_s3_key(job_id, asset_fname):
    """Return a `str` which is this asset's key in Private S3 bucket.

    This key is needed at upload time, and can also be to figure out
    where to expect to find an asset if it's already been uploaded to
    S3. We infix "~orig" so it will look like the other size-named
    images in the Public bucket when copied over.

    Tolerate asset_id which already has ~orig so we can input the asset_key.

    Example:
        Input: 'jobId1234', '/path/to/alex.tiff'
        Output: 'jobId1234/image/alex/alex~orig.tiff'

    :param str job_id: The Id of the job assigned from the JobDB.
    :param str asset_fname: The name of an asset to upload to S3.
    :raises ValueError: bad job_id
    :rtype: str
    """
    if type(job_id) is not str or not job_id.strip():
        error_msg = 'job_id must be nonempty str'
        log.error(error_msg)
        raise ValueError(error_msg)
    (ftype, asset_id, ext) = get_file_type_assetid_ext(asset_fname)
    if asset_id.endswith("~orig"):
        asset_id = asset_id[:-len("~orig")]
    return os.path.join(job_id, ftype, asset_id, asset_id + "~orig." + ext)


def get_private_s3_artifact_prefix(job_id, asset_fname):
    """Return the key prefix (dir) where artifacts should live, including "/".

    We need this so we can query for all artifacts under this prefix in S3.
    Yes, it will imply some omniscience on the caller which uses this.

    Examples:

       Input: jobId1234, /path/to/alex.tiff
       Output: jobId1234/image/alex/OUT/

    :param str job_id: The Id of the job assigned from the JobDB.
    :param str asset_fname: The name of an asset to base our path on.
    :rtype: str
    """
    if type(job_id) is not str or not job_id.strip():
        error_msg = 'job_id must be nonempty str'
        log.error(error_msg)
        raise ValueError(error_msg)
    (ftype, asset_id, ext) = get_file_type_assetid_ext(asset_fname)
    if asset_id.endswith("~orig"):
        asset_id = asset_id[:-len("~orig")]
    # Final quote forces a trailing "/"
    return os.path.join(job_id, ftype, asset_id, "OUT", "")


def get_private_s3_artifact_root(job_id, asset_fname):
    """
    Return the root of the key prefix (dir) where artifacts should live.

    We need this so we can query for all artifacts under this prefix in S3.
    Yes, it will imply some omniscience on the caller which uses this.

    Examples:

       Input: jobId1234, /path/to/alex.tiff
       Output: jobId1234/

    :param str job_id: The Id of the job assigned from the JobDB.
    :param str asset_fname: The name of an asset to base our path on.
    :rtype: str
    """
    if type(job_id) is not str or not job_id.strip():
        error_msg = 'job_id must be nonempty str'
        log.error(error_msg)
        raise ValueError(error_msg)
    prefix = get_private_s3_artifact_prefix(job_id, asset_fname)
    root = prefix.split(os.sep)[0]
    return os.path.join(root, "")


def get_private_s3_artifact_key(job_id, asset_fname, artifact_fname):
    """Return the key (path) where artifacts should live.

    Artifacts include transcoded and resized files as well as validated
    metadata files that will get published.

    Examples:

       Input: jobId1234, /path/to/alex.tiff, metadata.json
       Output: jobId1234/image/alex/OUT/metadata.json

       Input: jobId1234, /path/to/alex.tiff, some/path/metadata.json
       Output: jobId1234/image/alex/OUT/metadata.json

    :param str job_id: The Id of the job assigned from the JobDB.
    :param str asset_fname: The name of an asset to base our path on.
    :param str artifact_fname: File path or name of the artifact we'll store.
    :rtype: str
    """
    key = get_private_s3_key(job_id, asset_fname)
    asset_dir, _ = os.path.split(key)
    _, artifact_fname = os.path.split(artifact_fname)
    return os.path.join(asset_dir, "OUT", artifact_fname)


def get_public_s3_key(asset_fname):
    """Return the public asset's key (with ~orig) in Public S3 bucket.

    The file name will include an "~orig" infix for consistency with other
    public asset names created by imageresizer. Tolerate any asset_id already
    suffixed with ~orig so we can pass a job's asset_path that already has
    this.

    Examples:

        Input:  '/jid/image/assid/alex.tiff'
        Output: 'image/alex/alex~orig.tiff'

        Input:  '/jid/image/assid/alex~orig.tiff'
        Output: 'image/alex/alex~orig.tiff'

    :param str asset_fname: The name of an asset to upload to S3, sans ~orig.
    :rtype: str

    """
    (ftype, asset_id, ext) = get_file_type_assetid_ext(asset_fname)
    if asset_id.endswith("~orig"):
        asset_id = asset_id[:-len("~orig")]
    return os.path.join(ftype, asset_id, asset_id + "~orig." + ext)


def get_public_s3_artifact_prefix(asset_fname):
    """Return the key prefix (dir) where artifacts should live, including "/".

    We need this so we can query for all artifacts under this prefix in S3.
    Yes, it will imply some omniscience on the caller which uses this.

    Examples:

       Input: path/to/alex.tiff
       Output: image/alex/

    :param str asset_fname: The name of an asset to base our path on.
    :rtype: str
    """
    asset_key = get_public_s3_key(asset_fname)
    asset_dir, _ = os.path.split(asset_key)
    return asset_dir


def get_public_s3_artifact_key(asset_fname, artifact_fname):
    """Return the public asset's key (path) in Public S3 bucket.

    The path's dir is based on the asset's name, then has the asset's filename
    appended. We accept paths or bare filenames for the artifact, since we only
    care about the final fname -- we'll strip the leading dir. Tolerate any
    asset_id already suffixed with ~orig so we can pass a job's asset_path that
    already has this.

    Examples:

        Input:  path/to/alex.tiff, metadata.json
        Output: image/alex/metadata.json

        Input:  path/to/alex.tiff, jid/aid/OUT/metadata.json
        Output: image/alex/metadata.json

        Input:  path/to/alex.tiff, jid/aid/aid~orig.json
        Output: image/alex/aid~orig.json

    :param str asset_fname: The name of an asset to upload to S3.
    :param str artifact_fname: File path or name of the artifact we'll store.
    :rtype: str

    """
    key = get_public_s3_key(asset_fname)
    asset_dir, _ = os.path.split(key)
    _, artifact_fname = os.path.split(artifact_fname)
    return os.path.join(asset_dir, artifact_fname)
