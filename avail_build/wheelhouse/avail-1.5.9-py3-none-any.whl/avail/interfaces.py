"""Copyright 2015 AVAIL Authors.  See AUTHORS.txt in the repo root.

All rights reserved. Use of this source code is governed by a
proprietary license that can be found in the LICENSE file.

AVAIL interfaces are defined here.
"""

from zope.interface import (Attribute, Interface)


class IAsset(Interface):
    """Asset represents the basic information for a multimedia asset.
    """
    prefix = Attribute("The prefix of this Asset in file storage.")
    deleted_id = Attribute("The nasaid if this asset has been deleted.")
    id = Attribute("The NASA ID if current or a GUID if not")
    jobs = Attribute("The jobs that  have created or modified this asset")
    last_modified = Attribute("The last time this Asset was modified.")


class IAssetDB(Interface):
    """AssetDB is a handle to the AWS DynamoDB Asset table.

    It returns asset information.
    """

    def __init__(table):
        """Class onstructor."""


    def by_id(nasa_id):  # flake8: noqa
        """Get a Asset by NASA Id."""

    def new(nasa_id, asset_prefix, userid):  # flake8: noqa
        """Create a new Asset.

        There should only be one. """

    # def recent():  # flake8: noqa
    #     """Get recently updated or added assets."""


class IJob(Interface):
    """:term:`Job` represents a task across the AVAIL :term:`pipeline`.

    An in coming request may pass through a number of services once submitted.
    The `IJob` implementation allows for tracking an :term:`Asset` and its
    state across those services.
    """
    error = Attribute(
        "Boolean representing if this Job has enterred an error state.")
    incomplete = Attribute("Boolean representing if the Job is incomplete.")
    deadlettered = Attribute(
        "Boolean representing if any of the Job's SQS messages reached the"
        "DeadLetterQueue.")
    history = Attribute(
        "The state history for the asset associated with this Job.")
    id = Attribute("Return the Job ID")
    last_modified = Attribute("The last time this Job was modified.")
    next_state = Attribute("The next state for this Job.")
    previous_state = Attribute("The previous state for this Job.")
    state = Attribute(
        "The current state of a the asset associated with this Job.")
    owner = Attribute("The User ID of whoever initiated this job.")
    asset_path = Attribute("The path of this job's associated asset.")
    metadata_path = Attribute(
        # TODO: THis is in the public bucket now, but really should go back to
        # the private bucket.
        "The path of this job's associated asset's metadata.")
    asset_id = Attribute("The asset id -- NASA Id -- for this job's asset.")
    media_type = Attribute("The media type of this job's asset.")
    prefix = Attribute("The prefix for this asset -- in the private bucket.")

    def transition():  # flake8: noqa
        """Move the Job to the next state."""


class IJobDB(Interface):
    """JobDB is a handle to the AWS DynamoDB Job table.

    It returns new or existing Job items.
    """

    def by_id(job_id):  # flake8: noqa
        """Get a Job by job_id."""

    def new(asset_path, user_id):  # flake8: noqa
        """Create a new Job."""

    def unfinished():
        """Return a list of Jobs in an unfinished state."""

    def incomplete():
        """Return list of Jobs that are not complete."""

    # def incomplete_by_user_id():
    #     """Return list of Jobs that are not complete for a given user_id."""


class IUserDB(Interface):
    """UserDB is a handle to the AWS DynamoDB User table.

    It returns new or existing User items.
    """

    def by_auid(auid):  # flake8: noqa
        """Get a User by their NASA Agency UID (e.g., cbolden)."""



class IMetadata(Interface):
    """:term:`Metadata` in :term:`AVAIL` represent media metadata.

    This interface outlines shared metadata across all :term:`media asset`
    type.
    """

    # def serialize():
    #     """return serialized representation asset's additional metadata."""

    def app14(key):  # noqa
        """Return APP14 metadata group item matching key."""

    def composite(key):  # noqa
        """Return Composite metadata group item matching key."""

    def exif(key):  # noqa
        """Return EXIF metadata group item matching key."""

    def file(key):  # noqa
        """Return File metadata group item matching key."""

    def icc_profile(key):  # noqa
        """Return ICC_Profile metadata group item matching key."""

    def iptc(key):  # noqa
        """Return IPTC metadata group item matching key."""

    def photoshop(key):  # noqa
        """Return Photoshop metadata group item matching key."""

    def xmp(key):  # noqa
        """Return XMP metadata group item matching key."""

    def app14_items():
        """Return all APP14 group metadata items."""

    def composite_items():
        """Return all Composite group metadata items."""

    def exif_items():
        """Return all EXIF group metadata items."""

    def file_items():
        """Return all File group metadata items."""

    def icc_profile_items():
        """Return all ICC_Profile group metadata items."""

    def iptc_items():
        """Return all IPTC group metadata items."""

    def photoshop_items():
        """Return all Photoshop group metadata items."""

    def xmp_items():
        """Return all XMP group metadata items."""


class ITempObjectStore(Interface):
    """A class that implements this interface can manage file objects.

    In this case it represents a temporary store.
    """

    acl = Attribute("The default ACL for items in this bucket.")
    bucket = Attribute("The name of the bucket or the bucket itself.")

    def get(key):  # noqa
        """Fetch an object from the object store."""

    def put(key, fh):  # noqa
        """Put the file at filehandle in the object store at key."""

    def delete(key, prefix=""):  # noqa
        """Delete the object at key in the bucket."""

    def head(key):  # noqa
        """Perform a HEAD request on the ``key`` in the object store."""

    def start_multipart():  # noqa
        """Begin a multipart upload.

        This starts a multipart, chunked, or resumable....
        """

    def put_multipart(key, fh, mpu_id):  # noqa
        """Put the file at file handle in the object store.

        Use a multipart uplaod, however. This id for large file or streaming
        through from a client direc tto the object store.
        """

    def complete_multipart(mpu_id):  # noqa
        """Finish a multipart upload."""


class IObjectStore(ITempObjectStore):
    """A permanent object store."""

    def copy_from(key, store):  # noqa
        """Copy the ``key`` from this store to the ``store`` object store."""


class IPublishedQueue(Interface):
    # TODO: Make an IQueue wiht the advertized interface and inherit.
    """Marker interface for the Published Queue."""


class ITranscodedQueue(Interface):
    # TODO: Inherit the IQueue interface one day.
    """Marker interface for the Transcoded Queue."""
