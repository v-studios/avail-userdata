""" Copyright 2015 Reed O'Brien <reed@v-studios.com>.

All rights reserved. Use of this source code is governed by a
proprietary license that can be found in the LICENSE file.

AVAIL asset imports are defined here.
"""

from .predicates import ContentTypePredicate

from .security import (AVAILAuthenticationPolicy, authenticated_userinfo)

__all__ = (AVAILAuthenticationPolicy, ContentTypePredicate,
           authenticated_userinfo)
