"""Module to house any custom predicates for avail REST APIs.

Copyright (c) 2015 AVAIL Authors. See AUTHORS.txt in the root of the repo.
"""


class ContentTypePredicate:
    """Ensure content type is of a certain value.

    :type ctype: string
    :type ctype: The content type that this predicate should enforce.
    :type config: pyramid.config.Configurator
    :type config: The Configurator instance at the time of configuration.

    Returns bool noting whether the defined ctype is a match.

    Usage:
    .. code-block: python

        # import
        from avail.system import ContentTypePredicate

        # Wire up in Configurator example
        config.add_view_predicate("content_type", ContentTypePredicate)

        # Use in view/route configuration
        config.add_view(JSONOnlyExampleView, content_type="application/json")

    """

    def __init__(self, ctype, config):
        """The class constructor."""
        self.ctype = ctype

    def text(self):
        """Return a string representation of the predicate."""
        return "content type={}".format(self.ctype)

    # Same thing for a predicate hash
    phash = text

    def __call__(self, context, request):
        """Make the class callable and implement the check."""
        return request.content_type == self.ctype
