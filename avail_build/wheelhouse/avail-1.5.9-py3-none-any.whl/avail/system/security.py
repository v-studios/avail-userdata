"""Authentication implementation module.

Copyright (c) 2015 AVAIL Authors. See AUTHORS.txt in the root of the repo.
"""

from datetime import datetime
from datetime import timedelta

import jwt

from pyramid.interfaces import (IAuthenticationPolicy)
from pyramid.security import (Authenticated, Everyone)

from zope.interface import implementer

algorithms = ["HS256", "HS512"]


@implementer(IAuthenticationPolicy)
class AVAILAuthenticationPolicy:
    """AVAIL implementation of the pyramid authentication policy.

    Don't know what args it will take yet.
    """

    def __init__(self, secret,
                 algorithm="HS512",
                 audience=None,
                 duration=8, **kw):
        """AVAILAuthenticationPolicy constructor.

        :type secret: string
        :param secret: A secret string for signing authorization tokens.
        :type algorithm: string
        :param algorithm: The agorithm to use. Defaults to HS512.
        :type audience: string
        :param audience: A string for the JWT audience. Defaults to None
        :type deration: int
        :param duration: How long in hours a token is valid. Defaults to 8
                         hours.
        """
        self.algorithm = algorithm
        if audience:
            self.audience = audience
        self.secret = secret
        self.duration = duration
        for k, v in kw:
            setattr(self, k, v)

    def authenticated_userid(self, request):
        """Return the authenticated userid or "None" if not found.

        :param request: The current ``pyramid.request.Request``.
        """
        try:
            userinfo = self.authenticated_userinfo(request)
            user = userinfo.get("sub", None)
            return user if user else None
        except jwt.exceptions.ExpiredSignatureError:
            return None
        except (jwt.exceptions.InvalidTokenError, jwt.exceptions.DecodeError,
                jwt.exceptions.InvalidAudienceError,
                jwt.exceptions.InvalidIssuerError,
                jwt.exceptions.InvalidKeyError,
                jwt.exceptions.InvalidAlgorithmError):
            return None

    def unauthenticated_userid(self, request):
        """Return the *unauthenticated* userid.

        It is permitted to return whatever is in the current request without
        validating.

        :param request: The current ``pyramid.request.Request``.
        """
        raise NotImplementedError("Deliberately unimplemented")

    def effective_principals(self, request):
        """Return a sequence representing the effective principals.

        The returned principals *including* the userid and any groups belonged
        to by the current user, including 'system' groups such as
        ``pyramid.security.Everyone`` and ``pyramid.security.Authenticated``.

        :param request: The current ``pyramid.request.Request``.
        """
        eff_princs = [Everyone]
        try:
            userinfo = self.authenticated_userinfo(request)
        except jwt.exceptions.ExpiredSignatureError:
            return eff_princs
        except (jwt.exceptions.InvalidTokenError, jwt.exceptions.DecodeError,
                jwt.exceptions.InvalidAudienceError,
                jwt.exceptions.InvalidIssuerError,
                jwt.exceptions.InvalidKeyError,
                jwt.exceptions.InvalidAlgorithmError):
            return eff_princs

        userid = userinfo.get("sub", None)
        if userid:
            eff_princs.append(Authenticated)
            eff_princs.append(userid)
        roles = userinfo.get("roles", None)
        if roles:
            eff_princs.extend(roles)
        return eff_princs

    def remember(self, request, principal, extra=None, **kw):
        """Create JWT tocken from payload.

        The principal named ``principal`` when set in a response. An individual
        authentication policy and its consumers can decide on the composition
        and meaning of kw.
        TODO: This may be a noop. There's no cookie to set...

        :type request: pyramid.request.Request
        :param request: The current ``pyramid.request.Request``
        :type principal: string
        :param principal: The userid that will get the token set for it.
        :type extra: dict
        :param extra: A dictionary of k,v pairs to add to the token.
        :param kw: Not sure what will go here yet.

        Return the JWT as a UTF-8 string.
        """
        expiry = datetime.utcnow() + timedelta(hours=self.duration)
        payload = {
            "sub": principal,
            "iss": "https://images.nasa.gov/",
            "aud": self.audience,
            "exp": expiry
        }
        if extra:
            payload.update(extra)
        token = jwt.encode(payload, self.secret, algorithm=self.algorithm)
        return token.decode("utf8")

    def forget(self, request):
        """Return headers suitable for 'forgetting' the current user.

        The call should forget the current user on subsequent requests.

        TODO: This should likely send ``401 Not authorized`` causing the client
        to reauthenticate.

        :param request: The current ``pyramid.request.Request``
        """
        raise NotImplementedError("Deliberately unimplemented")

    def authenticated_userinfo(self, request):
        """Proxy for the stand-alone ``authenticated_userinfo`` func."""
        try:
            return authenticated_userinfo(request)
        except Exception:
            raise


def authenticated_userinfo(request):
    """Return userinfo contained in the JWT token.

    This function is used by `AVAILAuthenticationPolicy` to extract user and
    principal information.

    :param request: The ``pyramid.request.Request`` to extract from.
    """
    if request.authorization is None:
        return {}
    _, token = request.authorization
    if not token:
        return {}
    # Get paramaters needed for decoding from the request's settings.
    secret = request.registry.settings['authentication_policy.secret']
    algorithm = request.registry.settings['authentication_policy.algorithm']
    audience = request.registry.settings['authentication_policy.audience']
    try:
        jot = jwt.decode(token.encode('utf8'), secret,
                         algorithms=[algorithm],
                         audience=audience)
        return jot
    except jwt.exceptions.ExpiredSignatureError:
        raise
    except (jwt.exceptions.InvalidTokenError, jwt.exceptions.DecodeError,
            jwt.exceptions.InvalidAudienceError,
            jwt.exceptions.InvalidIssuerError, jwt.exceptions.InvalidKeyError,
            jwt.exceptions.InvalidAlgorithmError):
        raise
