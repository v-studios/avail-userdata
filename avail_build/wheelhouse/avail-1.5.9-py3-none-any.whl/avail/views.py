"""
Initial file for avail views.

Copyright (c) 2015 AVAIL Authors. See AUTHORS.txt in the root of the repo.
"""

import base64
import codecs
import json
from hashlib import md5
from mimetypes import guess_extension

from pyramid.httpexceptions import (HTTPBadRequest, HTTPCreated, HTTPNoContent,
                                    HTTPOk, HTTPSeeOther)
from pyramid.view import view_config


bytereader = codecs.getreader("utf-8")


@view_config(route_name="home", renderer="json", request_method="GET")
def my_view(request):  # pragma: no cover
    """Hello world view."""
    ass_type = request.matchdict["ass_type"]
    key = request.matchdict["key"]
    url = "/".join([request.fs.bucket.meta.client.meta.endpoint_url,
                    request.fs.bucket.name, ass_type, key])
    return HTTPSeeOther(json={}, location=url)


@view_config(route_name="info", renderer="json", request_method="GET")
def info_view(request):  # pragma: no cover
    """Hello world info view."""
    ass_type = request.matchdict["ass_type"]
    key = request.matchdict["key"]
    asset_info = request.fs.head("/".join([ass_type, key]))
    url = "/".join([request.fs.bucket.meta.client.meta.endpoint_url,
                    request.fs.bucket.name, ass_type, key])
    asset_info["location"] = url
    asset_info["LastModified"] = asset_info["LastModified"].isoformat()
    asset_info["ContentLength"] = str(asset_info["ContentLength"])
    del asset_info["Metadata"]
    del asset_info["ResponseMetadata"]
    return HTTPOk(json=asset_info, headers=asset_info)


@view_config(route_name="post", renderer="json", request_method="POST")
def post_view(request):  # pragma: no cover
    """Docstring here."""
    upload = request.params["upload_file"]
    try:
        md = json.load(bytereader(request.params["json_metadata"].file))[0]
    except Exception as e:
        return HTTPBadRequest("Couldn't parse metadata: {}".format(e))
    nid = md.get("JobIdentifier",
                 md.get("OriginalTransmissionReference", None))
    if nid is None:
        nid = md.get("FileName", None).rsplit(".", 1)[0]
    content_type = md["MIMEType"]
    ass_type = content_type.split("/")[0]
    ext = guess_extension(content_type)
    content_md5 = md5(upload.file.read()).digest()
    base64_md5 = base64.encodestring(content_md5).decode("utf-8").strip("\n")
    upload.file.seek(0)
    key = ass_type + "/" + nid + ext
    got = request.tmpfs.put(key, upload.file, content_md5=base64_md5)
    url = "/".join([request.tmpfs.bucket.meta.client.meta.endpoint_url,
                    request.tmpfs.bucket.name, key])
    got["location"] = url
    return HTTPCreated(json=got)


@view_config(route_name="home", renderer="json", request_method="DELETE")
def delete_view(request):  # pragma: no cover
    """Delete asset."""
    # TODO: Always succeeds, do we need to care?
    result = request.fs.delete("/".join([request.matchdict["ass_type"],
                                         request.matchdict["key"]]))
    if result["ResponseMetadata"]["HTTPStatusCode"] == 204:
        return HTTPNoContent(json={})


@view_config(route_name='root', renderer='json', request_method='GET',
             content_type='application/json')
def root_view(request):
    """View for /."""
    return {}
