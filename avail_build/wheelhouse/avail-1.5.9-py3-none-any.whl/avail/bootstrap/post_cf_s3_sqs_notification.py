#!/usr/bin/env python
# Copyright 2015 AVAIL Authors. See AUTHORS.txt in the root of the repo.

"""Setup non-CF-enabled infrastructure after building CloudFormation with Tropo.

After using Troposphere to create the CloudFormation template and
uploading that to CloudFormation to build the infrastructure, we have
to setup the infrastructure with things that CF can't do:

* create_s3_sqs: S3 Incoming notification to SQS Uploaded

There is an entry point for this defined in setup.py.

We're migrating individual resources out of this file into other
resource-specific files...
"""

import argparse
import configparser
import logging

import boto3

logging.basicConfig(level=logging.INFO)


def create_s3_sqs(config):
    """Add SQS notification when files hit the S3 Private (incoming) bucket.

    The SQS queue has a policy allowing S3 to SendMessage defined by
    Troposphere.

    It is safe to run this script more than once.
    """
    # TODO: We may be able to distinguish uploads and our own code's
    # object creation by the ObjectCreated methods, and we may want to
    # tighten what we accept: Put, Post, Copy,
    # CompleteMultipartUpload; for now allow all with "*".

    # {
    #     "QueueConfigurations": [
    #         {
    #             "Events": [
    #                 "s3:ObjectCreated:*"
    #             ],
    #             "Id": "Notifications",
    #             "QueueArn":
    #                 "arn:aws:sqs:us-east-1:355255540862:avail-uploaded"
    #         }
    #     ],
    # }
    logging.info("Creating S3 to SQS notification...")

    bucket_notification_configuration = {
        "QueueConfigurations": [{
            "Events": ["s3:ObjectCreated:*"],
            "Id": "Notifications",
            "QueueArn":
            "arn:aws:sqs:{}:{}:{}".format(
                config["AWS"]["region"],
                config["AWS"]["account"],
                config["SQS_QUEUES"]["UploadedQueue"])
        }]
    }
    client = boto3.client("s3")

    # TODO: check if they already exist

    client.put_bucket_notification_configuration(
        Bucket=config["AWS"]["s3_private_bucket_name"],
        NotificationConfiguration=bucket_notification_configuration
    )
    logging.info("Creating S3 to SQS notification...done")
    # We might want to log or display it, so return the config
    return bucket_notification_configuration


def main():
    """Entrypoint to run all steps."""
    parser = argparse.ArgumentParser(
        description="Create SQS notification.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        usage='%(prog)s $env.ini'
        )
    parser.add_argument(
        "inifile",
        help="Environment-specific .ini file for config settings.")
    args = parser.parse_args()
    config = configparser.RawConfigParser()
    config.optionxform = lambda option: option  # Preserve key case, e.g., for QueueNames
    config.read(args.inifile)
    create_s3_sqs(config)


if __name__ == "__main__":
    main()
