"""Common data for bootstrap package.

Copyright 2015 Reed O'Brien <reed@v-studios.com>. All Rights Reserved.
"""


ENVIRONS = ("dev", "prod", "stage")
