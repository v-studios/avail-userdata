import unittest

import pyramid.testing


class TestGetTemplateJSON(unittest.TestCase):
    def setUp(self):
        self.config = pyramid.testing.setUp()

    def tearDown(self):
        pyramid.testing.tearDown()

    def _ini_config(self):
        return {
            "AWS": {
                "account": "355255540862",
                "region": "us-east-1",
                "op_env": "dev",
                "op_env_tag": "dev",
                "ec2_tarball_url_base":
                    "http://code.dev.nasawestprime.com/avail/",
                "cloudwatch_iam_policy": "cloudwatch_put",
                "ami_id": "ami-f18b6a9a",
                "dynamodb_userdb_readunits": "1",
                "dynamodb_userdb_writeunits": "1",
                "dynamodb_assetdb_table_readunits": "5",
                "dynamodb_jobdb_table_readunits": "30",
                "dynamodb_jobdb_assetpath_mtime_readunits": "5",
                "dynamodb_jobdb_error_mtime_index_readunits": "15",
                "dynamodb_jobdb_incomplete_mtime_index_readunits": "5",
                "dynamodb_jobdb_writeunits": "10",

                "ec2_instance_cidr_tmpl": "10.1.5{}.0/24",

                "asg_avail_api_min": "1",
                "asg_avail_api_max": "1",
                "asg_avail_imageresizer_min": "1",
                "asg_avail_imageresizer_max": "1",
                "asg_avail_pipeline_min": "1",
                "asg_avail_pipeline_max": "1",

                "elb_avail_api": "avail-api-elb-dev",
                "elb_avail_api_healthcheck": "HTTP:80/healthcheck",
                "elb_avail_api_ssl_id": "AN_SSL_CERT_ID",
                "elb_avail_imageresizer": "avail-imageresizer-elb-dev",
                "elb_avail_imageresizer_healthcheck": "HTTP:80/healthcheck",
                "elb_avail_pipeline": "avail-pipeline-elb-dev",
                "elb_avail_pipeline_healthcheck": "HTTP:80/healthcheck",
                "route53_zone_name": "dev.nasawestprime.com",
                "route53_avail_api_elb": "avail-api.dev.nasawestprime.com",
                "route53_images_api_elb": "images-api.dev.nasawestprime.com",
                "route53_imageresizer_elb":
                    "avail-imageresizer.dev.nasawestprime.com",
                "route53_pipeline_elb":
                    "avail-pipeline.dev.nasawestprime.com",
                "route53_images_bucket": "images.dev.nasawestprime.com",
                "route53_images_assets_bucket": "images-assets.dev.nasawestprime.com",
                "route53_admin_bucket": "images-admin.dev.nasawestprime.com",
                "cloudfront_images_admin_identity": "XYZPDQ",
                "cloudfront_images_assets_identity": "XYZPDQ",
                "cloudfront_images_identity": "XYZPDQ",

                "route53_images_api_r53_name": "images-api.dev.nasawestprime.com",

                "sqs_deadletter_name": "avail-deadletter",

                "source_vpc_endpoint": "vpce-f78c419e",

                "s3_private_bucket_name": "avail-private-dev",
                "s3_images_bucket_name": "images.dev.nasa.gov",
                "s3_images_assets_bucket_name": "images-assets.dev.nasa.gov",
                "s3_images_admin_bucket_name": "images-admin.dev.nasa.gov",
                "s3_logging_name": "loggingbucket",
                "s3_logging_prefix": "loggingprefix/",

                # from earl prod
                "s3_images_r53_name": "images.dev.nasawestprime.com",
                "s3_images_assets_r53_name": "images-assets.dev.nasawestprime.com",
                "s3_images_admin_r53_name": "images-admin.dev.nasawestprime.com",


                "api_instance_type": "t2.micro",
                "imageresizer_instance_type": "t2.micro",
                "pipeline_instance_type": "t2.micro",
            },
            "SQS_QUEUES": {
                "UploadedQueue": "avail-uploaded",
                "TranscodedQueue": "avail-transcoded",
                "PublishedQueue": "avail-published",
                "IndexedQueue": "avail-indexed",
                "ErrorQueue": "avail-error",
            }
        }

    def call_fut(self, dev=True, prod=False):
        from avail.bootstrap.infrastructure import get_template_json
        return get_template_json(self._ini_config(), dev, prod)

    def test_invalid_env(self):
        import json
        j = self.call_fut()
        t = json.loads(j)
        # Basic section structure
        self.assertTrue("AWSTemplateFormatVersion" in t)
        self.assertTrue("Description" in t)
        self.assertTrue("Outputs" in t)
        self.assertTrue("Parameters" in t)
        self.assertTrue("Resources" in t)

        # Basic checks in each section
        self.assertEqual(t["AWSTemplateFormatVersion"], "2010-09-09")
        self.assertTrue("AVAIL" in t["Description"])

        # Outputs
        self.assertTrue("APIELBName" in t["Outputs"])
        self.assertTrue("APIInstanceProfile" in t["Outputs"])
        self.assertTrue("APIRole" in t["Outputs"])
        self.assertTrue("DeadLetterQueueArn" in t["Outputs"])
        self.assertTrue("DeadLetterQueueUrl" in t["Outputs"])
        self.assertTrue("ErrorQueueArn" in t["Outputs"])
        self.assertTrue("ErrorQueueUrl" in t["Outputs"])
        self.assertTrue("ImageResizerELBName" in t["Outputs"])
        self.assertTrue("ImageResizerInstanceProfile" in t["Outputs"])
        self.assertTrue("ImageResizerRole" in t["Outputs"])
        self.assertTrue("IndexedQueueArn" in t["Outputs"])
        self.assertTrue("IndexedQueueUrl" in t["Outputs"])
        self.assertTrue("NATDNS" in t["Outputs"])
        self.assertTrue("NATIP" in t["Outputs"])
        self.assertTrue("PipelineELBName" in t["Outputs"])
        self.assertTrue("PipelineInstanceProfile" in t["Outputs"])
        self.assertTrue("PipelineRole" in t["Outputs"])
        self.assertTrue("PrivateBucket" in t["Outputs"])
        self.assertTrue("ImagesBucket" in t["Outputs"])
        self.assertTrue("ImagesAdminBucket" in t["Outputs"])
        self.assertTrue("ImagesAssetsBucket" in t["Outputs"])
        self.assertTrue("ImagesBucketDNS" in t["Outputs"])
        self.assertTrue("ImagesAdminBucketDNS" in t["Outputs"])
        self.assertTrue("ImagesAssetsBucketDNS" in t["Outputs"])
        self.assertTrue("PublishedQueueArn" in t["Outputs"])
        self.assertTrue("PublishedQueueUrl" in t["Outputs"])
        self.assertTrue("TranscodedQueueArn" in t["Outputs"])
        self.assertTrue("TranscodedQueueUrl" in t["Outputs"])
        self.assertTrue("UploadedQueueArn" in t["Outputs"])
        self.assertTrue("UploadedQueueUrl" in t["Outputs"])

        # Parameters
        self.assertTrue("JobStateReadUnits" in t["Parameters"])
        self.assertTrue("KeyName" in t["Parameters"])
        self.assertTrue("SSHLocation" in t["Parameters"])
        self.assertTrue("ScaleNotificationEmail1" in t["Parameters"])
        self.assertTrue("ScaleNotificationEmail2" in t["Parameters"])

        # Resources
        self.assertTrue("APIAutoscalingGroup" in t["Resources"])
        self.assertTrue("APICPUAlarmHigh" in t["Resources"])
        self.assertTrue("APICPUAlarmLow" in t["Resources"])
        self.assertTrue("APIInstanceProfile" in t["Resources"])
        self.assertTrue("APILaunchTemplate" in t["Resources"])
        self.assertTrue("APILoadBalancer" in t["Resources"])
        self.assertTrue("APIRole" in t["Resources"])
        self.assertTrue("APIScaleDownPolicy" in t["Resources"])
        self.assertTrue("APIScaleUpPolicy" in t["Resources"])
        self.assertTrue("AllowAllFromVPC" in t["Resources"])
        self.assertTrue("AllowSSH" in t["Resources"])
        self.assertTrue("AllowHTTPSFromCDN" in t["Resources"])
        self.assertTrue("AttachGateway" in t["Resources"])
        self.assertTrue("DeadLetterQueue" in t["Resources"])
        self.assertTrue("DefaultRoute" in t["Resources"])
        self.assertTrue("ErrorQueue" in t["Resources"])
        self.assertTrue("IGWRouteTable" in t["Resources"])
        self.assertTrue("ImageResizerAutoscalingGroup" in t["Resources"])
        self.assertTrue("ImageResizerCPUAlarmHigh" in t["Resources"])
        self.assertTrue("ImageResizerCPUAlarmLow" in t["Resources"])
        self.assertTrue("ImageResizerInstanceProfile" in t["Resources"])
        self.assertTrue("ImageResizerLaunchTemplate" in t["Resources"])
        self.assertTrue("ImageResizerLoadBalancer" in t["Resources"])
        self.assertTrue("ImageResizerRole" in t["Resources"])
        self.assertTrue("ImageResizerScaleDownPolicy" in t["Resources"])
        self.assertTrue("ImageResizerScaleUpPolicy" in t["Resources"])
        self.assertTrue("IndexedQueue" in t["Resources"])
        self.assertTrue("InternetGateway" in t["Resources"])
        self.assertTrue("JobStateDB" in t["Resources"])
        self.assertTrue("NATDefaultRoute" in t["Resources"])
        self.assertTrue("NATInstance" in t["Resources"])
        self.assertTrue("NATRouteTable" in t["Resources"])
        self.assertTrue("PipelineAutoscalingGroup" in t["Resources"])
        self.assertTrue("PipelineCPUAlarmHigh" in t["Resources"])
        self.assertTrue("PipelineCPUAlarmLow" in t["Resources"])
        self.assertTrue("PipelineInstanceProfile" in t["Resources"])
        self.assertTrue("PipelineLaunchTemplate" in t["Resources"])
        self.assertTrue("PipelineLoadBalancer" in t["Resources"])
        self.assertTrue("PipelineRole" in t["Resources"])
        self.assertTrue("PipelineScaleDownPolicy" in t["Resources"])
        self.assertTrue("PipelineScaleUpPolicy" in t["Resources"])
        self.assertTrue("PrivateBucket" in t["Resources"])
        self.assertTrue("ImagesBucket" in t["Resources"])
        self.assertTrue("ImagesAdminBucket" in t["Resources"])
        self.assertTrue("ImagesAssetsBucket" in t["Resources"])
        self.assertTrue("PublishedQueue" in t["Resources"])
        self.assertTrue("ScalingSNSTopic" in t["Resources"])
        self.assertTrue("TranscodedQueue" in t["Resources"])
        self.assertTrue("UploadedQueue" in t["Resources"])
        self.assertTrue("VPC" in t["Resources"])
        self.assertTrue("app1" in t["Resources"])
        self.assertTrue("app1NAT" in t["Resources"])
        self.assertTrue("app2" in t["Resources"])
        self.assertTrue("app2NAT" in t["Resources"])
        self.assertTrue("db1" in t["Resources"])
        self.assertTrue("db1NAT" in t["Resources"])
        self.assertTrue("db2" in t["Resources"])
        self.assertTrue("db2NAT" in t["Resources"])
        self.assertTrue("infra1" in t["Resources"])
        self.assertTrue("infra1IGW" in t["Resources"])
        self.assertTrue("infra2" in t["Resources"])
        self.assertTrue("infra2IGW" in t["Resources"])
        self.assertTrue("tbd1" in t["Resources"])
        self.assertTrue("tbd2" in t["Resources"])
        self.assertTrue("webapi1" in t["Resources"])
        self.assertTrue("webapi1IGW" in t["Resources"])
        self.assertTrue("webapi2" in t["Resources"])
        self.assertTrue("webapi2IGW" in t["Resources"])
        #
        # TODO check attributes on resources
