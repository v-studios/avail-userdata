#!/usr/bin/env python
# Copyright 2019 AVAIL Authors

"""Clone content from single-album Cloudsearch into literal-array album domain.

Both domains are expected to exist, use
avail/avail/bootstrap/post_cf_cloudsearch.py to create the new one with the
literal-array 'album' and text-array 'album_text' fields.

This allows copying after an initial time.  During migration we check to see if
source record already exists in the destination, and don't copy if we don't
need to -- unless overriden by a flag. This should save some indexing time, but
might miss copying data that's changed on the source after the destination was
copied the first time.

We read the schema from src and dst, and know that the src 'text' album must be
converted to a 'list-array' for the dst; we also know we don't have to create
the album_text 'text-array' since the dst schema defines the source to be the
album field. CloudSearch gives us ALL the attributes as list, even if the
schema defines them as scalars (why, oh, why??); we have to look at dest and
feed it scalars or lists depending on whether the field is scalar or list (only
lists are keywords and album).
"""

import json
import logging
from argparse import ArgumentDefaultsHelpFormatter, ArgumentParser

from .lib import get_all_docs, get_doc_client, get_fields

BATCH_BYTES = 4 * 1024 * 1024   # CloudSearch max is 5MB, use 4MB batch

logging.basicConfig(level=logging.INFO)       # allow INFO get_all_docs()
for crap in ('boto', 'botocore', 'urllib3'):  # silence what the above allows
    logging.getLogger(crap).setLevel(logging.WARNING)
log = logging.getLogger('migrate-content')
log.setLevel(logging.INFO)


def main(args):
    """Read the source docs and push to the destination cloudsearch."""
    if args.verbose:
        log.setLevel(logging.DEBUG)

    src_fields = get_fields(args.src_domain)
    src_album_type = src_fields['album']['IndexFieldType']
    if src_album_type != 'text':
        log.warning('Source index is not "text": %s', src_album_type)
    dst_fields = get_fields(args.dst_domain)
    dst_album_type = dst_fields['album']['IndexFieldType']
    if dst_album_type != 'literal-array':
        log.error('Dest index it not "literal-array": %s', dst_album_type)
        exit(1)

    dst_csd = get_doc_client(args.dst_domain)
    write_doc = write_doc_closure(dst_csd)

    for doc in get_all_docs(args.src_domain):
        doc_id = doc['id']
        if args.force_copy:
            if args.dry_run:
                log.debug('DRYRUN force doc_id=%s))', doc_id)
            else:
                log.debug('Force doc_id=%s', doc_id)
                write_doc(doc)
        else:
            res = dst_csd.search(query="_id:'%s'" % doc_id,
                                 queryParser='structured',
                                 returnFields='_score')  # return minimum traffic
            if not res['hits']['found']:
                if args.dry_run:
                    log.info('DRYRUN write doc_id=%s', doc_id)
                else:
                    log.info('Write doc_id=%s', doc_id)
                    write_doc(doc)
    write_doc(None, flush=True)


def write_doc_closure(dst_csd):
    """Return a function with a closure to maintain and send a batch to CS.

    :param dst_csd: CloudSearch document endpoint
    :return: closure function
    """
    batch = []                  # NOQA flake8 doesn't grok the closure?

    def closure(doc=None, flush=False):
        """Closure to send the batch if big enough.

        :param dict doc: CloudSearch document with id and fields
        :param bool flush: set to True to force flushing the batch to CS
        """
        nonlocal batch
        if doc:
            doc['type'] = 'add'
            doc = _unlistify(doc)
            batch.append(doc)
        bytesize = len(repr(batch))
        if flush or bytesize > BATCH_BYTES:
            if not batch:
                return
            log.info('Uploading batch bytesize=%s len=%s', bytesize, len(batch))
            res = dst_csd.upload_documents(documents=json.dumps(batch),
                                           contentType='application/json')
            log.info('Uploaded  batch bytesize=%s len=%s adds=%s',
                     bytesize, len(batch), res['adds'])
            batch = []
    return closure


def _unlistify(doc):
    """Change non-listy dst fields to scalars for submission to CS.

    CS returns all fields as lists, even if scalars, but requires scalar fields
    to be uploaded to scalar indexes. Convert the returned lists to scalars for
    submission. We know the only listy fields in dest are album, keywords.

    Also remove albumtext and album_text if they exist, since they source album.
    doc is like:
    {'id': '0108_mjkane_test-6',
     'fields': {'album': ['Dark Side of the Moon'],
                'center': ['HQ'],
                'date_created': ['2019-01-25T00:00:00Z'],
                'keywords': ['rylie', 'test'],
                'media_type': ['video'],
                'nasa_id': ['0108_mjkane_test-6'],
                'owner': ['mjkane'],
                'title': ['0108_mjkane_test-6']},
     }

    :param dict doc: CloudSearch documument
    :return: CloudSearch document
    """
    for field in doc['fields']:
        if field not in ('album', 'keywords'):
            doc['fields'][field] = doc['fields'][field][0]
    doc['fields'].pop('albumtext', None)
    doc['fields'].pop('album_text', None)
    return doc


if __name__ == '__main__':
    parser = ArgumentParser(description=('Migrate content from single to'
                                         ' multi-album schema'),
                            formatter_class=ArgumentDefaultsHelpFormatter)
    # dashes in arg names get converted to undscores in arg.* attributes
    parser.add_argument('-s', '--src-domain', required=True,
                        help='source cloudsearch domain name')
    parser.add_argument('-d', '--dst-domain', required=True,
                        help='destination cloudsearch domain name')
    parser.add_argument('-f', '--force-copy',
                        default=False, action='store_true',
                        help='copy even if the dest doc already exists')
    parser.add_argument('-D', '--dry-run',
                        default=False, action='store_true',
                        help='do not actually write to the dst')
    parser.add_argument('-v', '--verbose',
                        default=False, action='store_true',
                        help='log all writes, not just batch')
    args = parser.parse_args()
    main(args)
