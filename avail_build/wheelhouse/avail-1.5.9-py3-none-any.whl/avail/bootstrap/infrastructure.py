#!/usr/bin/env python
r"""Setup the AWS S3 environment.

Copyright 2015 AVAIL team. All Rights Reserved.

Does the following::
    - Creates VPC, Internet Gateway (IGW), Public Route Table,
      NAT Gateway, and Private Route Table.
    - Creates Subnets
    - Associates public Subnets with IGW.
    - Associates private Subnets with NAT Gateway.
    - Creates AutoScaling Groups with ELB for public API and private
      ImageResizer, Pileline.
    - Creates DynamoDB for JobState, Assets, Users table.
    - Creates IAM Roles, Policies, Instance Profiles for instances to access
      resources.

Where $env.ini is one of:
    dev   = dev.ini
    stage = stage.ini
    prod  = prod.ini

Create a new stack like::

  ./infrastructure.py $env.ini > newstack.json
  or
  create_cfn_json $env.ini > newstack.json

  aws cloudformation create-stack \
      --stack-name newstack \
      --template-body file://newstack.json \
      --capabilities CAPABILITY_IAM \
      --parameters ParameterKey=KeyName,ParameterValue=your-key-name

Update an existing stack: see docs/deploy_infrastructure.rst.
"""

import argparse
import configparser

import awacs.acm
import awacs.autoscaling
from awacs.aws import (
    # Action,
    AWSPrincipal,
    Allow,
    ArnEquals,
    Condition,
    Everybody,
    IpAddress,
    Policy,
    Principal,
    SourceArn,
    Statement,
    StringEquals
)
import awacs.cloudformation
import awacs.cloudsearch
import awacs.dynamodb
import awacs.elasticloadbalancing
import awacs.elastictranscoder
import awacs.iam
import awacs.logs
import awacs.s3
import awacs.sns
import awacs.sqs
import awacs.sts

from troposphere import (
    Base64,
    FindInMap,
    GetAtt,
    Join,
    Output,
    Parameter,
    Ref,
    Tags,
    Template,
    autoscaling,
    cloudwatch as cw,
    dynamodb,
    ec2,
    elasticloadbalancing as elb,
    iam,
    route53,
    s3,
    sns,
    sqs,
)


def get_template(config, dev, prod):
    """Return CloudFormation template object.

    Get values from .ini file, build the Troposphere template object.
    """
    # We could move these down into the code body, once workng here.
    aws_account = config['AWS']['account']
    aws_region = config['AWS']['region']
    op_env = config['AWS']['op_env']  # DNS host, zone, autoscaling
    op_env_tag = config['AWS']['op_env_tag']  # IZ wants diff stage -> staging
    ami_id = config['AWS']['ami_id']
    ec2_tarball_url_base = config['AWS']['ec2_tarball_url_base']

    cloudwatch_iam_policy = "arn:aws:iam::" + "aws" + ":policy/" + config['AWS']['cloudwatch_iam_policy']

    dynamodb_userdb_readunits = int(config['AWS']['dynamodb_userdb_readunits'])
    dynamodb_userdb_writeunits = int(config['AWS']['dynamodb_userdb_writeunits'])
    dynamodb_assetdb_table_readunits = int(config['AWS']['dynamodb_assetdb_table_readunits'])
    dynamodb_jobdb_table_readunits = int(config['AWS']['dynamodb_jobdb_table_readunits'])
    dynamodb_jobdb_assetpath_mtime_readunits = int(config['AWS']['dynamodb_jobdb_assetpath_mtime_readunits'])
    dynamodb_jobdb_error_mtime_index_readunits = int(config['AWS']['dynamodb_jobdb_error_mtime_index_readunits'])
    dynamodb_jobdb_incomplete_mtime_index_readunits = int(config['AWS']['dynamodb_jobdb_incomplete_mtime_index_readunits'])
    dynamodb_jobdb_writeunits = int(config['AWS']['dynamodb_jobdb_writeunits'])

    ec2_instance_cidr_tmpl = config['AWS']['ec2_instance_cidr_tmpl']  # 50 in dev, stage; 60 in prod

    asg_avail_api_min = config['AWS']['asg_avail_api_min']
    asg_avail_api_max = config['AWS']['asg_avail_api_max']
    asg_avail_imageresizer_min = config['AWS']['asg_avail_imageresizer_min']
    asg_avail_imageresizer_max = config['AWS']['asg_avail_imageresizer_max']
    asg_avail_pipeline_min = config['AWS']['asg_avail_pipeline_min']
    asg_avail_pipeline_max = config['AWS']['asg_avail_pipeline_max']

    elb_avail_api = config['AWS']['elb_avail_api']
    elb_avail_api_healthcheck = config['AWS']['elb_avail_api_healthcheck']
    elb_avail_api_ssl_id = awacs.acm.ARN(region=aws_region, account=aws_account, resource=config['AWS']['elb_avail_api_ssl_id']).JSONrepr()

    elb_avail_imageresizer = config['AWS']['elb_avail_imageresizer']
    elb_avail_imageresizer_healthcheck = config['AWS']['elb_avail_imageresizer_healthcheck']
    elb_avail_pipeline = config['AWS']['elb_avail_pipeline']
    elb_avail_pipeline_healthcheck = config['AWS']['elb_avail_pipeline_healthcheck']

    route53_zone_name = config['AWS']['route53_zone_name']

    route53_images_api_elb = config['AWS']['route53_images_api_elb']
    route53_images_api_r53_name = config['AWS']['route53_images_api_r53_name']
    route53_imageresizer_elb = config['AWS']['route53_imageresizer_elb']
    route53_pipeline_elb = config['AWS']['route53_pipeline_elb']
    route53_images_bucket = config['AWS']['route53_images_bucket']
    route53_images_assets_bucket = config['AWS']['route53_images_assets_bucket']
    route53_admin_bucket = config['AWS']['route53_admin_bucket']

    if op_env in ('stage', 'prod'):
        cloudfront_images_admin_identity = config['AWS']['cloudfront_images_admin_identity']
        cloudfront_images_assets_identity = config['AWS']['cloudfront_images_assets_identity']
        cloudfront_images_identity = config['AWS']['cloudfront_images_identity']

    api_instance_type = config['AWS']['api_instance_type']
    imageresizer_instance_type = config['AWS']['imageresizer_instance_type']
    pipeline_instance_type = config['AWS']['pipeline_instance_type']

    sqs_queues = {}
    for name, awsname in config['SQS_QUEUES'].items():
        sqs_queues[name] = awsname
    sqs_deadletter_name = config['AWS']['sqs_deadletter_name']

    if op_env == 'dev':
        source_vpc_endpoint = config['AWS']['source_vpc_endpoint']

    s3_private = config['AWS']['s3_private_bucket_name']
    s3_images = config['AWS']['s3_images_bucket_name']
    s3_images_assets = config['AWS']['s3_images_assets_bucket_name']
    s3_images_admin = config['AWS']['s3_images_admin_bucket_name']
    s3_logging_name = config['AWS']['s3_logging_name']
    s3_logging_prefix = config['AWS']['s3_logging_prefix']

    # From earl prod: DNS name in .nasawestprime for bucket in .nasa.gov
    s3_images_r53 = config['AWS']['s3_images_r53_name']  # should be route53_*
    s3_images_admin_r53 = config['AWS']['s3_images_admin_r53_name']  # should be route53_*
    s3_images_assets_r53 = config['AWS']['s3_images_assets_r53_name']  # should be route53_*

    # Too much interdependency with bamboo.sh paths

    ec2_tarball_api_file = "avail_api.tgz"
    ec2_tarball_api_url = (ec2_tarball_url_base + "avail_api/" + op_env + "/latest/" +
                           ec2_tarball_api_file)
    ec2_tarball_api_sh = "misc/bootstrap_api.sh"
    ec2_tarball_imageresizer_file = "avail_imageresizer.tgz"
    ec2_tarball_imageresizer_url = (ec2_tarball_url_base +
                                    "avail_imageresizer/" + op_env + "/latest/" +
                                    ec2_tarball_imageresizer_file)
    ec2_tarball_imageresizer_sh = "misc/bootstrap_imageresizer.sh"
    ec2_tarball_pipeline_file = "avail_pipeline.tgz"
    ec2_tarball_pipeline_url = (ec2_tarball_url_base +
                                "avail_pipeline/" + op_env + "/latest/" +
                                ec2_tarball_pipeline_file)
    ec2_tarball_pipeline_sh = "misc/bootstrap_pipeline.sh"
    ec2_tarball_build_dir = "/avail_build"

    any_cidr_block = "0.0.0.0/0"    # for security groups
    vpn_cidr_block = "156.68.0.0/16"  # same as production
    vpc_cidr_block = "10.1.0.0/16"  # same as production

    if op_env == 'dev':
        az_map = {0: "us-east-1d", 1: "us-east-1e"}
    else:
        az_map = {0: "us-east-1b", 1: "us-east-1c"}

    if op_env == 'dev':
        friendly_pub_cidr_blocks = [
            "156.68.0.0/16", # NASA NE Teleworker VPN
            "131.182.0.0/16" # NASA HQ VPN
        ]
    else:
        friendly_pub_cidr_blocks = [
            # NASAVPN
            "156.68.0.0/16", # NASA NE Teleworker VPN
            "131.182.0.0/16", # NASA HQ VPN
            # WESTPrime AWS PubVPC Proxies
            "54.165.92.217/32",
            "54.172.48.46/32",
        ]

    subnet_map = {
        "infra1":   {"subnet": 0, "az": az_map[0], "rtr": "igw",
                     "name": "Infrastructure"},
        "infra2":   {"subnet": 1, "az": az_map[1], "rtr": "igw",
                     "name": "Infrastructure"},
        "webapi1":  {"subnet": 2, "az": az_map[0], "rtr": "igw",
                     "name": "Web/API (accessible)"},
        "webapi2":  {"subnet": 3, "az": az_map[1], "rtr": "igw",
                     "name": "Web/API (accessible)"},
        "app1":     {"subnet": 4, "az": az_map[0], "rtr": "nat",
                     "name": "App (private)"},
        "app2":     {"subnet": 5, "az": az_map[1], "rtr": "nat",
                     "name": "App (private)"},
        "db1":      {"subnet": 6, "az": az_map[0], "rtr": "nat",
                     "name": "DB (private)"},
        "db2":      {"subnet": 7, "az": az_map[1], "rtr": "nat",
                     "name": "DB (private)"},
    }
    if op_env == 'dev':
        subnet_map.update({
            "tbd1":     {"subnet": 8, "az": az_map[0], "rtr": None,
                         "name": "TBD"},
            "tbd2":     {"subnet": 9, "az": az_map[1], "rtr": None,
                         "name": "TBD"},
        })

    # public_subnets = ["webapi1", "webapi2"]

    nasa_subnet_map = {
        "nasa":     ["128.102.0.0/16", "128.149.0.0/16", "128.154.0.0/15",
                     "128.156.0.0/14", "128.183.0.0/16", "129.164.0.0/17",
                     "130.40.0.0/16", "130.134.0.0/15", "131.110.27.11/32",
                     "131.182.0.0/16", "137.78.0.0/16", "137.79.128.0/24",
                     "138.76.32.0/20", "139.88.0.0/16", "139.169.0.0/16",
                     "143.232.0.0/16", "146.165.0.0/16", "148.114.0.0/16",
                     "156.68.0.0/16", "163.205.0.0/16", "163.206.0.0/16",
                     "192.42.77.10/32", "192.77.77.0/24", "192.94.65.32/27",
                     "192.138.85.41/32", "192.138.85.42/31", "192.138.85.45/32",
                     "192.138.85.49/32", "192.149.0.0/16",
                     "198.116.110.100/31", "198.117.0.0/16",
                     "198.118.127.126/32", "198.118.127.177/32",
                     "198.119.0.0/16", "198.123.7.140/32"],
    }

    ec2_instance_name_tmpl = "AVAIL {} TIER, az {}"

    ###########################################################################
    # Start the template

    t = Template()
    t.add_version("2010-09-09")
    if op_env == 'dev':
        t.add_description("AVAIL Dev creates VPC, IGW, NAT, RouteTable, DefaultRoute, to simulate WESTPrime PubVPC;" +
                          "Deploys EC2, SQS, S3, ...")
    if op_env == 'stage':
        t.add_description("AVAIL Stage Environment in WESTPrime PubVPC, subnets, routes; " +
                          "Deploys EC2, SQS, S3, ...")
    if op_env == 'prod':
        t.add_description("AVAIL Production Environment in WESTPrime PubVPC, subnets, routes; " +
                          "Deploys EC2, SQS, S3, ...")

    ###########################################################################
    # WESTPrime Infrastructure

    # WESTPrime PubVPC VPC ID
    wp_vpc_id = "vpc-ec55a38d"
    # WESTPrime PubVPC Internet Gateway ID
    wp_igw_id = "igw-c334f4a2"
    # WESTPrime PubVPC NAT Instance ID
    wp_nat_id = "eni-e415c785"
    # WESTPrime Default IGW Route
    wp_route_igw = "rtb-c036f6a1"
    # WESTPrime Default NAT Route
    wp_route_nat = "rtb-3a6eae5b"
    # WESTPrime PubVPC SG SSH From Bastions
    wp_sg_ssh_from_bastions = "sg-7a13d204"
    # WESTPrime PubVPC SG Allow_HTTP From Everywhere
    wp_sg_http_from_all = "sg-4f8e2d20"
    # WESTPrime PubVPC SG Allow_HTTPS From Everywhere
    wp_sg_https_from_all = "sg-5d8e2d32"
    # WESTPrime PubVPC SG Allow_HTTPS From CloudFront CDN
    wp_sg_https_from_cdn_1 = "sg-80468aca"
    wp_sg_https_from_cdn_2 = "sg-889ff2c0"


    ###########################################################################
    # Parameters

    # NAT

    # DynamoDB for jobstate tracking

    p_jobstate_readunits = t.add_parameter(
        Parameter(
            "JobStateReadUnits",
            Description="Provisioned read throughput",
            Type="Number",
            Default="5",
            MinValue="5",
            MaxValue="10000",
            ConstraintDescription="should be between 5 and 10000"
        ))

    p_jobstate_primary_hashkeyname = t.add_parameter(
        Parameter(
            "JobStatePrimaryHashKeyName",
            Description="Item attr to use as primary key hash attribute.",
            Type="String",
            Default="job",  # see: avail.job.Job
            AllowedPattern="[a-zA-Z0-9]*",
            MinLength="1",
            MaxLength="2048",
            ConstraintDescription="must contain only alphanumberic characters"
        ))

    p_jobstate_primary_hashkeytype = t.add_parameter(
        Parameter(
            "JobStatePrimaryHashKeyType",
            Description="Type of attr being used as primary key hash attr",
            Type="String",
            Default="S",
            AllowedPattern="[S|N]",
            MinLength="1",
            MaxLength="1",
            ConstraintDescription="must be either S or N"
        ))

    p_jobstate_primary_rangekeyname = t.add_parameter(
        Parameter(
            "JobStatePrimaryRangeKeyName",
            Description="Item attr to use as primary key range attribute.",
            Type="String",
            Default="mtime",  # see: avail.job.Job
            MinLength="1",
            MaxLength="2048",
            ConstraintDescription="may contain any string chars (timestamp)"
        ))

    p_jobstate_primary_rangekeytype = t.add_parameter(
        Parameter(
            "JobStatePrimaryRangeKeyType",
            Description="Type of attr being used as primary key range attr",
            Type="String",
            Default="S",
            AllowedPattern="[S|N]",
            MinLength="1",
            MaxLength="1",
            ConstraintDescription="must be either S or N"
        ))

    p_jobstate_gsi1_hashkeyname = t.add_parameter(
        Parameter(
            "JobStateGSI1HashKeyName",
            Description="Item attr to use as 1st GSI's hash attribute.",
            Type="String",
            Default="error",  # see: avail.job.Job
            AllowedPattern="[a-zA-Z]*",
            MinLength="1",
            MaxLength="2048",
            ConstraintDescription="must contain only alphabetical characters"
        ))

    p_jobstate_gsi1_hashkeytype = t.add_parameter(
        Parameter(
            "JobStateGSI1HashKeyType",
            Description="Type of attr being used as 1st GSI's hash attribute.",
            Type="String",
            Default="N",
            AllowedPattern="N",
            MinLength="1",
            MaxLength="1",
            ConstraintDescription="must be N"
        ))

    p_jobstate_gsi1_rangekeyname = t.add_parameter(
        Parameter(
            "JobStateGSI1RangeKeyName",
            Description="Item attr to use as 1st GSI's range attribute.",
            Type="String",
            Default="mtime",  # see: avail.job.Job
            MinLength="1",
            MaxLength="2048",
            ConstraintDescription="may contain any string chars (timestamp)"
        ))

    p_jobstate_gsi1_rangekeytype = t.add_parameter(
        Parameter(
            "JobStateGSI1RangeKeyType",
            Description="Type of attr being used as 1st GSI's range attr",
            Type="String",
            Default="S",
            AllowedPattern="S",
            MinLength="1",
            MaxLength="1",
            ConstraintDescription="must be S"
        ))

    p_jobstate_gsi2_hashkeyname = t.add_parameter(
        Parameter(
            "JobStateGSI2HashKeyName",
            Description="Item attr to use as 2nd GSI's hash attribute.",
            Type="String",
            Default="assetPath",  # see: avail.job.Job
            MinLength="1",
            MaxLength="2048",
            ConstraintDescription="may contain any string chars (filename)"
        ))

    p_jobstate_gsi2_hashkeytype = t.add_parameter(
        Parameter(
            "JobStateGSI2HashKeyType",
            Description="Type of attr being used as 2nd GSI's hash attribute.",
            Type="String",
            Default="S",
            AllowedPattern="[S|N]",
            MinLength="1",
            MaxLength="1",
            ConstraintDescription="must be either S or N"
        ))

    p_jobstate_gsi2_rangekeyname = t.add_parameter(
        Parameter(
            "JobStateGSI2RangeKeyName",
            Description="Item attr to use as 2nd GSI's range attribute.",
            Type="String",
            Default="mtime",  # see: avail.job.Job
            MinLength="1",
            MaxLength="2048",
            ConstraintDescription="may contain any string chars (timestamp)"
        ))

    p_jobstate_gsi2_rangekeytype = t.add_parameter(
        Parameter(
            "JobStateGSI2RangeKeyType",
            Description="Type of attr being used as 2nd GSI's range attr",
            Type="String",
            Default="S",
            AllowedPattern="S",
            MinLength="1",
            MaxLength="1",
            ConstraintDescription="must be S"
        ))

    p_jobstate_gsi3_hashkeyname = t.add_parameter(
        Parameter(
            "JobStateGSI3HashKeyName",
            Description="Item attr to use as 3rd GSI's hash attribute.",
            Type="String",
            Default="incomplete",  # see: avail.job.Job
            MinLength="10",
            MaxLength="10",
            ConstraintDescription="may contain any string chars (filename)"
        ))

    p_jobstate_gsi3_hashkeytype = t.add_parameter(
        Parameter(
            "JobStateGSI3HashKeyType",
            Description="Type of attr being used as 3rd GSI's hash attribute.",
            Type="String",
            Default="N",
            AllowedPattern="N",
            MinLength="1",
            MaxLength="1",
            ConstraintDescription="must be N"
        ))

    p_jobstate_gsi3_rangekeyname = t.add_parameter(
        Parameter(
            "JobStateGSI3RangeKeyName",
            Description="Item attr to use as 3rd GSI's range attribute.",
            Type="String",
            Default="mtime",  # see: avail.job.Job
            MinLength="1",
            MaxLength="2048",
            ConstraintDescription="may contain any string chars (timestamp)"
        ))

    p_jobstate_gsi3_rangekeytype = t.add_parameter(
        Parameter(
            "JobStateGSI3RangeKeyType",
            Description="Type of attr being used as 3rd GSI's range attr",
            Type="String",
            Default="S",
            AllowedPattern="S",
            MinLength="1",
            MaxLength="1",
            ConstraintDescription="must be S"
        ))

    ################
    #  DynamoDB for asset tracking

    p_asset_primary_hashkeyname = t.add_parameter(
        Parameter(
            "AssetPrimaryHashKeyName",
            Description="Item attr to use as primary key hash attribute.",
            Type="String",
            Default="nasaId",
            AllowedPattern="[a-zA-Z0-9]*",
            MinLength="1",
            MaxLength="2048",
            ConstraintDescription="must contain only alphanumberic characters"
            ))

    p_asset_primary_hashkeytype = t.add_parameter(
        Parameter(
            "AssetPrimaryHashKeyType",
            Description="Type of attr being used as primary key hash attr",
            Type="String",
            Default="S",
            AllowedPattern="[S|N]",
            MinLength="1",
            MaxLength="1",
            ConstraintDescription="must be either S or N"))

    p_asset_gsi1_hashkeyname = t.add_parameter(
        Parameter(
            "AssetGSI1HashKeyName",
            Description="Item attr to use as 1st GSI's hash attribute.",
            Type="String",
            Default="deletedId",
            AllowedPattern="[a-zA-Z]*",
            MinLength="1",
            MaxLength="2048",
            ConstraintDescription="must contain only alphabetical characters"))

    p_asset_gsi1_hashkeytype = t.add_parameter(
        Parameter(
            "AssetGSI1HashKeyType",
            Description="Type of attr being used as 1st GSI's hash attribute.",
            Type="String",
            Default="S",
            AllowedPattern="[S|N]",
            MinLength="1",
            MaxLength="1",
            ConstraintDescription="must be either S or N"))

    p_asset_gsi1_rangekeyname = t.add_parameter(
        Parameter(
            "AssetGSI1RangeKeyName",
            Description="Item attr to use as 1st GSI's range attribute.",
            Type="String",
            Default="mtime",  # see: avail.asset.Asset
            MinLength="1",
            MaxLength="2048",
            ConstraintDescription="may contain any string chars (timestamp)"
        ))

    p_asset_gsi1_rangekeytype = t.add_parameter(
        Parameter(
            "AssetGSI1RangeKeyType",
            Description="Type of attr being used as 1st GSI's range attr.",
            Type="String",
            Default="S",
            AllowedPattern="[S|N]",
            MinLength="1",
            MaxLength="1",
            ConstraintDescription="must be either S or N"
        ))

    p_asset_gsi2_hashkeyname = t.add_parameter(
        Parameter(
            "AssetGSI2HashKeyName",
            Description="Item attr to use as 2nd GSI's hash attribute.",
            Type="String",
            Default="assetPrefix",
            MinLength="1",
            MaxLength="2048",
            ConstraintDescription="may contain any string chars (filename)"))

    p_asset_gsi2_hashkeytype = t.add_parameter(
        Parameter(
            "AssetGSI2HashKeyType",
            Description="Type of attr being used as 2nd GSI's hash attribute.",
            Type="String",
            Default="S",
            AllowedPattern="[S|N]",
            MinLength="1",
            MaxLength="1",
            ConstraintDescription="must be either S or N"))

    p_asset_gsi3_hashkeyname = t.add_parameter(
        Parameter(
            "AssetGSI3HashKeyName",
            Description="Item attr to use as 2nd GSI's hash attribute.",
            Type="String",
            Default="mediaType",
            MinLength="1",
            MaxLength="2048",
            ConstraintDescription="may contain any string chars (filename)"))

    p_asset_gsi3_hashkeytype = t.add_parameter(
        Parameter(
            "AssetGSI3HashKeyType",
            Description="Type of attr being used as 2nd GSI's hash attribute.",
            Type="String",
            Default="S",
            AllowedPattern="[S|N]",
            MinLength="1",
            MaxLength="1",
            ConstraintDescription="must be either S or N"))
    # Misc

    p_keyname = t.add_parameter(
        Parameter(
            "KeyName",
            ConstraintDescription="must be name of an existing eC2 KeyPair",
            Description=(
                "Name of existing EC2 KeyPair to enable SSH to instance"),
            Type="AWS::EC2::KeyPair::KeyName",
        ))

    p_scale_notification_email_1 = t.add_parameter(
        Parameter(
            "ScaleNotificationEmail1",
            ConstraintDescription="must be valid email address",
            Description="Email address to send scale event notifications",
            Type="String",
            Default="chris@v-studios.com",
        ))

    p_scale_notification_email_2 = t.add_parameter(
        Parameter(
            "ScaleNotificationEmail2",
            ConstraintDescription="must be valid email address",
            Description="Email address to send scale event notifications",
            Type="String",
            Default="jason.g.miller@nasa.gov",
        ))

    p_sshlocation = t.add_parameter(
        Parameter(
            "SSHLocation",
            Description=(
                "IP address range that can be used to SSH to instances"),
            Type="String",
            MinLength="9",
            MaxLength="18",
            Default=vpn_cidr_block,
            AllowedPattern=(
                "(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})/(\d{1,2})"),
            ConstraintDescription=(
                "must be a valid IP CIDR range of the form x.x.x.x/x."),
        ))

    ###########################################################################
    # Resources: network infrastructure: VPC, IGW, NAT GW, Routes, Subnets, SGs

    # VPC
    if op_env == 'dev':
        r_vpc = t.add_resource(
            ec2.VPC(
                "VPC",
                CidrBlock=vpc_cidr_block,
                EnableDnsHostnames=True,
                Tags=Tags(
                    Name="AVAIL-dev",
                    Application="AVAIL",
                    ApplicationID="AVAIL",
                    BillingID="NIEM.62HP27",
                    WorkOrder="WP-430-WO-AVAIL-00001",
                    cloud_env="pubvpc",
                    op_env=op_env_tag,
                    customer="NIEP",
                    owner="Rodney Grubbs",
                    site="images.nasa.gov",
                )
            ))

    else:
        r_vpc = t.add_parameter(
            Parameter(
                "VPC",
                Description="WESTPrime PubVPC VPC ID",
                Type="String",
                Default=wp_vpc_id,
                )
        )

    # Security Groups

    # Security Group : HTTPS access from all NASA Centers
    # subnets defined in NASA_SUBNET_MAP
    # We only create subnets and the HTTP(S) SGs in Dev; use existing in stage/prod
    if op_env == 'dev':

        r_sgr_all_nasa_subnets_https = []

        for s, attr in nasa_subnet_map.items():
           # Security Group : HTTPS access from all NASA Centers
            for cidrnets in attr:
                r_sgr_all_nasa_subnets_https.append(
                    ec2.SecurityGroupRule(
                        Description="Allow HTTPS from NASA Centers",
                        IpProtocol="tcp",
                        FromPort=443,
                        ToPort=443,
                        CidrIp=cidrnets,
                    )
                )

        r_sg_vpc_all = t.add_resource(
            ec2.SecurityGroup(
                "AllowAllFromVPC",
                GroupDescription="Allow All from our VPC",
                SecurityGroupIngress=[
                    ec2.SecurityGroupRule(
                        IpProtocol="tcp",
                        FromPort=1,
                        ToPort=65535,
                        CidrIp=vpc_cidr_block,
                    )
                ],
                VpcId=Ref(r_vpc),
            ))

    r_sg_api_elb_healthcheck = t.add_resource(
        ec2.SecurityGroup(
            "APIELBHealthCheck",
            GroupName=Join("-", ["avail-api-elb-1", op_env, "pubvpc"]),
            GroupDescription="Allow HTTP via port 7890 for API ELB HealthCheck",
            VpcId=Ref(r_vpc)
        ))

    r_sg_api_ec2_healthcheck_from_elb = t.add_resource(
        ec2.SecurityGroup(
            "AllowHTTPSHealthCheckFromAPIELB",
            GroupDescription="Allow HTTPS + HealthCheck from API ELB on port 7890",
            GroupName=Join("-", ["avail-api-ec2-1", op_env, "pubvpc"]),
            SecurityGroupIngress=[
                 ec2.SecurityGroupRule(
                    Description="Allow HTTPS from API ELB on port 443",
                    IpProtocol="tcp",
                    FromPort="443",
                    ToPort="443",
                    SourceSecurityGroupId=Ref(r_sg_api_elb_healthcheck),
                ),
                ec2.SecurityGroupRule(
                    Description="Allow HealthCheck from API ELB on port 7890",
                    IpProtocol="tcp",
                    FromPort="7890",
                    ToPort="7890",
                    SourceSecurityGroupId=Ref(r_sg_api_elb_healthcheck),
                )
            ],
            VpcId=Ref(r_vpc)
        ))

    if ( op_env == "stage" ) or ( op_env == "prod"):

        r_sg_api_from_proxy_a = t.add_resource(
            ec2.SecurityGroupIngress(
                "APIELBAllowHTTPSFromPipelineEC2ViaProxyA",
                Description="Allow HTTPS to API ELB from Pipeline EC2 on port 443, through PubVPC Proxy A",
                GroupId=Ref(r_sg_api_elb_healthcheck),
                IpProtocol="tcp",
                FromPort="443",
                ToPort="443",
                CidrIp="54.165.92.217/32",
            ))

        r_sg_api_from_proxy_b = t.add_resource(
            ec2.SecurityGroupIngress(
                "APIELBAllowHTTPSFromPipelineEC2ViaProxyB",
                Description="Allow HTTPS to API ELB from Pipeline EC2 on port 443, through PubVPC Proxy B",
                GroupId=Ref(r_sg_api_elb_healthcheck),
                IpProtocol="tcp",
                FromPort="443",
                ToPort="443",
                CidrIp="54.172.48.46/32",
            ))

    r_sg_resizer_elb_healthcheck = t.add_resource(
        ec2.SecurityGroup(
            "ResizerELBHealthCheck",
            GroupName=Join("-", ["avail-resizer-elb-1", op_env, "pubvpc"]),
            GroupDescription="Allow HTTP via port 7890 for Resizer ELB HealthCheck",
            SecurityGroupIngress=[
                ec2.SecurityGroupRule(
                    Description="Allow HTTP to Resizer ELB from API EC2 on port 80",
                    IpProtocol="tcp",
                    FromPort="80",
                    ToPort="80",
                    SourceSecurityGroupId=Ref(r_sg_api_ec2_healthcheck_from_elb),
               ),
            ],
            VpcId=Ref(r_vpc)
        ))

    r_sg_resizer_ec2_healthcheck_from_elb = t.add_resource(
        ec2.SecurityGroup(
            "AllowHealthCheckFromResizerELB",
            GroupDescription="Allow HealthCheck from Resizer ELB on port 7890",
            GroupName=Join("-", ["avail-resizer-ec2-1", op_env, "pubvpc"]),
            SecurityGroupIngress=[
                ec2.SecurityGroupRule(
                    Description="Allow HealthCheck from Resizer ELB on port 7890",
                    IpProtocol="tcp",
                    FromPort="7890",
                    ToPort="7890",
                    SourceSecurityGroupId=Ref(r_sg_resizer_elb_healthcheck),
                )
            ],
            VpcId=Ref(r_vpc)
        ))

    r_sg_resizer_ec2_ingress = t.add_resource(
        ec2.SecurityGroupIngress(
            "ResizerEC2HTTPIngress",
            Description="Allow HTTP from Resizer ELB on port 80",
            GroupId=Ref(r_sg_resizer_ec2_healthcheck_from_elb),
            IpProtocol="tcp",
            FromPort="80",
            ToPort="80",
            SourceSecurityGroupId=Ref(r_sg_resizer_elb_healthcheck),
        ))

    r_sg_pipeline_elb_healthcheck = t.add_resource(
        ec2.SecurityGroup(
            "PipelineELBHealthCheck",
            GroupName=Join("-", ["avail-pipeline-elb-1", op_env, "pubvpc"]),
            GroupDescription="Allow HTTP via port 7890 for Pipeline ELB HealthCheck",
            VpcId=Ref(r_vpc)
        ))

    r_sg_pipeline_ec2_healthcheck_from_elb = t.add_resource(
        ec2.SecurityGroup(
            "AllowHealthCheckFromPipelineELB",
            GroupDescription="Allow HealthCheck from Pipeline ELB on port 7890",
            GroupName=Join("-", ["avail-pipeline-ec2-1", op_env, "pubvpc"]),
            SecurityGroupIngress=[
                ec2.SecurityGroupRule(
                    Description="Allow HealthCheck from Pipeline ELB on port 7890",
                    IpProtocol="tcp",
                    FromPort="7890",
                    ToPort="7890",
                    SourceSecurityGroupId=Ref(r_sg_pipeline_elb_healthcheck),
                )
            ],
            VpcId=Ref(r_vpc)
        ))

    r_sg_resizer_ec2_ingress = t.add_resource(
        ec2.SecurityGroupIngress(
            "ResizerELBAllowHTTPFromPipelineEC2",
            Description="Allow HTTP to Resizer ELB from Pipeline EC2 on port 80",
            GroupId=Ref(r_sg_resizer_elb_healthcheck),
            IpProtocol="tcp",
            FromPort="80",
            ToPort="80",
            SourceSecurityGroupId=Ref(r_sg_pipeline_ec2_healthcheck_from_elb),
        )),

    if op_env == 'dev':

        r_sg_ssh_ingress = []

        r_sg_ssh = t.add_resource(
            ec2.SecurityGroup(
                "AllowSSH",
                GroupDescription="Enable SSH access via port 22",
                SecurityGroupIngress=r_sg_ssh_ingress,
                VpcId=Ref(r_vpc)
            ))

        r_sg_ssh_ingress.append(
            ec2.SecurityGroupRule(
                Description="Allow SSH from NASA VPN on port 22",
                IpProtocol="tcp",
                FromPort="22",
                ToPort="22",
                CidrIp=Ref(p_sshlocation),
            ))

        r_sg_ssh_from_nat_instance = t.add_resource(
            ec2.SecurityGroupIngress(
                "AllowSSHFromNATInstance",
                Description="Allow SSH from Bastions on port 22",
                IpProtocol="tcp",
                FromPort="22",
                ToPort="22",
                SourceSecurityGroupId=Ref(r_sg_ssh),
                GroupId=Ref(r_sg_ssh),
            ))

        r_sg_https_from_cdn = t.add_resource(
            ec2.SecurityGroup(
                "AllowHTTPSFromCDN",
                GroupDescription="Allow HTTPS From CDN",
                GroupName=Join("-", ["avail-cdn-https-elb-1", op_env, "pubvpc"]),
                SecurityGroupIngress=r_sgr_all_nasa_subnets_https,
                VpcId=Ref(r_vpc),
            ))

        r_api_elb_sgs = [
            Ref(r_sg_api_elb_healthcheck),
            Ref(r_sg_https_from_cdn)
        ]

    else:
        r_sg_ssh = t.add_parameter(
            Parameter(
                "AllowSSH",
                Description="WESTPrime PubVPC SG SSH From Bastions",
                Type="String",
                Default=wp_sg_ssh_from_bastions,
            ))

        r_sg_https_from_cdn_1 = t.add_parameter(
            Parameter(
                "WPAllowHTTPSFromCDN1",
                Description="WESTPrime PubVPC SG Allow_HTTPS From CDN",
                Type="String",
                Default=wp_sg_https_from_cdn_1,
            ))

        r_sg_https_from_cdn_2 = t.add_parameter(
            Parameter(
                "WPAllowHTTPSFromCDN2",
                Description="WESTPrime PubVPC SG Allow_HTTPS From CDN",
                Type="String",
                Default=wp_sg_https_from_cdn_2,
            ))

        r_api_elb_sgs = [
            Ref(r_sg_api_elb_healthcheck),
            Ref(r_sg_https_from_cdn_1),
            Ref(r_sg_https_from_cdn_2)
        ]


    # Internet Gateway (for public resources)
    # TODO: conditionalize this: if in .ini, use; if not, create and use
    # TODO: this looks broken: nothing in the Dev IGW but tags!
    if op_env == 'dev':
        r_igw_gateway = t.add_resource(
            ec2.InternetGateway(
                "InternetGateway",
                Tags=Tags(
                    Name="AVAIL VPC Internet Gateway",
                    Application="AVAIL",
                    ApplicationID="AVAIL",
                    BillingID="NIEM.62HP27",
                    WorkOrder="WP-430-WO-AVAIL-00001",
                    cloud_env="pubvpc",
                    op_env=op_env_tag,
                    customer="NIEP",
                    owner="Rodney Grubbs",
                    site="images.nasa.gov",
                    ),
                ))
    else:
        t.add_parameter(  # TODO: where is this used?
            Parameter(
                "InternetGateway",
                Description="WESTPrime PubVPC Internet Gateway ID",
                Type="String",
                Default=wp_igw_id,
            )
        )

    if op_env == 'dev':
        # Unused variable: r_igw_attachment =
        t.add_resource(
            ec2.VPCGatewayAttachment(
                "AttachGateway",
                InternetGatewayId=Ref(r_igw_gateway),
                VpcId=Ref(r_vpc),
            ))

        r_igw_route_table = t.add_resource(
            ec2.RouteTable(
                "IGWRouteTable",
                Tags=Tags(
                    Name="AVAIL Default through IGW for Public",
                    Application="AVAIL",
                    ApplicationID="AVAIL",
                    BillingID="NIEM.62HP27",
                    WorkOrder="WP-430-WO-AVAIL-00001",
                    cloud_env="pubvpc",
                    op_env=op_env_tag,
                    customer="NIEP",
                    owner="Rodney Grubbs",
                    site="images.nasa.gov",
                    ),
                VpcId=Ref(r_vpc),
            ))

        # Unused: r_igw_default_route =
        t.add_resource(
            ec2.Route(
                "DefaultRoute",
                DependsOn="AttachGateway",
                GatewayId=Ref(r_igw_gateway),
                DestinationCidrBlock="0.0.0.0/0",
                RouteTableId=Ref(r_igw_route_table),
            ))

    else:
        r_igw_route_table = t.add_parameter(
            Parameter(
                "IGWRouteTable",
                Description="WESTPrime Default IGW Route",
                Type="String",
                Default=wp_route_igw,
            ))

    # Subnets

    r_subnets = {}
    for s, attr in subnet_map.items():
        r_subnets[s] = t.add_resource(
            ec2.Subnet(
                s,                      # CF logical ID
                AvailabilityZone=attr["az"],
                CidrBlock=ec2_instance_cidr_tmpl.format(attr["subnet"]),
                Tags=Tags(
                    Name=ec2_instance_name_tmpl.format(
                        attr["name"], attr["az"]),
                    Application="AVAIL",
                    ApplicationID="AVAIL",
                    BillingID="NIEM.62HP27",
                    WorkOrder="WP-430-WO-AVAIL-00001",
                    cloud_env="pubvpc",
                    op_env=op_env_tag,
                    customer="NIEP",
                    owner="Rodney Grubbs",
                    site="images.nasa.gov"),
                VpcId=Ref(r_vpc),
            ))

    # NAT instance and routing for Private subnets
    # We have to crate the subnets before we can create the NAT,
    # then we can create the NAT route table, and finally
    # associate subnets with it.

    if op_env == 'dev':
        r_nat_instance = t.add_resource(
            ec2.Instance(
                "NATInstance",
                ImageId=ami_id,
                InstanceType="t2.micro",
                KeyName=Ref(p_keyname),
                NetworkInterfaces=[
                    ec2.NetworkInterfaceProperty(
                        AssociatePublicIpAddress=True,
                        Description="NATs need a public IP",
                        DeviceIndex="0",
                        GroupSet=[Ref(r_sg_ssh),
                                  Ref(r_sg_vpc_all)],
                        SubnetId=Ref(r_subnets["infra1"]),
                    ),
                ],
                SourceDestCheck=False,  # required for NAT
                Tags=Tags(
                    Name="AVAIL NAT GW",
                    Application="AVAIL",
                    ApplicationID="AVAIL",
                    BillingID="NIEM.62HP27",
                    WorkOrder="WP-430-WO-AVAIL-00001",
                    cloud_env="pubvpc",
                    op_env=op_env_tag,
                    customer="NIEP",
                    owner="Rodney Grubbs",
                    role="routing",         # is there a better name?
                    site="images.nasa.gov",
                    tech_stack="network",
                ),
                UserData=Base64(Join('', [
                    "#!/bin/bash -xe\n",
                    "apt-get -y remove ansible\n",
                    "apt-get -y install python-pip\n",
                    "echo 1 > /proc/sys/net/ipv4/ip_forward\n",
                    "iptables -t nat -A POSTROUTING -o eth0 -s 10.1.0.0/16 -j MASQUERADE\n",
                    "pip install ansible==2.1.5.0\n",
                    "mkdir {}\n".format(ec2_tarball_build_dir),
                    "cd {}\n".format(ec2_tarball_build_dir),
                    "curl --location -o {} {}\n".format(ec2_tarball_api_file,
                                                        ec2_tarball_api_url),
                    "tar zxf {}\n".format(ec2_tarball_api_file),
                    "cd bootstrap/ansible\n",
                    "/usr/local/bin/ansible-playbook -i hosts -l avail_api setup.yml -t devops\n",
                ])),
            ))
        t.add_output([
            Output("NATDNS", Value=GetAtt(r_nat_instance, "PublicDnsName")),
            Output("NATIP",  Value=GetAtt(r_nat_instance, "PublicIp")),
        ])

        r_sg_api = t.add_resource(
            ec2.SecurityGroupIngress(
                "APIELBAllowHTTPSFromPipelineEC2",
                Description="Allow HTTPS to API ELB from Pipeline EC2 on port 443, through NAT",
                GroupId=Ref(r_sg_https_from_cdn),
                IpProtocol="tcp",
                FromPort="443",
                ToPort="443",
                CidrIp=Join("", [GetAtt(r_nat_instance, "PublicIp"), "/32"])
            )),

        r_nat_route_table = t.add_resource(
            ec2.RouteTable(
                "NATRouteTable",
                Tags=Tags(
                    Name="AVAIL Default through NAT for Private",
                    Application="AVAIL",
                    ApplicationID="AVAIL",
                    BillingID="NIEM.62HP27",
                    WorkOrder="WP-430-WO-AVAIL-00001",
                    cloud_env="pubvpc",
                    op_env=op_env_tag,
                    customer="NIEP",
                    owner="Rodney Grubbs",
                    site="images.nasa.gov",
                    ),
                VpcId=Ref(r_vpc),
            ))

        # Unused; r_nat_route_default =
        t.add_resource(
            ec2.Route(
                "NATDefaultRoute",
                InstanceId=Ref(r_nat_instance),
                DestinationCidrBlock="0.0.0.0/0",
                RouteTableId=Ref(r_nat_route_table),
            ))

    else:
        t.add_parameter(
            Parameter(
                "NATInstance",
                Description="WESTPrime PubVPC NAT Instance ID",
                Type="String",
                Default=wp_nat_id,
            ))

        r_nat_route_table = t.add_parameter(
            Parameter(
                "NATRouteTable",
                Description="WESTPrime Default NAT Route",
                Type="String",
                Default=wp_route_nat,
            ))

    for s, attr in subnet_map.items():
        if attr["rtr"] == "igw":
            # Unused: r_subnet_route_table_association =
            t.add_resource(
                ec2.SubnetRouteTableAssociation(
                    "{}IGW".format(s),
                    SubnetId=Ref(r_subnets[s]),
                    RouteTableId=Ref(r_igw_route_table),
                )
            )
        if attr["rtr"] == "nat":
            # Unused: r_subnet_route_table_association =
            t.add_resource(
                ec2.SubnetRouteTableAssociation(
                    "{}NAT".format(s),
                    SubnetId=Ref(r_subnets[s]),
                    RouteTableId=Ref(r_nat_route_table),
                )
            )

    ###########################################################################
    # SQS

    r_deadletter_queue = t.add_resource(
        sqs.Queue(
            "DeadLetterQueue",
            QueueName=sqs_deadletter_name,
        ))
    t.add_output([
        Output("DeadLetterQueueUrl", Value=Ref(r_deadletter_queue)),
        Output("DeadLetterQueueArn", Value=GetAtt(r_deadletter_queue, "Arn"))
    ])

    # We likely want to change AV/ET timeout to be long; how long?
    r_queues = {}
    for queue, awsname in sqs_queues.items():
        r_queues[queue] = t.add_resource(
            sqs.Queue(
                queue,
                QueueName=awsname,
                RedrivePolicy=sqs.RedrivePolicy(
                    deadLetterTargetArn=GetAtt(r_deadletter_queue, "Arn"),
                    maxReceiveCount="5",
                ),
                VisibilityTimeout=120,  # default=30
            ))
        t.add_output([
            Output(queue + "Url", Value=Ref(r_queues[queue])),
            Output(queue + "Arn", Value=GetAtt(r_queues[queue], "Arn"))
        ])

    # SQS Policy allowing S3 Private incoming tmp bucket to SendMessage

    r_uploaded_queue_policy = t.add_resource(
        sqs.QueuePolicy(
            "UploadedQueuePolicy",
            PolicyDocument=Policy(
                Version="2012-10-17",
                Statement=[
                    Statement(
                        Action=[awacs.sqs.SendMessage],
                        Condition=Condition(
                            ArnEquals(
                                SourceArn,
                                awacs.s3.ARN(s3_private)
                            )
                        ),
                        Effect=Allow,
                        Principal=AWSPrincipal(Everybody),
                        Resource=[GetAtt(r_queues["UploadedQueue"], "Arn")],
                        Sid=("Allow-S3-Incoming-Tmp-to-SendMessage-"
                             "to-SQS-Queue"),
                    ),
                ],
            ),
            Queues=[Ref(r_queues["UploadedQueue"])],
        )
    )
    t.add_output([
        Output("UploadedQueuePolicy", Value=Ref(r_uploaded_queue_policy))
    ])

    ###########################################################################
    # S3

    # Private: for incoming, want listing, but no read
    # We may want CORS, LifeCycle, NO? WebsiteConfiguration, ...
    # Need Bucket Policy to allow LIST to owner but need IAM Role
    #
    # Post CloudFormation -- which can't do this reliably -- we create an
    # SQS Notification on the bucket.

    r_s3_private = t.add_resource(
        s3.Bucket(
            "PrivateBucket",
            AccessControl=s3.BucketOwnerFullControl,
            BucketName=s3_private,
            CorsConfiguration=s3.CorsConfiguration(
                CorsRules=[
                    s3.CorsRules(
                        AllowedHeaders=["*"],
                        AllowedMethods=[
                            "PUT",
                            "POST",
                            "DELETE",
                            "GET",
                            "HEAD",
                        ],
                        AllowedOrigins=[
                            "*",
                        ],
                        ExposedHeaders=["ETag"],
                    )
                ]
            ),
            Tags=Tags(Name="AVAIL Private Assets",
                      Application="AVAIL",
                      ApplicationID="AVAIL",
                      BillingID="NIEM.62HP27",
                      # No funny chars allowed in
                      # com.amazon.aws.platform.billing.tagset.type.TagValue
                      WorkOrder="WP-430-WO-AVAIL-00001",
                      cloud_env="pubvpc",
                      op_env=op_env_tag,
                      customer="NIEP",
                      owner="Rodney Grubbs",
                      role="storage",
                      site="images.nasa.gov"),
            LoggingConfiguration=s3.LoggingConfiguration(
                DestinationBucketName=s3_logging_name,
                LogFilePrefix=s3_logging_prefix),
        ))
    t.add_output([
        Output("PrivateBucket", Value=Ref(r_s3_private)),
        Output("PrivateBucketArn",
               Value=Join("", ["arn:aws:s3:::", Ref(r_s3_private)])),
    ])

    r_s3_private_multipart_iam = t.add_resource(
        iam.User(
            "S3PrivateMultipartIAM",
    ))

    r_s3_private_bucket_policy = t.add_resource(
        s3.BucketPolicy(
            "S3PrivateBucketPolicy",
            Bucket=Ref(r_s3_private),
            PolicyDocument=Policy(
                Version="2012-10-17",  # needed for policy vars
                Statement=[
                    Statement(
                        Action=[
                            awacs.s3.Action("AbortMultipartUpload"),
                            awacs.s3.Action("ListMultipartUploadParts"),
                            awacs.s3.Action("GetObject"),
                            awacs.s3.Action("PutObject"),
                            awacs.s3.Action("PutObjectAcl"),
                        ],
                        Effect=Allow,
                        Principal=Principal("AWS", GetAtt(r_s3_private_multipart_iam, "Arn")),
                        Resource=[
                            awacs.s3.ARN(s3_private + "/*"),
                        ],
                        Sid="AVAILS3PrivateBucketPolicy",
                    ),
                ],
            ),
    ))

    # Public front end.

    r_s3_images = t.add_resource(
        s3.Bucket(
            "ImagesBucket",
            AccessControl=s3.BucketOwnerFullControl,
            BucketName=s3_images,
            CorsConfiguration=s3.CorsConfiguration(
                CorsRules=[
                    s3.CorsRules(
                        AllowedHeaders=["*"],
                        AllowedMethods=["GET"],
                        AllowedOrigins=["*"],
                    )
                ]
            ),
            Tags=Tags(Name="AVAIL Public Web Interface",
                      Application="AVAIL",
                      ApplicationID="AVAIL",
                      BillingID="NIEM.62HP27",
                      # No funny chars allowed in
                      # com.amazon.aws.platform.billing.tagset.type.TagValue
                      WorkOrder="WP-430-WO-AVAIL-00001",
                      cloud_env="pubvpc",
                      op_env=op_env_tag,
                      customer="NIEP",
                      owner="Rodney Grubbs",
                      role="storage",
                      site="images.nasa.gov"),
            VersioningConfiguration=s3.VersioningConfiguration(
                Status="Enabled"),
            WebsiteConfiguration=s3.WebsiteConfiguration(
                IndexDocument="index.html",
                ErrorDocument="index.html",
                ),
            LoggingConfiguration=s3.LoggingConfiguration(
                DestinationBucketName=s3_logging_name,
                LogFilePrefix=s3_logging_prefix),
    ))
    t.add_output(Output(
        "ImagesBucket", Value=Ref(r_s3_images)
    ))

    # FE bucket: dev points to S3, stage/prod must point to CDN
    route53_images_target = route53_images_bucket  # s3-website-us-east-1.amazonaws.com
    if 'route53_images_target' in config['AWS']:
        route53_images_target = config['AWS']['route53_images_target']
    r_r53_images_bucket_dns = t.add_resource(
        route53.RecordSetType(
            "ImagesBucketDNS",
            HostedZoneName=route53_zone_name,
            Comment="CNAME to the images FE Bucket or CDN",  # FE, not assets
            Name=s3_images_r53,
            Type="CNAME",
            TTL="300",
            ResourceRecords=[route53_images_target],
            ),
    )
    t.add_output(Output(
        "ImagesBucketDNS", Value=Ref(r_r53_images_bucket_dns)
    ))

    r_s3_images_admin = t.add_resource(
        s3.Bucket(
            "ImagesAdminBucket",
            AccessControl=s3.BucketOwnerFullControl,
            BucketName=s3_images_admin,
            CorsConfiguration=s3.CorsConfiguration(
                CorsRules=[
                    s3.CorsRules(
                        AllowedHeaders=["*"],
                        AllowedMethods=["GET"],
                        AllowedOrigins=["*"],
                    )
                ]
            ),
            Tags=Tags(Name="AVAIL Images Admin Redirect",
                      Application="AVAIL",
                      ApplicationID="AVAIL",
                      BillingID="NIEM.62HP27",
                      # No funny chars allowed in
                      # com.amazon.aws.platform.billing.tagset.type.TagValue
                      WorkOrder="WP-430-WO-AVAIL-00001",
                      cloud_env="pubvpc",
                      op_env=op_env_tag,
                      customer="NIEP",
                      owner="Rodney Grubbs",
                      role="storage",
                      site="images.nasa.gov"),
            VersioningConfiguration=s3.VersioningConfiguration(
                Status="Enabled"),
            WebsiteConfiguration=s3.WebsiteConfiguration(
                IndexDocument="index.html",
                RoutingRules=[s3.RoutingRule(
                    RedirectRule=s3.RedirectRule(
                        HostName=s3_images,
                        ReplaceKeyWith="login",
                        Protocol="https"
                        ),
                    )],
                ),
            LoggingConfiguration=s3.LoggingConfiguration(
                DestinationBucketName=s3_logging_name,
                LogFilePrefix=s3_logging_prefix),
    ))
    t.add_output(Output(
        "ImagesAdminBucket", Value=Ref(r_s3_images_admin)
    ))

    route53_images_admin_target = route53_admin_bucket
    if 'route53_images_admin_target' in config['AWS']:
        route53_images_admin_target = config['AWS']['route53_images_admin_target']
    r_r53_admin_bucket_dns = t.add_resource(
        route53.RecordSetType(
            "ImagesAdminBucketDNS",
            HostedZoneName=route53_zone_name,
            Comment="CNAME to the images admin login Bucket or CDN",
            Name=s3_images_admin_r53,
            Type="CNAME",
            TTL="300",
            ResourceRecords=[route53_images_admin_target],
            ),
    )
    t.add_output(Output(
        "ImagesAdminBucketDNS", Value=Ref(r_r53_admin_bucket_dns))
    )
    r_s3_images_assets = t.add_resource(
        s3.Bucket(
            "ImagesAssetsBucket",
            AccessControl=s3.BucketOwnerFullControl,
            BucketName=s3_images_assets,
            CorsConfiguration=s3.CorsConfiguration(
                CorsRules=[
                    s3.CorsRules(
                        AllowedHeaders=["*"],
                        AllowedMethods=["GET"],
                        AllowedOrigins=["*"],
                    )
                ]
            ),
            Tags=Tags(Name="AVAIL Public Assets",
                      Application="AVAIL",
                      ApplicationID="AVAIL",
                      BillingID="NIEM.62HP27",
                      # No funny chars allowed in
                      # com.amazon.aws.platform.billing.tagset.type.TagValue
                      WorkOrder="WP-430-WO-AVAIL-00001",
                      cloud_env="pubvpc",
                      op_env=op_env_tag,
                      customer="NIEP",
                      owner="Rodney Grubbs",
                      role="storage",
                      site="images.nasa.gov"),
            VersioningConfiguration=s3.VersioningConfiguration(
                Status="Enabled"),
            WebsiteConfiguration=s3.WebsiteConfiguration(
                IndexDocument="index.html",
                ErrorDocument="404.html",
                ),
            LoggingConfiguration=s3.LoggingConfiguration(
                DestinationBucketName=s3_logging_name,
                LogFilePrefix=s3_logging_prefix),
    ))
    t.add_output(Output(
        "ImagesAssetsBucket", Value=Ref(r_s3_images_assets)
    ))

    # Point to bucket or CDN
    route53_images_assets_target = route53_images_assets_bucket
    if 'route53_images_assets_target' in config['AWS']:
        route53_images_assets_target = config['AWS']['route53_images_assets_target']
    r_r53_images_assets_bucket_dns = t.add_resource(
        route53.RecordSetType(
            "ImagesAssetsBucketDNS",
            HostedZoneName=route53_zone_name,
            Comment="CNAME to the images assets media Bucket or CDN",
            Name=s3_images_assets_r53,
            Type="CNAME",
            TTL="300",
            ResourceRecords=[route53_images_assets_target],
            ),
        )
    t.add_output(Output(
        "ImagesAssetsBucketDNS", Value=Ref(r_r53_images_assets_bucket_dns)
    ))

    # Images bucket Policy Statement
    r_s3_images_bucket_policy_statement = [
        Statement(
            Action=[awacs.s3.GetObject],
            Effect=Allow,
            Resource=[
                awacs.s3.ARN(s3_images),
                awacs.s3.ARN(s3_images + "/*"),
            ],
            Principal=AWSPrincipal(Everybody),
            Condition=Condition(
                IpAddress("aws:SourceIp",
                          friendly_pub_cidr_blocks),
            ),
        ),
    ]

    # In dev environment, append to Images bucket Policy Statement
    if op_env == 'dev':
        r_s3_images_bucket_policy_statement.append(
            Statement(
                Action=[awacs.s3.GetObject],
                Effect=Allow,
                Resource=[
                    awacs.s3.ARN(s3_images),
                    awacs.s3.ARN(s3_images + "/*"),
                ],
                Principal=AWSPrincipal(Everybody),
                Condition=Condition(
                    StringEquals("aws:SourceVpce",
                                 source_vpc_endpoint),
                ),
            )
        )

    # In stage or prod environemnts, append to Images bucket Policy Statement
    if op_env in ('stage' , 'prod'):
        r_s3_images_bucket_policy_statement.append(
            Statement(
                Action=[awacs.s3.GetObject],
                Effect=Allow,
                Resource=[
                    awacs.s3.ARN(s3_images + "/*"),
                ],
                Principal=AWSPrincipal(
                    awacs.aws.BaseARN(
                        service="iam",
                        account="cloudfront",
                        resource="user/CloudFront Origin Access Identity " + cloudfront_images_identity
                    )
                )
        ))

    # S3 Bucket Policies Allowing public access to Public Buckets
    r_s3_images_bucket_policy = t.add_resource(
        s3.BucketPolicy(
            "ImagesBucketPolicy",
            Bucket=Ref(r_s3_images),
            PolicyDocument=Policy(
                Statement=r_s3_images_bucket_policy_statement
            ),
        )
    )
    t.add_output(Output(
        "ImagesBucketPolicy", Value=Ref(r_s3_images_bucket_policy)
    ))

    # ImagesAssets bucket Policy Statement
    r_s3_images_assets_bucket_policy_statement = [
            Statement(
                Action=[awacs.s3.GetObject],
                Effect=Allow,
                Resource=[
                    awacs.s3.ARN(s3_images_assets),
                    awacs.s3.ARN(s3_images_assets + "/*"),
                ],
                Principal=AWSPrincipal(Everybody),
                Condition=Condition(
                    IpAddress("aws:SourceIp",
                              friendly_pub_cidr_blocks),
                ),
            ),
        ]

    # In dev environment, append to ImagesAssets bucket Policy Statement
    if op_env == 'dev':
        r_s3_images_assets_bucket_policy_statement.append(
            Statement(
                Action=[awacs.s3.GetObject],
                Effect=Allow,
                Resource=[
                    awacs.s3.ARN(s3_images_assets),
                    awacs.s3.ARN(s3_images_assets + "/*"),
                ],
                Principal=AWSPrincipal(Everybody),
                Condition=Condition(
                    StringEquals("aws:SourceVpce",
                                 source_vpc_endpoint),
                ),
            )
        )

    # In stage or prod environments, append to ImagesAssets bucket Policy Statement
    if op_env in ('stage' , 'prod'):
        r_s3_images_assets_bucket_policy_statement.append(
            Statement(
                Action=[
                    awacs.s3.Action("GetBucketLocation"),
                    awacs.s3.Action("ListBucket"),
                    awacs.s3.Action("GetObject"),
                ],
                Effect=Allow,
                Resource=[
                    awacs.s3.ARN(s3_images_assets),
                    awacs.s3.ARN(s3_images_assets + "/*"),
                ],
                Principal=AWSPrincipal(awacs.iam.ARN(resource="root", account="283711470916"))
        ))

        r_s3_images_assets_bucket_policy_statement.append(
            Statement(
                Action=[awacs.s3.GetObject],
                Effect=Allow,
                Resource=[
                    awacs.s3.ARN(s3_images_assets + "/*"),
                ],
                Principal=AWSPrincipal(
                    awacs.aws.BaseARN(
                        service="iam",
                        account="cloudfront",
                        resource="user/CloudFront Origin Access Identity " + cloudfront_images_assets_identity
                    )
                )
        ))

    r_s3_images_assets_bucket_policy = t.add_resource(
        s3.BucketPolicy(
            "ImagesAssetsBucketPolicy",
            Bucket=Ref(r_s3_images_assets),
            PolicyDocument=Policy(
                Statement=r_s3_images_assets_bucket_policy_statement
            ),
        )
    )
    t.add_output(Output(
        "ImagesAssetsBucketPolicy", Value=Ref(r_s3_images_assets_bucket_policy)
    ))

    # ImagesAssets bucket Policy Statement
    r_s3_images_admin_bucket_policy_statement = [
        Statement(
            Action=[awacs.s3.GetObject],
            Effect=Allow,
            Resource=[
                awacs.s3.ARN(s3_images_admin),
                awacs.s3.ARN(s3_images_admin + "/*"),
            ],
            Principal=AWSPrincipal(Everybody),
            Condition=Condition(
                IpAddress("aws:SourceIp",
                          friendly_pub_cidr_blocks),
            ),
        )
    ]

    # In dev environment, append to ImagesAdmin bucket Policy Statement
    if op_env == 'dev':
        r_s3_images_admin_bucket_policy_statement.append(
            Statement(
                Action=[awacs.s3.GetObject],
                Effect=Allow,
                Resource=[
                    awacs.s3.ARN(s3_images_admin),
                    awacs.s3.ARN(s3_images_admin + "/*"),
                ],
                Principal=AWSPrincipal(Everybody),
                Condition=Condition(
                    StringEquals("aws:SourceVpce",
                                 source_vpc_endpoint),
                ),
            )
        )

    # In stage or prod environments, append to ImagesAssets bucket Policy Statement
    if op_env in ('stage' , 'prod'):
        r_s3_images_admin_bucket_policy_statement.append(
            Statement(
                Action=[awacs.s3.GetObject],
                Effect=Allow,
                Resource=[
                    awacs.s3.ARN(s3_images_admin + "/*"),
                ],
                Principal=AWSPrincipal(
                    awacs.aws.BaseARN(
                        service="iam",
                        account="cloudfront",
                        resource="user/CloudFront Origin Access Identity " + cloudfront_images_admin_identity
                    )
                )
        ))

    r_s3_images_admin_bucket_policy = t.add_resource(
        s3.BucketPolicy(
            "ImagesAdminBucketPolicy",
            Bucket=Ref(r_s3_images_admin),
            PolicyDocument=Policy(
                Statement=r_s3_images_admin_bucket_policy_statement
            ),
        )
    )
    t.add_output(Output(
        "ImagesAdminBucketPolicy", Value=Ref(r_s3_images_admin_bucket_policy)
    ))

    ###########################################################################
    # DynamoDB for JobState
    #   attribute definitions
    ad_jobstate_primary_hashkeyname = dynamodb.AttributeDefinition(
        AttributeName=Ref(p_jobstate_primary_hashkeyname),
        AttributeType=Ref(p_jobstate_primary_hashkeytype),
    )
    ad_jobstate_primary_rangekeyname = dynamodb.AttributeDefinition(
        AttributeName=Ref(p_jobstate_primary_rangekeyname),
        AttributeType=Ref(p_jobstate_primary_rangekeytype),
    )
    ad_jobstate_gsi1_hashkeyname = dynamodb.AttributeDefinition(
        AttributeName=Ref(p_jobstate_gsi1_hashkeyname),
        AttributeType=Ref(p_jobstate_gsi1_hashkeytype),
    )
    ad_jobstate_gsi1_rangekeyname = dynamodb.AttributeDefinition(
        AttributeName=Ref(p_jobstate_gsi1_rangekeyname),
        AttributeType=Ref(p_jobstate_gsi1_rangekeytype),
    )
    ad_jobstate_gsi2_hashkeyname = dynamodb.AttributeDefinition(
        AttributeName=Ref(p_jobstate_gsi2_hashkeyname),
        AttributeType=Ref(p_jobstate_gsi2_hashkeytype),
    )
    ad_jobstate_gsi2_rangekeyname = dynamodb.AttributeDefinition(
        AttributeName=Ref(p_jobstate_gsi2_rangekeyname),
        AttributeType=Ref(p_jobstate_gsi2_rangekeytype),
    )
    ad_jobstate_gsi3_hashkeyname = dynamodb.AttributeDefinition(
        AttributeName=Ref(p_jobstate_gsi3_hashkeyname),
        AttributeType=Ref(p_jobstate_gsi3_hashkeytype),
    )
    ad_jobstate_gsi3_rangekeyname = dynamodb.AttributeDefinition(
        AttributeName=Ref(p_jobstate_gsi3_rangekeyname),
        AttributeType=Ref(p_jobstate_gsi3_rangekeytype),
    )
    #   local secondary indices
    #   global secondary indices
    gsi_jobstate_1 = dynamodb.GlobalSecondaryIndex(  # error-mtime-index
        IndexName=Join( "-", [
            Ref(p_jobstate_gsi1_hashkeyname),
            Ref(p_jobstate_gsi1_rangekeyname),
            "index"
        ]),
        KeySchema=[
            dynamodb.KeySchema(
                AttributeName=Ref(p_jobstate_gsi1_hashkeyname),
                KeyType="HASH"
            ),
            dynamodb.KeySchema(
                AttributeName=Ref(p_jobstate_gsi1_rangekeyname),
                KeyType="RANGE"
            )
        ],
        Projection=dynamodb.Projection(
            ProjectionType='ALL'
        ),
        ProvisionedThroughput=dynamodb.ProvisionedThroughput(
            ReadCapacityUnits=dynamodb_jobdb_error_mtime_index_readunits,
            WriteCapacityUnits=dynamodb_jobdb_writeunits,
        )
    )

    gsi_jobstate_2 = dynamodb.GlobalSecondaryIndex(  # assetPath-mtime-index
        IndexName=Join("-", [
            Ref(p_jobstate_gsi2_hashkeyname),
            Ref(p_jobstate_gsi2_rangekeyname),
            "index"
        ]),
        KeySchema=[
            dynamodb.KeySchema(
                AttributeName=Ref(p_jobstate_gsi2_hashkeyname),
                KeyType="HASH",
            ),
            dynamodb.KeySchema(
                AttributeName=Ref(p_jobstate_gsi2_rangekeyname),
                KeyType="RANGE",
            )
        ],
        Projection=dynamodb.Projection(
            ProjectionType='ALL'
        ),
        ProvisionedThroughput=dynamodb.ProvisionedThroughput(
            ReadCapacityUnits=dynamodb_jobdb_assetpath_mtime_readunits,
            WriteCapacityUnits=dynamodb_jobdb_writeunits,
        )
    )

    gsi_jobstate_3 = dynamodb.GlobalSecondaryIndex(  # incomplete-mtime-index
        IndexName=Join("-", [
            Ref(p_jobstate_gsi3_hashkeyname),
            Ref(p_jobstate_gsi3_rangekeyname),
            "index"
        ]),
        KeySchema=[
            dynamodb.KeySchema(
                AttributeName=Ref(p_jobstate_gsi3_hashkeyname),
                KeyType="HASH",
            ),
            dynamodb.KeySchema(
                AttributeName=Ref(p_jobstate_gsi3_rangekeyname),
                KeyType="RANGE",
            )
        ],
        Projection=dynamodb.Projection(
            ProjectionType='ALL'
        ),
        ProvisionedThroughput=dynamodb.ProvisionedThroughput(
            ReadCapacityUnits=dynamodb_jobdb_incomplete_mtime_index_readunits,
            WriteCapacityUnits=dynamodb_jobdb_writeunits,
        )
    )

    #   table resource
    r_jobstate_db = t.add_resource(
        dynamodb.Table(
            "JobStateDB",
            AttributeDefinitions=[
                ad_jobstate_primary_hashkeyname,
                ad_jobstate_primary_rangekeyname,
                ad_jobstate_gsi1_hashkeyname,
                ad_jobstate_gsi2_hashkeyname,
                ad_jobstate_gsi3_hashkeyname,
            ],
            KeySchema=[
                dynamodb.KeySchema(
                    AttributeName=Ref(p_jobstate_primary_hashkeyname),
                    KeyType="HASH",
                ),
            ],
            ProvisionedThroughput=dynamodb.ProvisionedThroughput(
                ReadCapacityUnits=dynamodb_jobdb_table_readunits,
                WriteCapacityUnits=dynamodb_jobdb_writeunits,
            ),
            GlobalSecondaryIndexes=[
                gsi_jobstate_1,
                gsi_jobstate_2,
                gsi_jobstate_3,
            ],
            Tags=Tags(Name="AVAIL Public Assets",
                      Application="AVAIL",
                      ApplicationID="AVAIL",
                      BillingID="NIEM.62HP27",
                      # No funny chars allowed in
                      # com.amazon.aws.platform.billing.tagset.type.TagValue
                      WorkOrder="WP-430-WO-AVAIL-00001",
                      cloud_env="pubvpc",
                      op_env=op_env_tag,
                      customer="NIEP",
                      owner="Rodney Grubbs",
                      role="jobstatedb",
                      site="images.nasa.gov"
            ),
        )
    )
    t.add_output(Output("JobStateDB", Value=Ref(r_jobstate_db)))

    ###############################################################################
    # 2019-12-17 Unified table with modern data modeling: assets, users, jobs
    # I'm not squirreling around with references to Params we NEVER change.
    # Table name get set to $stack-AvailDB-$random like availdev-AvailDB-1AB61TQ1FOKZC

    r_avail_db = t.add_resource(
        dynamodb.Table(
            "AvailDB",
            BillingMode="PAY_PER_REQUEST",
            AttributeDefinitions=[
                dynamodb.AttributeDefinition(AttributeName="pk", AttributeType="S"),
                dynamodb.AttributeDefinition(AttributeName="sk", AttributeType="S"),
                # For GSIs
                dynamodb.AttributeDefinition(AttributeName="data", AttributeType="S"),
                dynamodb.AttributeDefinition(AttributeName="dt_state", AttributeType="S"),
                dynamodb.AttributeDefinition(AttributeName="processing", AttributeType="S"),
                dynamodb.AttributeDefinition(AttributeName="state_dt", AttributeType="S"),
                dynamodb.AttributeDefinition(AttributeName="uid", AttributeType="S"),

            ],
            KeySchema=[
                dynamodb.KeySchema(AttributeName="pk", KeyType="HASH"),
                dynamodb.KeySchema(AttributeName="sk", KeyType="RANGE"),
            ],
            # GSIs named like hashkey-rangekey
            GlobalSecondaryIndexes=[
                # Generic overloaded GSI, currently being use to map nasaid->aid, auid->uid.
                # Should be generally useful anywhere we can add a `data` attr.
                # Implies that items with `data` should have high cardinality but be knowable sk
                dynamodb.GlobalSecondaryIndex(
                    IndexName="sk-data",
                    KeySchema=[
                        dynamodb.KeySchema(AttributeName="sk", KeyType="HASH"),
                        dynamodb.KeySchema(AttributeName="data", KeyType="RANGE"),
                    ],
                    Projection=dynamodb.Projection(ProjectionType="KEYS_ONLY"),
                ),
                # Find assets by user in some state, sorted by dt.
                # Needs to track the asset state item so needs GSI on canonical item,
                # and the item must include a state_dt attr that tracks state and dt attrs.
                dynamodb.GlobalSecondaryIndex(
                    IndexName="uid-state_dt",
                    KeySchema=[
                        dynamodb.KeySchema(AttributeName="uid", KeyType="HASH"),
                        dynamodb.KeySchema(AttributeName="state_dt", KeyType="RANGE"),
                    ],
                    Projection=dynamodb.Projection(ProjectionType="KEYS_ONLY"),
                ),
                # Find assets by user in some time period, sorted by state.
                # Needs to track asset time and state so needs GSI on canonical item,
                # with a dt_state that tracks the item's dt and state.
                dynamodb.GlobalSecondaryIndex(
                    IndexName="uid-dt_state",
                    KeySchema=[
                        dynamodb.KeySchema(AttributeName="uid", KeyType="HASH"),
                        dynamodb.KeySchema(AttributeName="dt_state", KeyType="RANGE"),
                    ],
                    Projection=dynamodb.Projection(ProjectionType="KEYS_ONLY"),
                ),
                # Assets being processed are the most queried by dashboard;
                # these include ones waiting for user action (metadata, captions).
                # Store on the index the state which should include 'waiting'
                # along with a dt (do we need dt?)
                # * processing=uploading#2019-11-21T17:12:10
                # * processing=wait_for_metadata##2019-11-21T17:12:10
                # (In a workflow engine, wait_for_metadata would be a legit state.)
                dynamodb.GlobalSecondaryIndex(
                    IndexName="uid-processing",  # don't want our recipes 'dt', misleading
                    KeySchema=[
                        dynamodb.KeySchema(AttributeName="uid", KeyType="HASH"),
                        dynamodb.KeySchema(AttributeName="processing", KeyType="RANGE"),
                    ],
                    Projection=dynamodb.Projection(ProjectionType="KEYS_ONLY"),
                ),
            ],
            Tags=Tags(
                Name="AVAIL Unified Database Table",
                Application="AVAIL",
                ApplicationID="AVAIL",
                BillingID="NIEM.62HP27",
                WorkOrder="WP-430-WO-AVAIL-00001",
                cloud_env="pubvpc",
                op_env=op_env_tag,
                customer="NIEP",
                owner="Rodney Grubbs",
                role="availdb",
                site="images.nasa.gov"
            ),
        ),
    )
    t.add_output(Output("AvailDb", Value=Ref(r_avail_db)))

    #########################################################################
    # DynamoDB for Asset
    # attribute definitions
    ad_asset_primary_hashkeyname = dynamodb.AttributeDefinition(
        AttributeName=Ref(p_asset_primary_hashkeyname),
        AttributeType=Ref(p_asset_primary_hashkeytype)
    )
    ad_asset_gsi1_hashkeyname = dynamodb.AttributeDefinition(
        AttributeName=Ref(p_asset_gsi1_hashkeyname),
        AttributeType=Ref(p_asset_gsi1_hashkeytype)
    )
    ad_asset_gsi1_rangekeyname = dynamodb.AttributeDefinition(
        AttributeName=Ref(p_asset_gsi1_rangekeyname),
        AttributeType=Ref(p_asset_gsi1_rangekeytype)
    )
    ad_asset_gsi2_hashkeyname = dynamodb.AttributeDefinition(
        AttributeName=Ref(p_asset_gsi2_hashkeyname),
        AttributeType=Ref(p_asset_gsi2_hashkeytype)
    )
    ad_asset_gsi3_hashkeyname = dynamodb.AttributeDefinition(
        AttributeName=Ref(p_asset_gsi3_hashkeyname),
        AttributeType=Ref(p_asset_gsi3_hashkeytype)
    )

    #   global secondary indices

    gsi_asset_1 = dynamodb.GlobalSecondaryIndex(
        IndexName=Join("-", [
            Ref(p_asset_gsi1_hashkeyname),
            Ref(p_asset_gsi1_rangekeyname),
            "index"
        ]),
        KeySchema=[
            dynamodb.KeySchema(
                AttributeName=Ref(p_asset_gsi1_hashkeyname),
                KeyType="HASH",
            ),
            dynamodb.KeySchema(
                AttributeName=Ref(p_asset_gsi1_rangekeyname),
                KeyType="RANGE",
            ),
        ],
        Projection=dynamodb.Projection(
                ProjectionType="ALL"
        ),
        ProvisionedThroughput=dynamodb.ProvisionedThroughput(
            ReadCapacityUnits=Ref(p_jobstate_readunits),
            WriteCapacityUnits=dynamodb_jobdb_writeunits,
        )
    )

    gsi_asset_2 = dynamodb.GlobalSecondaryIndex(
        IndexName=Join("-", [
            Ref(p_asset_gsi2_hashkeyname),
            "index"
        ]),
        KeySchema=[
            dynamodb.KeySchema(
                AttributeName=Ref(p_asset_gsi2_hashkeyname),
                KeyType="HASH",
            ),
        ],
        Projection=dynamodb.Projection(
                ProjectionType="ALL"
        ),
        ProvisionedThroughput=dynamodb.ProvisionedThroughput(
            ReadCapacityUnits=Ref(p_jobstate_readunits),
            WriteCapacityUnits=dynamodb_jobdb_writeunits,
        )
    )

    gsi_asset_3 = dynamodb.GlobalSecondaryIndex(
        IndexName=Join("-", [
            Ref(p_asset_gsi3_hashkeyname),
            "index"
        ]),
        KeySchema=[
            dynamodb.KeySchema(
                AttributeName=Ref(p_asset_gsi3_hashkeyname),
                KeyType="HASH",
        )],
        Projection=dynamodb.Projection(
                ProjectionType="ALL"
        ),
        ProvisionedThroughput=dynamodb.ProvisionedThroughput(
            ReadCapacityUnits=Ref(p_jobstate_readunits),
            WriteCapacityUnits=dynamodb_jobdb_writeunits,
        )
    )

    r_asset_db = t.add_resource(
        dynamodb.Table(
            "AssetDB",
            AttributeDefinitions=[
                ad_asset_primary_hashkeyname,
                ad_asset_gsi1_hashkeyname,
                ad_asset_gsi1_rangekeyname,
                ad_asset_gsi2_hashkeyname,
                ad_asset_gsi3_hashkeyname
            ],
            KeySchema=[
                dynamodb.KeySchema(
                    AttributeName=Ref(p_asset_primary_hashkeyname),
                    KeyType="HASH",
                )
            ],
            ProvisionedThroughput=dynamodb.ProvisionedThroughput(
                ReadCapacityUnits=dynamodb_assetdb_table_readunits,
                WriteCapacityUnits=dynamodb_jobdb_writeunits,
            ),
            GlobalSecondaryIndexes=[
                gsi_asset_1, gsi_asset_2, gsi_asset_3
            ],
            Tags=Tags(Name="AVAIL Public Assets",
                      Application="AVAIL",
                      ApplicationID="AVAIL",
                      BillingID="NIEM.62HP27",
                      # No funny chars allowed in
                      # com.amazon.aws.platform.billing.tagset.type.TagValue
                      WorkOrder="WP-430-WO-AVAIL-00001",
                      cloud_env="pubvpc",
                      op_env=op_env_tag,
                      customer="NIEP",
                      owner="Rodney Grubbs",
                      role="assetdb",
                      site="images.nasa.gov"
            ),
        )
    )
    t.add_output(Output("AssetDB", Value=Ref(r_asset_db)))

    # DynamoDB for Users: key=auid; expects attributes center=str, roles=[str, ...]
    #
    # users = boto3.resource("dynamodb").Table("availtest-UserDB-cshenton")
    # users.get_item(Key={"auid": "rgrubbs"}) returns
    # {'Item': {'center': 'MSFC', 'roles': {'group:UAT', 'group:IEG'}, 'auid': 'rgrubbs'},
    #  'ResponseMetadata': {'HTTPStatusCode': 200,
    #                       'RequestId': 'VT8CJJ1606LHK70KDQHI2EUPFBVV4KQNSO5AEMVJF66Q9ASUAAJG'}}

    r_user_db = t.add_resource(
        dynamodb.Table(
            "UserDB",
            AttributeDefinitions=[dynamodb.AttributeDefinition(
                AttributeName="auid",
                AttributeType="S"
            )],
            KeySchema=[
                dynamodb.KeySchema(
                    AttributeName="auid",
                    KeyType="HASH",
            )],
            ProvisionedThroughput=dynamodb.ProvisionedThroughput(
                ReadCapacityUnits=dynamodb_userdb_readunits,
                WriteCapacityUnits=dynamodb_userdb_writeunits,
            ),
            Tags=Tags(Name="AVAIL Public Assets",
                      Application="AVAIL",
                      ApplicationID="AVAIL",
                      BillingID="NIEM.62HP27",
                      # No funny chars allowed in
                      # com.amazon.aws.platform.billing.tagset.type.TagValue
                      WorkOrder="WP-430-WO-AVAIL-00001",
                      cloud_env="pubvpc",
                      op_env=op_env_tag,
                      customer="NIEP",
                      owner="Rodney Grubbs",
                      role="userdb",
                      site="images.nasa.gov"
            ),
        )
    )
    t.add_output(Output("UserDB", Value=Ref(r_user_db)))

    ###########################################################################
    # IAM: Roles, Policies, Instance Profiles (all can write to ErrorQueue)

    # API:
    # - S3 avail-private:  write
    # - SQS UploadQueue:   write
    # - SQS ErrorQueue:    write
    # - DynamoDB JobState: write

    r_scaling_sns_topic = t.add_resource(
        sns.Topic(
            "ScalingSNSTopic",
            Subscription=[
                sns.Subscription(
                    Endpoint=Ref(p_scale_notification_email_1),
                    Protocol="email"
                ),
                sns.Subscription(
                    Endpoint=Ref(p_scale_notification_email_2),
                    Protocol="email"
                ),
            ],
        ))
    t.add_output([
        Output("ScalingSNSTopicName",
               Value=GetAtt(r_scaling_sns_topic, "TopicName")),
        Output("ScalingSNSTopicARN",
               Value=Ref(r_scaling_sns_topic))
    ])

    r_api_scale_up_lifecycle_hook = t.add_resource(
        autoscaling.LifecycleHook(
            "APIScaleUpLifeCycleHook",
            DependsOn=["APIAutoscalingGroup", "AutoscalingLifecycleRole"],
        ))

    r_api_role_policy_statements = [
        Statement(
            # Action=[awacs.s3.GetObject,
            #         awacs.s3.PutObject,
            #         ],
            Action=[awacs.s3.Action("*")],
            Effect=Allow,
            # Resource=[awacs.s3.ARN(r_s3_private.title)],
            # Resource=[GetAtt(r_s3_private, "Arn")],
            # ^ error: not support attribute type
            #   Arn in Fn::GetAtt
            Resource=[
                awacs.s3.ARN(s3_private),
                awacs.s3.ARN(s3_private + "/*"),
                awacs.s3.ARN(s3_images),
                awacs.s3.ARN(s3_images + "/*"),
                awacs.s3.ARN(s3_images_assets),
                awacs.s3.ARN(s3_images_assets + "/*"),
            ],
            Sid="AVAILAPIS3ReadWrite",
        ),
        Statement(
            Action=[
                # TODO: remove unneeded permissions
                awacs.sqs.ChangeMessageVisibility,
                awacs.sqs.DeleteMessage,
                # awacs.sqs.GetQueueAttributes,
                awacs.sqs.GetQueueUrl,
                # awacs.sqs.ReceiveMessage,
                awacs.sqs.SendMessage,
                # awacs.sqs.SetQueueAttributes,
            ],
            Effect=Allow,
            Resource=[
                GetAtt(r_queues["UploadedQueue"], "Arn"),
                GetAtt(r_queues["PublishedQueue"], "Arn"),
                GetAtt(r_queues["TranscodedQueue"], "Arn"),
                GetAtt(r_queues["ErrorQueue"], "Arn"),
            ],
            Sid="AVAILAPISQSInsert",
        ),
        Statement(
            Action=[
                # TODO: remove unneeded capabilities
                awacs.dynamodb.DeleteItem,
                awacs.dynamodb.DescribeTable,
                awacs.dynamodb.GetItem,
                awacs.dynamodb.PutItem,
                awacs.dynamodb.Query,
                awacs.dynamodb.Scan,
                awacs.dynamodb.UpdateItem,
            ],
            Effect=Allow,
            Resource=[
                # Works, but crude:
                Join("", ["arn:aws:dynamodb:",
                          aws_region,
                          ":",
                          aws_account,
                          ":table/",
                          Ref(r_jobstate_db)]),
                Join("", ["arn:aws:dynamodb:",
                          aws_region,
                          ":",
                          aws_account,
                          ":table/",
                          Ref(r_jobstate_db),
                          "/index/*"]),
                Join("", ["arn:aws:dynamodb:",
                          aws_region,
                          ":",
                          aws_account,
                          ":table/",
                          Ref(r_asset_db)]),
                Join("", ["arn:aws:dynamodb:",
                          aws_region,
                          ":",
                          aws_account,
                          ":table/",
                          Ref(r_asset_db),
                          "/index/*"]),
                Join("", ["arn:aws:dynamodb:", aws_region, ":", aws_account, ":table/",
                          Ref(r_avail_db)]),
                Join("", ["arn:aws:dynamodb:", aws_region, ":", aws_account, ":table/",
                          Ref(r_avail_db), "/index/*"]),
            ],
            Sid="AVAILAPIDynamodb",
        ),
        Statement(
            # UserDB should be read/get only
            Action=[
                awacs.dynamodb.DescribeTable,
                awacs.dynamodb.GetItem,
            ],
            Effect=Allow,
            Resource=[
                Join("", ["arn:aws:dynamodb:",
                          aws_region,
                          ":",
                          aws_account,
                          ":table/",
                          Ref(r_user_db)]),
                Join("", ["arn:aws:dynamodb:",
                          aws_region,
                          ":",
                          aws_account,
                          ":table/",
                          Ref(r_user_db),
                          "/index/*"]),
                ],
            Sid="AVAILAPIDynamodbUserDB",
        ),
        Statement(
            Action=[
                awacs.cloudsearch.Action(
                    "search"),
                awacs.cloudsearch.Action(
                    "suggest"),
                awacs.cloudsearch.Action(
                    "document"),
                ],
            Effect=Allow,
            Resource=["*"],
            Sid="AVAILAPICloudSearch",
        ),
        Statement(
            Action=[
               awacs.autoscaling.CompleteLifecycleAction,
               awacs.autoscaling.DescribeAutoScalingGroups,
               awacs.autoscaling.DescribeAutoScalingInstances,
               awacs.autoscaling.DescribeLifecycleHooks,
            ],
            Effect=Allow,
            Resource=["*"],
            Sid="AVAILAPIScaleUpLifeCycleComplete",
        ),
    ]

    r_api_role = t.add_resource(
        iam.Role(
            "APIRole",
            AssumeRolePolicyDocument=Policy(
                Statement=[
                    Statement(
                        Action=[awacs.sts.AssumeRole],
                        Effect=Allow,
                        Principal=Principal("Service", "ec2.amazonaws.com"),
                        Sid="AVAILAPIRole",
                    ),
                ],
            ),
            ManagedPolicyArns=[cloudwatch_iam_policy],
            Path="/",
            Policies=[iam.Policy(
                "APIPolicy",
                PolicyDocument=Policy(
                    Version="2012-10-17",  # needed for policy vars
                    Statement=r_api_role_policy_statements,
                ),
                PolicyName="avail-api-policy",
            )],
        ))
    r_api_instance_profile = t.add_resource(
        iam.InstanceProfile(
            "APIInstanceProfile",
            Path="/",
            Roles=[Ref(r_api_role)],
        ))
    t.add_output([
        Output("APIRole", Value=Ref(r_api_role)),
        Output("APIInstanceProfile", Value=Ref(r_api_instance_profile))
    ])

    r_autoscaling_lifecycle_role = t.add_resource(
        iam.Role(
            "AutoscalingLifecycleRole",
            AssumeRolePolicyDocument=Policy(
                Statement=[
                    Statement(
                        Action=[awacs.sts.AssumeRole],
                        Effect=Allow,
                        Principal=Principal("Service", "autoscaling.amazonaws.com"),
                        Sid="AVAILAutoscalingLifecycleRole",
                    ),
                ],
            ),
            Path="/",
            Policies=[iam.Policy(
                "AutoscalingLifecyclePolicy",
                PolicyDocument=Policy(
                    Version="2012-10-17",  # needed for policy vars
                    Statement=[
                        Statement(
                            Action=[
                                 awacs.sns.Action(
                                     "Publish"),
                            ],
                            Effect=Allow,
                            Resource=[
                                Ref(r_scaling_sns_topic),
                            ],
                            Sid="AVAILAutoscalingLifeCycleSNSNotify",
                        ),
                        ],
                    ),
                    PolicyName="avail-autoscaling-lifecycle-policy",
                )],
           ))
    t.add_output([
        Output("AutoscalingLifecycleRole", Value=Ref(r_autoscaling_lifecycle_role)),
    ])

    # ImageResizer:
    # - S3 avail-private:    read, write
    # - SQS UploadedQueue:   read, delete
    # - SQS TranscodedQueue: write
    # - SQS ErrorQueue:      write
    # - DynamoDB: JobState:  write

    r_imageresizer_scale_up_lifecycle_hook = t.add_resource(
        autoscaling.LifecycleHook(
            "ImageResizerScaleUpLifeCycleHook",
            DependsOn=["ImageResizerAutoscalingGroup", "AutoscalingLifecycleRole"],
        ))

    r_imageresizer_role_policy_statements = [
        Statement(
            Action=[awacs.s3.Action("*")],
            Effect=Allow,
            Resource=[awacs.s3.ARN(s3_private),
                      awacs.s3.ARN(s3_private + "/*"),
                      ],
            Sid="AVAILImageResizerS3ReadWrite",
        ),
        Statement(
            Action=[awacs.s3.Action("*")],
            Effect=Allow,
            Resource=[awacs.s3.ARN(s3_images_assets),
                      awacs.s3.ARN(s3_images_assets + "/*"),
                      ],
            Sid="AVAILImageResizerS3Read",
        ),
        Statement(
            Action=[
                # TODO: remove unneeded permissions
                # awacs.sqs.ChangeMessageVisibility,
                awacs.sqs.DeleteMessage,
                # awacs.sqs.GetQueueAttributes,
                # awacs.sqs.GetQueueUrl,
                awacs.sqs.ReceiveMessage,
                # awacs.sqs.SendMessage,
                # awacs.sqs.SetQueueAttributes,
            ],
            Effect=Allow,
            Resource=[
                GetAtt(r_queues["UploadedQueue"], "Arn"),
            ],
            Sid="AVAILImageResizerSQSInsertUploaded",
        ),
        Statement(
            Action=[
                # TODO: remove unneeded permissions
                awacs.sqs.ChangeMessageVisibility,
                # awacs.sqs.DeleteMessage,
                # awacs.sqs.GetQueueAttributes,
                # awacs.sqs.GetQueueUrl,
                # awacs.sqs.ReceiveMessage,
                awacs.sqs.SendMessage,
                # awacs.sqs.SetQueueAttributes,
            ],
            Effect=Allow,
            Resource=[
                GetAtt(r_queues["TranscodedQueue"], "Arn"),
                GetAtt(r_queues["ErrorQueue"], "Arn"),
            ],
            Sid="AVAILImageResizerSQSInsert",
        ),
        Statement(
            Action=[
                # TODO: remove unneeded capabilities
                awacs.dynamodb.DeleteItem,
                awacs.dynamodb.DescribeTable,
                awacs.dynamodb.GetItem,
                awacs.dynamodb.PutItem,
                awacs.dynamodb.Query,
                awacs.dynamodb.Scan,
                awacs.dynamodb.UpdateItem,
            ],
            Effect=Allow,
            Resource=[
                # Works, but crude:
                Join("", ["arn:aws:dynamodb:",
                          aws_region,
                          ":",
                          aws_account,
                          ":table/",
                          Ref(r_jobstate_db)]),
                Join("", ["arn:aws:dynamodb:", aws_region, ":", aws_account, ":table/",
                          Ref(r_avail_db)]),
                Join("", ["arn:aws:dynamodb:", aws_region, ":", aws_account, ":table/",
                          Ref(r_avail_db), "/index/*"]),
            ],
            Sid="AVAILImageResizerDynamodb",
        ),
        Statement(
            Action=[
               awacs.autoscaling.CompleteLifecycleAction,
               awacs.autoscaling.DescribeAutoScalingGroups,
               awacs.autoscaling.DescribeAutoScalingInstances,
               awacs.autoscaling.DescribeLifecycleHooks,
            ],
            Effect=Allow,
            Resource=["*"],
            Sid="AVAILImageResizerScaleUpLifeCycleComplete",
        ),
    ]

    r_imageresizer_role = t.add_resource(
        iam.Role(
            "ImageResizerRole",
            AssumeRolePolicyDocument=Policy(
                Statement=[
                    Statement(
                        Action=[awacs.sts.AssumeRole],
                        Effect=Allow,
                        Principal=Principal("Service", "ec2.amazonaws.com"),
                        Sid="AVAILImageResizerRole",
                    ),
                ],
            ),
            ManagedPolicyArns=[cloudwatch_iam_policy],
            Path="/",
            Policies=[iam.Policy(
                "ImageResizerPolicy",
                PolicyDocument=Policy(
                    Statement=r_imageresizer_role_policy_statements,
                ),
                PolicyName="avail-imageresizer-policy",
            )],
        ))
    r_imageresizer_instance_profile = t.add_resource(
        iam.InstanceProfile(
            "ImageResizerInstanceProfile",
            Path="/",
            Roles=[Ref(r_imageresizer_role)],
        ))
    t.add_output([
        Output("ImageResizerRole",
               Value=Ref(r_imageresizer_role)),
        Output("ImageResizerInstanceProfile",
               Value=Ref(r_imageresizer_instance_profile))
    ])

    # Pipeline
    # - S3 avail-private:    read, write
    # - S3 avail-public:     read, write
    # - SQS UploadedQueue:   read, write, delete
    # - SQS TranscodedQueue: read, write, delete
    # - SQS PublishedQueue:  read, write, delete
    # - SQS ErrorQueue:      read, write, delete
    # - DynamoDB: JobState:  write

    r_pipeline_scale_up_lifecycle_hook = t.add_resource(
        autoscaling.LifecycleHook(
            "PipelineScaleUpLifeCycleHook",
            DependsOn=["PipelineAutoscalingGroup", "AutoscalingLifecycleRole"],
        ))

    r_pipeline_role_policy_statements = [
        Statement(
            # Action=[awacs.s3.GetObject,
            #         awacs.s3.PutObject,
            #         ],
            # AWACS has no symbolic name for *
            Action=[awacs.s3.Action("*")],
            Effect=Allow,
            # Resource=[awacs.s3.ARN(r_s3_private.title),
            #           awacs.s3.ARN(r_s3_images.title),
            #           ],
            # TODO: HARDWIRED
            Resource=[awacs.s3.ARN(s3_private),
                      awacs.s3.ARN(s3_private + "/*"),
                      awacs.s3.ARN(s3_images),
                      awacs.s3.ARN(s3_images + "/*"),
                      awacs.s3.ARN(s3_images_assets),
                      awacs.s3.ARN(s3_images_assets + "/*"),
                      ],
            Sid="AVAILPipelineS3ReadWrite",
        ),
        Statement(
            Action=[
                # TODO: remove unneeded permissions
                awacs.sqs.ChangeMessageVisibility,
                awacs.sqs.DeleteMessage,
                awacs.sqs.GetQueueAttributes,
                awacs.sqs.GetQueueUrl,
                awacs.sqs.ListQueues,
                awacs.sqs.ReceiveMessage,
                awacs.sqs.SendMessage,
                # awacs.sqs.SetQueueAttributes,
            ],
            Effect=Allow,
            Resource=[
                GetAtt(r_queues["UploadedQueue"], "Arn"),
                GetAtt(r_queues["TranscodedQueue"], "Arn"),
                GetAtt(r_queues["PublishedQueue"], "Arn"),
                GetAtt(r_queues["ErrorQueue"], "Arn"),
            ],
            Sid="AVAILPipelineSQSReadWriteDelete",
        ),
        Statement(
            Action=[
                # TODO: remove unneeded capabilities
                awacs.dynamodb.DeleteItem,
                awacs.dynamodb.DescribeTable,
                awacs.dynamodb.GetItem,
                awacs.dynamodb.PutItem,
                awacs.dynamodb.Query,
                awacs.dynamodb.Scan,
                awacs.dynamodb.UpdateItem,
            ],
            Effect=Allow,
            Resource=[
                # Works, but crude:
                Join("", ["arn:aws:dynamodb:",
                          aws_region,
                          ":",
                          aws_account,
                          ":table/",
                          Ref(r_jobstate_db)]),
                Join("", ["arn:aws:dynamodb:",
                          aws_region,
                          ":",
                          aws_account,
                          ":table/",
                          Ref(r_jobstate_db),
                          "/index/*"]),
                Join("", ["arn:aws:dynamodb:",
                          aws_region,
                          ":",
                          aws_account,
                          ":table/",
                          Ref(r_asset_db)]),
                Join("", ["arn:aws:dynamodb:",
                          aws_region,
                          ":",
                          aws_account,
                          ":table/",
                          Ref(r_asset_db),
                          "/index/*"]),
                Join("", ["arn:aws:dynamodb:", aws_region, ":", aws_account, ":table/",
                          Ref(r_avail_db)]),
                Join("", ["arn:aws:dynamodb:", aws_region, ":", aws_account, ":table/",
                          Ref(r_avail_db), "/index/*"]),
                ],
            Sid="AVAILPipelineDynamodb",
        ),
        Statement(
            # UserDB should be read/get only
            Action=[
                awacs.dynamodb.DescribeTable,
                awacs.dynamodb.GetItem,
            ],
            Effect=Allow,
            Resource=[
                Join("", ["arn:aws:dynamodb:",
                          aws_region,
                          ":",
                          aws_account,
                          ":table/",
                          Ref(r_user_db)]),
                Join("", ["arn:aws:dynamodb:",
                          aws_region,
                          ":",
                          aws_account,
                          ":table/",
                          Ref(r_user_db),
                          "/index/*"]),
                ],
            Sid="AVAILPipelineDynamodbUserDB",
        ),
        Statement(
            Action=[
                awacs.elastictranscoder.CreateJob,
                awacs.elastictranscoder.ListPresets,
                awacs.elastictranscoder.ListPipelines,
                awacs.elastictranscoder.ReadJob,
                awacs.elastictranscoder.ReadPipeline
            ],
            Effect=Allow,
            Resource=[
                # ET Pipeline has no ARNs
                "*"
                ],
            Sid="AVAILPipelineElasticTranscoder",
        ),
        Statement(
            Action=[
                awacs.cloudsearch.Action(
                    "search"),
                awacs.cloudsearch.Action(
                    "suggest"),
                awacs.cloudsearch.Action(
                    "document"),
                ],
            Effect=Allow,
            Resource=["*"],
            Sid="AVAILPipelineCloudSearch",
        ),
        Statement(
            Action=[
               awacs.autoscaling.CompleteLifecycleAction,
               awacs.autoscaling.DescribeAutoScalingGroups,
               awacs.autoscaling.DescribeAutoScalingInstances,
               awacs.autoscaling.DescribeLifecycleHooks,
            ],
            Effect=Allow,
            Resource=["*"],
            Sid="AVAILPipelineScaleUpLifeCycleComplete",
        ),
        Statement(
            Action=[
                awacs.cloudformation.DescribeStackResources,
                ],
            Effect=Allow,
            Resource=[
                Join("", ["arn:aws:cloudformation:",
                          aws_region,
                          ":",
                          aws_account,
                          ":stack/*"]),
                ],
            Sid="AVAILPipelineCloudFormationDescribeResources",
        ),
        Statement(
            Action=[
                awacs.elasticloadbalancing.DescribeInstanceHealth,
                ],
            Effect=Allow,
            Resource=["*"],
            Sid="AVAILPipelineElasticLoadBalancingDescribeInstanceHealth",
        ),
    ]

    r_pipeline_role = t.add_resource(
        iam.Role(
            "PipelineRole",
            AssumeRolePolicyDocument=Policy(
                Statement=[
                    Statement(
                        Action=[awacs.sts.AssumeRole],
                        Effect=Allow,
                        Principal=Principal("Service", "ec2.amazonaws.com"),
                        Sid="AVAILPipelineRole",
                    ),
                ],
            ),
            ManagedPolicyArns=[cloudwatch_iam_policy],
            Path="/",
            Policies=[iam.Policy(
                "PipelinePolicy",
                PolicyDocument=Policy(
                    Statement=r_pipeline_role_policy_statements,
                ),
                PolicyName="avail-pipeline-policy",
            )],
        ))
    r_pipeline_instance_profile = t.add_resource(
        iam.InstanceProfile(
            "PipelineInstanceProfile",
            Path="/",
            Roles=[Ref(r_pipeline_role)],
        ))
    t.add_output([
        Output("PipelineRole",
               Value=Ref(r_pipeline_role)),
        Output("PipelineInstanceProfile",
               Value=Ref(r_pipeline_instance_profile))
    ])

    ###########################################################################
    # API: LaunchTemplate, Private ELB, AutoScalingGroup, Notifications

    r_api_launchtemplate = t.add_resource(
        ec2.LaunchTemplate(
            "APILaunchTemplate",
            LaunchTemplateName="APILaunchTemplate" + op_env,
            LaunchTemplateData=ec2.LaunchTemplateData(
                IamInstanceProfile=ec2.IamInstanceProfile(
                    Arn=GetAtt(r_api_instance_profile, "Arn"),),
                ImageId=ami_id,
                InstanceType=api_instance_type,
                KeyName=Ref(p_keyname),
                Monitoring=ec2.Monitoring(Enabled=True),
                # No need for NetworkInterfaces; instances in private subnets get private IPv4
                # addresses by default.
                SecurityGroupIds=[Ref(r_sg_ssh),
                                  Ref(r_sg_api_ec2_healthcheck_from_elb)
                                  ],
                TagSpecifications=[ec2.TagSpecifications(
                    Tags=Tags(Name="images-api." + op_env + ".nasawestprime.com",
                              Application="AVAIL",
                              ApplicationID="AVAIL",
                              BillingID="NIEM.62HP27",
                              WorkOrder="WP-430-WO-AVAIL-00001",
                              cloud_env="pubvpc",
                              op_env=op_env_tag,
                              customer="NIEP",
                              owner="Rodney Grubbs",
                              role="api",
                              site="images.nasa.gov",
                              tech_stack="app",
                              ansibleignore="",
                              ),
                    ResourceType=r) for r in ("instance", "volume",)],
                UserData=Base64(Join('', [
                    "#!/bin/bash -xe\n",
                    "export op_env={}\n".format(op_env),
                    "apt-get -y remove ansible\n",
                    "pip install ansible==2.1.5.0\n",
                    "mkdir {}\n".format(ec2_tarball_build_dir),
                    "cd {}\n".format(ec2_tarball_build_dir),
                    "curl --location -o {} {}\n".format(
                        ec2_tarball_api_file,
                        ec2_tarball_api_url),
                    "tar zxf {}\n".format(ec2_tarball_api_file),
                    "sh {}\n".format(ec2_tarball_api_sh),
                    "cat {}/misc/rc.local > /etc/rc.local\n".format(ec2_tarball_build_dir),
                    "ln -s {}/misc/complete-lifecycle-hook.sh /etc/init.d/\n".format(ec2_tarball_build_dir),
                    "reboot\n"
                ]))
            ),
        )
    )

    api_elb_listeners = [
        elb.Listener(
            LoadBalancerPort="80",
            InstancePort="80",
            Protocol="HTTP",
            InstanceProtocol="HTTP",
        ),
        # SSL terminated on ELB with cert there,
        # so direct ELB HTTPS with SSL to instance 443 without SSL.
        # https://docs.aws.amazon.com/ElasticLoadBalancing/latest/
        #         DeveloperGuide/ssl-server-cert.html#upload-cert
        # CertId like:
        # arn:aws:iam::123456789123:server-certificate/start_certname_com
        elb.Listener(
            InstancePort="443",
            InstanceProtocol="HTTP",
            LoadBalancerPort="443",
            Protocol="HTTPS",
            SSLCertificateId=elb_avail_api_ssl_id,
        ),
    ]

    if op_env == 'prod':
        api_elb_listeners.append(
            elb.Listener(
                InstancePort="4400",
                InstanceProtocol="HTTP",
                LoadBalancerPort="4400",
                Protocol="HTTPS",
                SSLCertificateId=elb_avail_api_ssl_id,
            ),
        )

    r_api_loadbalancer = t.add_resource(
        elb.LoadBalancer(
            "APILoadBalancer",
            CrossZone=True,
            HealthCheck=elb.HealthCheck(
                Target=elb_avail_api_healthcheck,  # instance:443 not SSL
                HealthyThreshold="3",
                UnhealthyThreshold="5",
                Interval="30",
                Timeout="5",
            ),
            Listeners=api_elb_listeners,
            LoadBalancerName=elb_avail_api,  # needed by AutoScaleGroup
            SecurityGroups=r_api_elb_sgs,
            Scheme="internet-facing",
            Subnets=[Ref(r_subnets["infra1"]), Ref(r_subnets["infra2"])],
            Tags=Tags(
                Name="API LoadBalancer",
                Application="AVAIL",
                ApplicationID="AVAIL",
                BillingID="NIEM.62HP27",
                WorkOrder="WP-430-WO-AVAIL-00001",
                cloud_env="pubvpc",
                op_env=op_env_tag,
                customer="NIEP",
                owner="Rodney Grubbs",
                role="api",
                site="images.nasa.gov",
            ),
        ))
    t.add_output(
        Output("APIELBName", Value=GetAtt(r_api_loadbalancer, "DNSName"))
    )

    # We may override the API target to point at the CDN
    route53_images_api_target = GetAtt(r_api_loadbalancer, "DNSName")
    if 'route53_images_api_target' in config['AWS']:
        route53_images_api_target = config['AWS']['route53_images_api_target']
    t.add_resource(
        route53.RecordSetType(
            "APIELBDNSimages",
            HostedZoneName=route53_zone_name,
            Comment="CNAME to the API ELB or CDN",
            Name=route53_images_api_elb,
            Type="CNAME",
            TTL="300",
            ResourceRecords=[route53_images_api_target],
        ),
    )
    r_api_autoscalinggroup = t.add_resource(
        autoscaling.AutoScalingGroup(
            "APIAutoscalingGroup",
            AvailabilityZones=[az_map[0], az_map[1]],
            Cooldown=300,
            DesiredCapacity=asg_avail_api_min,
            HealthCheckGracePeriod=300,
            HealthCheckType="EC2",  # or ELB
            LaunchTemplate=autoscaling.LaunchTemplateSpecification(
                LaunchTemplateId=Ref(r_api_launchtemplate),
                Version=GetAtt(r_api_launchtemplate, "LatestVersionNumber"),),
            LoadBalancerNames=[Ref(r_api_loadbalancer)],
            MaxSize=asg_avail_api_max,
            MetricsCollection=[
                autoscaling.MetricsCollection(Granularity="1Minute")],
            MinSize=asg_avail_api_min,
            NotificationConfigurations=[autoscaling.NotificationConfigurations(
                TopicARN=Ref(r_scaling_sns_topic),
                NotificationTypes=[autoscaling.EC2_INSTANCE_LAUNCH,
                                   autoscaling.EC2_INSTANCE_LAUNCH_ERROR,
                                   autoscaling.EC2_INSTANCE_TERMINATE,
                                   autoscaling.EC2_INSTANCE_TERMINATE_ERROR])],
            Tags=autoscaling.Tags(Name="images-api." + op_env +
                                  ".nasawestprime.com",
                                  Application="AVAIL",
                                  ApplicationID="AVAIL",
                                  BillingID="NIEM.62HP27",
                                  WorkOrder="WP-430-WO-AVAIL-00001",
                                  cloud_env="pubvpc",
                                  op_env=op_env_tag,
                                  customer="NIEP",
                                  owner="Rodney Grubbs",
                                  role="api",
                                  site="images.nasa.gov",
                                  tech_stack="app",
                                  ansibleignore="",
                                  ),

            # UpdatePolicy= UpdatePolicy() controls rolling update
            VPCZoneIdentifier=[Ref(r_subnets["app1"]),
                               Ref(r_subnets["app2"])],
        ))

    # Complete building api_asg lifecycle hook, needs api_asg, asg_scaling_role and scaling_sns_topic to exist
    r_api_scale_up_lifecycle_hook.AutoScalingGroupName = Ref(r_api_autoscalinggroup)
    r_api_scale_up_lifecycle_hook.LifecycleTransition = "autoscaling:EC2_INSTANCE_LAUNCHING"
    r_api_scale_up_lifecycle_hook.NotificationTargetARN = Ref(r_scaling_sns_topic)
    r_api_scale_up_lifecycle_hook.RoleARN = GetAtt(r_autoscaling_lifecycle_role, "Arn")

    r_api_scale_up_policy = t.add_resource(
        autoscaling.ScalingPolicy(
            "APIScaleUpPolicy",
            AdjustmentType="ChangeInCapacity",  # or ExactCapacity
            AutoScalingGroupName=Ref(r_api_autoscalinggroup),
            Cooldown=60,
            ScalingAdjustment="1",
        ))

    r_api_scale_down_policy = t.add_resource(
        autoscaling.ScalingPolicy(
            "APIScaleDownPolicy",
            AdjustmentType="ChangeInCapacity",  # or ExactCapacity
            AutoScalingGroupName=Ref(r_api_autoscalinggroup),
            Cooldown=300,
            ScalingAdjustment="-1",
        ))


    # Unused: r_api_cpu_alarm_high =
    t.add_resource(
        cw.Alarm(
            "APICPUAlarmHigh",
            AlarmDescription=(
                "Alarm if CPU high or missing due to dead instance"),
            ComparisonOperator="GreaterThanThreshold",
            Dimensions=[cw.MetricDimension(Name="AutoScalingGroupName",
                                           Value=Ref(r_api_autoscalinggroup))],
            EvaluationPeriods=3,
            MetricName="CPUUtilization",
            Period="60",
            Namespace="AWS/EC2",
            Statistic="Average",
            Threshold="25",
            AlarmActions=[Ref(r_api_scale_up_policy)],
        ))

    # Unused: r_api_cpu_alarm_low =
    t.add_resource(
        cw.Alarm(
            "APICPUAlarmLow",
            AlarmDescription="Alarm if CPU low",
            ComparisonOperator="LessThanThreshold",
            Dimensions=[cw.MetricDimension(Name="AutoScalingGroupName",
                                           Value=Ref(r_api_autoscalinggroup))],
            EvaluationPeriods=5,
            MetricName="CPUUtilization",
            Period="60",
            Namespace="AWS/EC2",
            Statistic="Average",
            Threshold="19",
            AlarmActions=[Ref(r_api_scale_down_policy)],
        ))

    ###########################################################################
    # ImageResizer: LaunchTemplate, Private ELB, ASG, Notificaiotns

    r_imageresizer_launchtemplate = t.add_resource(
        ec2.LaunchTemplate(
            "ImageResizerLaunchTemplate",
            LaunchTemplateName="ImageResizerLaunchTemplate" + op_env,
            LaunchTemplateData=ec2.LaunchTemplateData(
                IamInstanceProfile=ec2.IamInstanceProfile(
                    Arn=GetAtt(r_imageresizer_instance_profile, "Arn"),),
                ImageId=ami_id,
                InstanceType=imageresizer_instance_type,
                KeyName=Ref(p_keyname),
                Monitoring=ec2.Monitoring(Enabled=True),
                # No need for NetworkInterfaces; instances in private subnets get private IPv4
                # addresses by default.
                SecurityGroupIds=[Ref(r_sg_ssh),
                                Ref(r_sg_resizer_ec2_healthcheck_from_elb)
                                ],
                TagSpecifications=[ec2.TagSpecifications(
                    Tags=Tags(Name="images-resizer." + op_env + ".nasawestprime.com",
                              Application="AVAIL",
                              ApplicationID="AVAIL",
                              BillingID="NIEM.62HP27",
                              WorkOrder="WP-430-WO-AVAIL-00001",
                              cloud_env="pubvpc",
                              op_env=op_env_tag,
                              customer="NIEP",
                              owner="Rodney Grubbs",
                              role="imageresizer",
                              site="images.nasa.gov",
                              tech_stack="app",
                              ansibleignore="",
                              ),
                    ResourceType=r) for r in ("instance", "volume",)],
                UserData=Base64(Join('', [
                    "#!/bin/bash -xe\n",
                    "export op_env={}\n".format(op_env),
                    "apt-get -y remove ansible\n",
                    "pip install ansible==2.1.5.0\n",
                    "mkdir {}\n".format(ec2_tarball_build_dir),
                    "cd {}\n".format(ec2_tarball_build_dir),
                    "curl --location -o {} {}\n".format(
                        ec2_tarball_imageresizer_file,
                        ec2_tarball_imageresizer_url),
                    "tar zxf {}\n".format(ec2_tarball_imageresizer_file),
                    "sh {}\n".format(ec2_tarball_imageresizer_sh),
                    "cat {}/misc/rc.local > /etc/rc.local\n".format(ec2_tarball_build_dir),
                    "ln -s {}/misc/complete-lifecycle-hook.sh /etc/init.d/\n".format(ec2_tarball_build_dir),
                    "reboot\n"
                ]))
            ),
        )
    )

    r_imageresizer_loadbalancer = t.add_resource(
        elb.LoadBalancer(
            "ImageResizerLoadBalancer",
            CrossZone=True,
            HealthCheck=elb.HealthCheck(
                Target=elb_avail_imageresizer_healthcheck,
                HealthyThreshold="3",
                UnhealthyThreshold="5",
                Interval="30",
                Timeout="5",
            ),
            Listeners=[
                elb.Listener(
                    LoadBalancerPort="80",
                    InstancePort="80",
                    Protocol="HTTP",
                    InstanceProtocol="HTTP",
                ),
                # I can do HTTPS->HTTP but need HTTPS cert
            ],
            # needed by AutoScaleGroup
            LoadBalancerName=elb_avail_imageresizer,
            SecurityGroups=[
                Ref(r_sg_resizer_elb_healthcheck),
            ],
            Scheme="internal",      # on private subnet
            Subnets=[Ref(r_subnets["app1"]), Ref(r_subnets["app2"])],
            Tags=Tags(
                Name="ImageResizer LoadBalancer",
                Application="AVAIL",
                ApplicationID="AVAIL",
                BillingID="NIEM.62HP27",
                WorkOrder="WP-430-WO-AVAIL-00001",
                cloud_env="pubvpc",
                op_env=op_env_tag,
                customer="NIEP",
                owner="Rodney Grubbs",
                role="imageresizer",
                site="images.nasa.gov",
            ),
        ))
    t.add_output(
        Output("ImageResizerELBName", Value=GetAtt(r_imageresizer_loadbalancer,
                                                   "DNSName"))
    )

    # Unused: r_dns_imageresizer =
    t.add_resource(
        route53.RecordSetType(
            "ImageResizerELBDNS",
            HostedZoneName=route53_zone_name,
            Comment="CNAME to the private ImageResizer ELB",
            Name=route53_imageresizer_elb,
            Type="CNAME",
            TTL="300",
            ResourceRecords=[GetAtt(r_imageresizer_loadbalancer, "DNSName")],
        ),
    )
    t.add_output([
        Output("ImageResizerELBDNS", Value=GetAtt(r_imageresizer_loadbalancer,
                                                  "DNSName"))
    ])

    r_imageresizer_autoscalinggroup = t.add_resource(
        autoscaling.AutoScalingGroup(
            "ImageResizerAutoscalingGroup",
            AvailabilityZones=[az_map[0], az_map[1]],
            Cooldown=300,
            DesiredCapacity=asg_avail_imageresizer_min,
            HealthCheckGracePeriod=300,
            HealthCheckType="EC2",  # or ELB
            LaunchTemplate=autoscaling.LaunchTemplateSpecification(
                LaunchTemplateId=Ref(r_imageresizer_launchtemplate),
                Version=GetAtt(r_imageresizer_launchtemplate, "LatestVersionNumber"),),
            LoadBalancerNames=[Ref(r_imageresizer_loadbalancer)],
            MaxSize=asg_avail_imageresizer_max,
            MetricsCollection=[
                autoscaling.MetricsCollection(Granularity="1Minute")],
            MinSize=asg_avail_imageresizer_min,
            NotificationConfigurations=[autoscaling.NotificationConfigurations(
                TopicARN=Ref(r_scaling_sns_topic),
                NotificationTypes=[autoscaling.EC2_INSTANCE_LAUNCH,
                                   autoscaling.EC2_INSTANCE_LAUNCH_ERROR,
                                   autoscaling.EC2_INSTANCE_TERMINATE,
                                   autoscaling.EC2_INSTANCE_TERMINATE_ERROR])],
                Tags=autoscaling.Tags(Name="images-resizer." + op_env +
                                      ".nasawestprime.com",
                                      Application="AVAIL",
                                      ApplicationID="AVAIL",
                                      BillingID="NIEM.62HP27",
                                      WorkOrder="WP-430-WO-AVAIL-00001",
                                      cloud_env="pubvpc",
                                      op_env=op_env_tag,
                                      customer="NIEP",
                                      owner="Rodney Grubbs",
                                      role="imageresizer",
                                      site="images.nasa.gov",
                                      tech_stack="app",
                                      ansibleignore="",
                                  ),
            # UpdatePolicy= UpdatePolicy() controls rolling update
            VPCZoneIdentifier=[Ref(r_subnets["app1"]),
                               Ref(r_subnets["app2"])],
        ))

    # Complete building ir_asg lifecycle hook, needs ir_asg, asg_scaling_role and scaling_sns_topic to exist
    r_imageresizer_scale_up_lifecycle_hook.AutoScalingGroupName = Ref(r_imageresizer_autoscalinggroup)
    r_imageresizer_scale_up_lifecycle_hook.LifecycleTransition = "autoscaling:EC2_INSTANCE_LAUNCHING"
    r_imageresizer_scale_up_lifecycle_hook.NotificationTargetARN = Ref(r_scaling_sns_topic)
    r_imageresizer_scale_up_lifecycle_hook.RoleARN = GetAtt(r_autoscaling_lifecycle_role, "Arn")

    r_imageresizer_scale_up_policy = t.add_resource(
        autoscaling.ScalingPolicy(
            "ImageResizerScaleUpPolicy",
            AdjustmentType="ChangeInCapacity",  # or ExactCapacity
            AutoScalingGroupName=Ref(r_imageresizer_autoscalinggroup),
            Cooldown=60,
            ScalingAdjustment="1",
        ))

    r_imageresizer_scale_down_policy = t.add_resource(
        autoscaling.ScalingPolicy(
            "ImageResizerScaleDownPolicy",
            AdjustmentType="ChangeInCapacity",  # or ExactCapacity
            AutoScalingGroupName=Ref(r_imageresizer_autoscalinggroup),
            Cooldown=300,
            ScalingAdjustment="-1",
        ))

    # Unused: r_imageresizer_cpu_alarm_high =
    t.add_resource(
        cw.Alarm(
            "ImageResizerCPUAlarmHigh",
            AlarmDescription=(
                "Alarm if CPU high or missing due to dead instance"),
            ComparisonOperator="GreaterThanThreshold",
            Dimensions=[
                cw.MetricDimension(
                    Name="AutoScalingGroupName",
                    Value=Ref(r_imageresizer_autoscalinggroup))],
            EvaluationPeriods=3,
            MetricName="CPUUtilization",
            Period="60",
            Namespace="AWS/EC2",
            Statistic="Average",
            Threshold="50",
            AlarmActions=[Ref(r_imageresizer_scale_up_policy)],
        ))

    # Unused: r_imageresizer_cpu_alarm_low =
    t.add_resource(
        cw.Alarm(
            "ImageResizerCPUAlarmLow",
            AlarmDescription="Alarm if CPU low",
            ComparisonOperator="LessThanThreshold",
            Dimensions=[
                cw.MetricDimension(
                    Name="AutoScalingGroupName",
                    Value=Ref(r_imageresizer_autoscalinggroup))],
            EvaluationPeriods=5,
            MetricName="CPUUtilization",
            Period="60",
            Namespace="AWS/EC2",
            Statistic="Average",
            Threshold="24",
            AlarmActions=[Ref(r_imageresizer_scale_down_policy)],
        ))

    ###########################################################################
    # Pipeline: LaunchTemplate, Private ELB, ASG, Notifications

    r_pipeline_launchtemplate = t.add_resource(
        ec2.LaunchTemplate(
            "PipelineLaunchTemplate",
            LaunchTemplateName="PipelineLaunchTemplate"  + op_env,
            LaunchTemplateData=ec2.LaunchTemplateData(
                BlockDeviceMappings=[
                    ec2.BlockDeviceMapping(
                        DeviceName="/dev/sda1",
                        Ebs=ec2.EBSBlockDevice(VolumeSize="550",))
                ],
                IamInstanceProfile=ec2.IamInstanceProfile(
                    Arn=GetAtt(r_pipeline_instance_profile, "Arn"),),
                ImageId=ami_id,
                InstanceType=pipeline_instance_type,
                KeyName=Ref(p_keyname),
                Monitoring=ec2.Monitoring(Enabled=True),
                # No need for NetworkInterfaces; instances in private subnets get private IPv4
                # addresses by default.
                SecurityGroupIds=[Ref(r_sg_ssh),
                                  Ref(r_sg_pipeline_ec2_healthcheck_from_elb)
                                  ],
                TagSpecifications=[ec2.TagSpecifications(
                    Tags=Tags(Name="images-pipeline." + op_env + ".nasawestprime.com",
                              Application="AVAIL",
                              ApplicationID="AVAIL",
                              BillingID="NIEM.62HP27",
                              WorkOrder="WP-430-WO-AVAIL-00001",
                              cloud_env="pubvpc",
                              op_env=op_env_tag,
                              customer="NIEP",
                              owner="Rodney Grubbs",
                              role="pipeline",
                              site="images.nasa.gov",
                              tech_stack="app",
                              ansibleignore="",
                              ),
                    ResourceType=r) for r in ("instance", "volume",)],
                UserData=Base64(Join('', [
                    "#!/bin/bash -xe\n",
                    "export op_env={}\n".format(op_env),
                    "apt-get -y remove ansible\n",
                    "pip install ansible==2.1.5.0\n",
                    "mkdir {}\n".format(ec2_tarball_build_dir),
                    "cd {}\n".format(ec2_tarball_build_dir),
                    "curl --location -o {} {}\n".format(
                        ec2_tarball_pipeline_file,
                        ec2_tarball_pipeline_url),
                    "tar zxf {}\n".format(ec2_tarball_pipeline_file),
                    "sh {}\n".format(ec2_tarball_pipeline_sh),
                    "cat {}/misc/rc.local > /etc/rc.local\n".format(ec2_tarball_build_dir),
                    "ln -s {}/misc/complete-lifecycle-hook.sh /etc/init.d/\n".format(ec2_tarball_build_dir),
                    "reboot\n"
                ]))
            ),
        )
    )

    r_pipeline_loadbalancer = t.add_resource(
        elb.LoadBalancer(
            "PipelineLoadBalancer",
            CrossZone=True,
            HealthCheck=elb.HealthCheck(
                Target=elb_avail_pipeline_healthcheck,
                HealthyThreshold="3",
                UnhealthyThreshold="5",
                Interval="30",
                Timeout="5",
            ),
            Listeners=[
                elb.Listener(
                    LoadBalancerPort="80",
                    InstancePort="80",
                    Protocol="HTTP",
                    InstanceProtocol="HTTP",
                ),
                # I can do HTTPS->HTTP but need HTTPS cert
            ],
            LoadBalancerName=elb_avail_pipeline,  # needed by AutoScaleGroup
            SecurityGroups=[
                Ref(r_sg_pipeline_elb_healthcheck),
            ],
            Scheme="internal",      # on private subnet
            Subnets=[Ref(r_subnets["app1"]), Ref(r_subnets["app2"])],
            Tags=Tags(
                Name="Pipeline LoadBalancer",
                Application="AVAIL",
                ApplicationID="AVAIL",
                BillingID="NIEM.62HP27",
                WorkOrder="WP-430-WO-AVAIL-00001",
                cloud_env="pubvpc",
                op_env=op_env_tag,
                customer="NIEP",
                owner="Rodney Grubbs",
                role="pipeline",
                site="images.nasa.gov",
            ),
        ))
    t.add_output(
        Output("PipelineELBName",
               Value=GetAtt(r_pipeline_loadbalancer, "DNSName"))
    )

    # Unused: r_dns_pipeline =
    t.add_resource(
        route53.RecordSetType(
            "PipelineELBDNS",
            HostedZoneName=route53_zone_name,
            Comment="CNAME to the private Pipeline ELB",
            Name=route53_pipeline_elb,
            Type="CNAME",
            TTL="300",
            ResourceRecords=[GetAtt(r_pipeline_loadbalancer, "DNSName")],
        ),
    )
    t.add_output([
        Output("PipelineELBDNS", Value=GetAtt(r_imageresizer_loadbalancer,
                                              "DNSName"))
    ])

    r_pipeline_autoscalinggroup = t.add_resource(
        autoscaling.AutoScalingGroup(
            "PipelineAutoscalingGroup",
            AvailabilityZones=[az_map[0], az_map[1]],
            Cooldown=300,
            DesiredCapacity=asg_avail_pipeline_min,
            HealthCheckGracePeriod=300,
            HealthCheckType="EC2",  # or ELB
            LaunchTemplate=autoscaling.LaunchTemplateSpecification(
                LaunchTemplateId=Ref(r_pipeline_launchtemplate),
                Version=GetAtt(r_pipeline_launchtemplate, "LatestVersionNumber"),),
            LoadBalancerNames=[Ref(r_pipeline_loadbalancer)],
            MaxSize=asg_avail_pipeline_max,
            MetricsCollection=[
                autoscaling.MetricsCollection(Granularity="1Minute")],
            MinSize=asg_avail_pipeline_min,
            NotificationConfigurations=[autoscaling.NotificationConfigurations(
                TopicARN=Ref(r_scaling_sns_topic),
                NotificationTypes=[autoscaling.EC2_INSTANCE_LAUNCH,
                                   autoscaling.EC2_INSTANCE_LAUNCH_ERROR,
                                   autoscaling.EC2_INSTANCE_TERMINATE,
                                   autoscaling.EC2_INSTANCE_TERMINATE_ERROR])],
            Tags=autoscaling.Tags(Name="images-pipeline." + op_env +
                                  ".nasawestprime.com",
                                  Application="AVAIL",
                                  ApplicationID="AVAIL",
                                  BillingID="NIEM.62HP27",
                                  WorkOrder="WP-430-WO-AVAIL-00001",
                                  cloud_env="pubvpc",
                                  op_env=op_env_tag,
                                  customer="NIEP",
                                  owner="Rodney Grubbs",
                                  role="pipeline",
                                  site="images.nasa.gov",
                                  tech_stack="app",
                                  ansibleignore="",
                                  ),
            # UpdatePolicy= UpdatePolicy() controls rolling update
            VPCZoneIdentifier=[Ref(r_subnets["app1"]),
                               Ref(r_subnets["app2"])],
        ))

    # Complete building pipeline_asg lifecycle hook, needs pipeline_asg, asg_scaling_role and scaling_sns_topic to exist
    r_pipeline_scale_up_lifecycle_hook.AutoScalingGroupName = Ref(r_pipeline_autoscalinggroup)
    r_pipeline_scale_up_lifecycle_hook.LifecycleTransition = "autoscaling:EC2_INSTANCE_LAUNCHING"
    r_pipeline_scale_up_lifecycle_hook.NotificationTargetARN = Ref(r_scaling_sns_topic)
    r_pipeline_scale_up_lifecycle_hook.RoleARN = GetAtt(r_autoscaling_lifecycle_role, "Arn")

    r_pipeline_scale_up_policy = t.add_resource(
        autoscaling.ScalingPolicy(
            "PipelineScaleUpPolicy",
            AdjustmentType="ChangeInCapacity",  # or ExactCapacity
            AutoScalingGroupName=Ref(r_pipeline_autoscalinggroup),
            Cooldown=60,
            ScalingAdjustment="1",
        ))

    r_pipeline_scale_down_policy = t.add_resource(
        autoscaling.ScalingPolicy(
            "PipelineScaleDownPolicy",
            AdjustmentType="ChangeInCapacity",  # or ExactCapacity
            AutoScalingGroupName=Ref(r_pipeline_autoscalinggroup),
            Cooldown=300,
            ScalingAdjustment="-1",
        ))

    # Unused: r_pipeline_cpu_alarm_high =
    t.add_resource(
        cw.Alarm(
            "PipelineCPUAlarmHigh",
            AlarmDescription=(
                "Alarm if CPU high or missing due to dead instance"),
            ComparisonOperator="GreaterThanThreshold",
            Dimensions=[
                cw.MetricDimension(Name="AutoScalingGroupName",
                                   Value=Ref(r_pipeline_autoscalinggroup))],
            EvaluationPeriods=3,
            MetricName="CPUUtilization",
            Period="60",
            Namespace="AWS/EC2",
            Statistic="Average",
            Threshold="27",
            AlarmActions=[Ref(r_pipeline_scale_up_policy)],
        ))

    # Unused: r_pipeline_cpu_alarm_low =
    t.add_resource(
        cw.Alarm(
            "PipelineCPUAlarmLow",
            AlarmDescription="Alarm if CPU low",
            ComparisonOperator="LessThanThreshold",
            Dimensions=[
                cw.MetricDimension(Name="AutoScalingGroupName",
                                   Value=Ref(r_pipeline_autoscalinggroup))],
            EvaluationPeriods=5,
            MetricName="CPUUtilization",
            Period="60",
            Namespace="AWS/EC2",
            Statistic="Average",
            Threshold="22",
            AlarmActions=[Ref(r_pipeline_scale_down_policy)],
        ))

    return t

###############################################################################


def get_template_json(config, dev, prod):
    """Get Troposphere template object, return JSON."""
    template = get_template(config, dev, prod)
    return template.to_json()


def main():
    """Entrypoint to use as command."""
    parser = argparse.ArgumentParser(
        description="Create CloudFormation template.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        usage='%(prog)s $env.ini'
        )
    parser.add_argument("inifile", help='''
        .ini file for configuration settings.
        i.e. infrastructure.py dev.ini > availdev.json
    ''')
    parser.parse_args()
    args = parser.parse_args()
    config = configparser.RawConfigParser()
    # Preserve key case, e.g., for QueueNames
    config.optionxform = lambda option: option
    config.read(args.inifile)

    if config['AWS']['op_env'] == "dev":
        dev = True
    else:
        dev = False

    if config['AWS']['op_env'] == "stage":
        stage = True
    else:
        stage = False

    if config['AWS']['op_env'] == "prod":
        prod = True
    else:
        prod = False

    template_json = get_template_json(config, dev, prod)
    print(template_json)

if __name__ == "__main__":
    main()

# yapf:enable
