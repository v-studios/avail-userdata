"""bootstrap package exceptions.

Copyright 2015 Reed O'Brien <reed@v-studios.com>. All Rights Reserved.
"""


class BootstrapException(Exception):

    """A base exception fro the bootstrap package."""


class InvalidDeploymentEnvironment(BootstrapException):

    """An Exception for and env not in ENVIRONS."""
