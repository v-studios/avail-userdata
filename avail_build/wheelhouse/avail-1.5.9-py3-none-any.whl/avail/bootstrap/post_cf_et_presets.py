#!/usr/bin/env python
# ElasticTranscoder (like CloudSearch) has no CloudFormation support
# so we have to do this (like CS) with a boto script.
# Copyright 2015 AVAIL team. All Rights Reserved.

"""Create ElasticTranscoder presets for video, thumbnails, audio."""


import argparse
import configparser

import boto3

from botocore.exceptions import ClientError

# Presets concurred after much disussion with Bryan:
# https://docs.google.com/document/d/1mc_bCPunNyP25Z0yMAWvP7zJO_jw1ofaZplJ5NyVi3s/edit

PRESETS = [
    {
        'Name': 'AVAIL-Scaled-Large1080',
        'Description': '1920x1080 fps=30 kbps=5000, thumb=384x212, audio=48KHz@160Kbps',
        'Audio': {
            'BitRate': '160',
            'Channels': '2',
            'Codec': 'AAC',
            'CodecOptions': {'Profile': 'AAC-LC'},
            'SampleRate': '48000',
        },
        'Container': 'mp4',
        'Thumbnails': {
            'Format': 'png',
            'Interval': '60',
            'MaxHeight': '212',
            'MaxWidth':  '384',
            'PaddingPolicy': 'NoPad',
            'SizingPolicy': 'ShrinkToFit',
        },
        'Video': {
            'BitRate':   '5000',
            'Codec': 'H.264',
            'CodecOptions': {
                'ColorSpaceConversionMode': 'None',
                'InterlacedMode': 'Progressive',
                'Level': '4.1',
                'MaxReferenceFrames': '3',
                'Profile': 'high',
            },
            'DisplayAspectRatio': 'auto',
            'FixedGOP': 'false',
            'FrameRate':   '30',
            'KeyframesMaxDist': '90',
            'MaxHeight': '1080',
            'MaxWidth':  '1920',
            'PaddingPolicy': 'NoPad',
            'SizingPolicy': 'ShrinkToFit',
        },
    },
    {
        'Name': 'AVAIL-Scaled-Large720',
        'Description': '1280x720 fps=same_max60 kbps=5000, thumb=384x212, audio=48KHz@160Kbps',
        'Audio': {
            'BitRate': '160',
            'Channels': '2',
            'Codec': 'AAC',
            'CodecOptions': {'Profile': 'AAC-LC'},
            'SampleRate': '48000',
        },
        'Container': 'mp4',
        'Thumbnails': {
            'Format': 'png',
            'Interval': '60',
            'MaxHeight': '212',
            'MaxWidth':  '384',
            'PaddingPolicy': 'NoPad',
            'SizingPolicy': 'ShrinkToFit',
        },
        'Video': {
            'BitRate':    '5000',
            'FrameRate':  'auto',
            'Codec': 'H.264',
            'CodecOptions': {
                'ColorSpaceConversionMode': 'None',
                'InterlacedMode': 'Progressive',
                'Level': '4.1',
                'MaxReferenceFrames': '3',
                'Profile': 'high',
            },
            'DisplayAspectRatio': 'auto',
            'FixedGOP': 'false',
            'KeyframesMaxDist': '90',
            'MaxFrameRate': '60',
            'MaxHeight':   '720',
            'MaxWidth':   '1280',
            'PaddingPolicy': 'NoPad',
            'SizingPolicy': 'ShrinkToFit',
        },
    },

    {
        'Name': 'AVAIL-Scaled-Medium',
        'Description': '1280x720 fps=30 kbps=2200, thumb=384x212, audio=48KHz@160Kbps',
        'Audio': {
            'BitRate': '160',
            'Channels': '2',
            'Codec': 'AAC',
            'CodecOptions': {'Profile': 'AAC-LC'},
            'SampleRate': '48000',
        },
        'Container': 'mp4',
        'Thumbnails': {
            'Format': 'png',
            'Interval': '60',
            'MaxHeight': '212',
            'MaxWidth':  '384',
            'PaddingPolicy': 'NoPad',
            'SizingPolicy': 'ShrinkToFit',
        },
        'Video': {
            'BitRate':  '2200',
            'FrameRate':  '30',
            'Codec': 'H.264',
            'CodecOptions': {
                'ColorSpaceConversionMode': 'None',
                'InterlacedMode': 'Progressive',
                'Level': '3.1',
                'MaxReferenceFrames': '3',
                'Profile': 'main',
            },
            'DisplayAspectRatio': 'auto',
            'FixedGOP': 'false',
            'KeyframesMaxDist': '90',
            'MaxHeight': '720',
            'MaxWidth': '1280',
            'PaddingPolicy': 'NoPad',
            'SizingPolicy': 'ShrinkToFit',
        },
    },
    {
        'Name': 'AVAIL-Scaled-Small',
        'Description': '640x480 fps=30 kbps=2200, thumb=384x212, audio=22KHz@40Kbps',
        'Audio': {
            'BitRate':       '40',
            'Channels': '2',
            'Codec': 'AAC',
            'CodecOptions': {'Profile': 'auto'},
            'SampleRate': '22050',
        },
        'Container': 'mp4',
        'Thumbnails': {
            'Format': 'png',
            'Interval': '60',
            'MaxHeight': '212',
            'MaxWidth':  '384',
            'PaddingPolicy': 'NoPad',
            'SizingPolicy': 'ShrinkToFit',
        },
        'Video': {
            'BitRate':  '1500',
            'Codec': 'H.264',
            'CodecOptions': {
                'ColorSpaceConversionMode': 'None',
                'InterlacedMode': 'Progressive',
                'Level': '3',
                'MaxReferenceFrames': '3',
                'Profile': 'baseline',
            },
            'DisplayAspectRatio': 'auto',
            'FixedGOP': 'false',
            'FrameRate':  '30',
            'KeyframesMaxDist': '90',
            'MaxHeight': '480',
            'MaxWidth':  '640',
            'PaddingPolicy': 'NoPad',
            'SizingPolicy': 'ShrinkToFit',
        },
    },
    {
        'Name': 'AVAIL-Mandatory-Preview',
        'Description': '480x360 fps=30 kbps=2200, thumb=480x360, audio=22KHz@40Kbps',
        'Audio': {
            'BitRate':       '40',
            'Channels': '2',
            'Codec': 'AAC',
            'CodecOptions': {'Profile': 'auto'},
            'SampleRate': '22050',
        },
        'Container': 'mp4',
        'Thumbnails': {
            # Wanted 768x432 but ET won't create thumbs larger than video
            'Format': 'png',
            'Interval': '60',
            'MaxHeight': '360',
            'MaxWidth':  '480',
            'PaddingPolicy': 'NoPad',
            'SizingPolicy': 'ShrinkToFit',
        },
        'Video': {
            'BitRate':   '600',
            'Codec': 'H.264',
            'CodecOptions': {
                'Profile': 'baseline',
                'ColorSpaceConversionMode': 'None',
                'InterlacedMode': 'Progressive',
                'Level': '3',
                'MaxReferenceFrames': '3',
            },
            'DisplayAspectRatio': 'auto',
            'FixedGOP': 'false',
            'FrameRate':  '30',
            'MaxHeight': '360',
            'MaxWidth':  '480',
            'KeyframesMaxDist': '90',
            'PaddingPolicy': 'NoPad',
            'SizingPolicy': 'ShrinkToFit',

        },
    },
    {
        'Name': 'AVAIL-Mandatory-Mobile',
        'Description': '320x240 fps=15 kbps=300, thumb=192x108, audio=22KHz@40Kbps',
        'Audio': {
            'BitRate':       '40',
            'Channels': '2',
            'Codec': 'AAC',
            'CodecOptions': {'Profile': 'auto'},
            'SampleRate': '22050',
        },
        'Container': 'mp4',
        'Thumbnails': {
            'Format': 'png',
            'Interval': '60',
            'MaxHeight': '108',
            'MaxWidth':  '192',
            'PaddingPolicy': 'NoPad',
            'SizingPolicy': 'ShrinkToFit',
        },
        'Video': {
            'BitRate':   '300',
            'Codec': 'H.264',
            'CodecOptions': {
                'Profile': 'baseline',
                'ColorSpaceConversionMode': 'None',
                'InterlacedMode': 'Progressive',
                'Level': '3',
                'MaxReferenceFrames': '3',
            },
            'DisplayAspectRatio': 'auto',
            'FixedGOP': 'false',
            'FrameRate':  '15',
            'KeyframesMaxDist': '90',
            'MaxHeight': '240',
            'MaxWidth':  '320',
            'PaddingPolicy': 'NoPad',
            'SizingPolicy': 'ShrinkToFit',
        },
    },
    {
        'Name': 'AVAIL-Mandatory-AnimGIF',
        'Description': '348x216 fps=15 kbps=400, thumb=192x108, audio=none',
        'Container': 'gif',
        'Thumbnails': {
            'Format': 'png',
            'Interval': '300',  # from AWS
            'MaxHeight': '108',
            'MaxWidth':  '192',
            'PaddingPolicy': 'NoPad',
            'SizingPolicy': 'ShrinkToFit',
        },
        'Video': {
            'BitRate':   '400',
            'Codec':     'gif',
            'CodecOptions': {'LoopCount': 'Infinite'},
            'DisplayAspectRatio': 'auto',
            'FrameRate':  '15',
            'MaxHeight': '216',
            'MaxWidth':  '348',
            'PaddingPolicy': 'NoPad',
            'SizingPolicy': 'ShrinkToFit',
        },
    },
]


def create_elastictranscoder_presets(config):
    """Create video, audio, thumbnail presets specific to NIEP and front-end needs.

    We need custom settings of our output videos and their thumbnails. Some
    videos need to be 'auto' (same) framerate to support 60fps incoming, and
    thumbnail images need to be larger than the default 192 width so hover over
    images look good.  We'll create custom "AVAIL-*" presets for each of our 5
    sizes: optional scaled large, medium, small; mandatory preview, mobile.

    All videos will be created with thumbnails and preserve audio; while we don't
    see a need for audio in the 'preview' size, it may bite us in the ass if we
    omit it.

    Thumbnails will be shrink to fit, with no padding (so we don't add
    unremovable black bars).

    We're gonna try the Animated GIF to see if it might be useful, especially
    for video previews on mobile.
    """
    et = boto3.client('elastictranscoder')
    res = et.list_presets(Ascending='false')  # return newest first, presumably ours
    extant_presets = [p['Name'] for p in res['Presets'] if p['Type'] != 'System']

    for preset in PRESETS:
        if preset['Name'] in extant_presets:
            print('SKIP extant preset name={}'.format(preset['Name']))
            continue
        try:
            res = et.create_preset(**preset)
        except ClientError as e:
            print('Error creating name={}: {}'.format(preset['Name'], e))
            continue
        if res['ResponseMetadata']['HTTPStatusCode'] != 201:
            print('HTTP error creating: {}'.format(res['ResponseMetadata']))
        elif res['Warning']:
            print('WARNING when creating name={}: {}'.format(preset['Name'], res['Warning']))
        else:
            print('Created id={} name={}'.format(res['Preset']['Id'], res['Preset']['Name']))


def main():
    """Entrypoint to run all steps."""
    parser = argparse.ArgumentParser(
        description="Create ElasticTranscoder Presets.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        usage='%(prog)s $env.ini'
        )
    parser.add_argument(
        "inifile",
        help="Environment-specific .ini file for config settings.")
    args = parser.parse_args()
    config = configparser.RawConfigParser()
    # Preserve key case, e.g., for QueueNames
    config.optionxform = lambda option: option
    config.read(args.inifile)
    create_elastictranscoder_presets(config)


if __name__ == "__main__":
    main()
