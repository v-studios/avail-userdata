"""
Copyright 2015 AVAIL Authors. See AUTHORS.txt in the root of the repo.

Ensure bootstrap is included in package by pip wheel.
"""
