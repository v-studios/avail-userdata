# Copyright 2019 AVAIL Authors.
"""Library for use with migrate_cloudsearch_content.py."""

import logging

import boto3


LOG_INTERVAL = 100
SEARCH_SIZE = 1000


def get_all_docs(domain):
    """A generator to return all docs for a CloudSearch domain.

    :param str domain: name of the CloudSearch domain
    "return: doc for each call of the enumerator
    """
    css = get_search_client(domain)
    num = 0
    cursor = 'initial'
    while True:
        ret = css.search(query='matchall', queryParser='structured',
                         cursor=cursor, size=SEARCH_SIZE)
        ret_meta = ret.pop('ResponseMetadata')
        if ret_meta['HTTPStatusCode'] != 200:
            raise ValueError('Bad status from search')
        hits = ret['hits']
        if not hits['hit']:
            logging.info('cloudsearch found no more hits, breaking')
            break
        found = hits['found']
        cursor = hits.get('cursor')
        for hit in hits['hit']:
            num += 1
            if not num % LOG_INTERVAL:
                logging.info('cloudsearch doc #%s of %s: cs_id=%s' % (
                    num, found, hit['id']))
            yield {'id': hit['id'], 'fields': hit['fields']}


def get_fields(domain):
    """Return dict of fields and definitions.

    field_name: {'IndexFieldName': 'thename',
                 'IndexFieldType': 'thetype', 'TypeSpecificOptions': {...}}
    """
    csc = boto3.client('cloudsearch')
    ret = csc.describe_index_fields(DomainName=domain)['IndexFields']
    return {f['Options']['IndexFieldName']: f['Options'] for f in ret}


def get_search_domain(domain):
    """Return dict of CS search/doc endpoints, ARN."""
    return boto3.client('cloudsearch').describe_domains(
        DomainNames=[domain])['DomainStatusList'][0]


def get_search_client(domain):
    """Return a cloudsearch search client for the given domain_name."""
    cs_domain = get_search_domain(domain)
    return boto3.client('cloudsearchdomain',
                        endpoint_url=('https://' +
                                      cs_domain['SearchService']['Endpoint']))


def get_doc_client(domain):
    """Return a cloudsearch doc client for the given domain_name."""
    cs_domain = get_search_domain(domain)
    return boto3.client('cloudsearchdomain',
                        endpoint_url=('https://' +
                                      cs_domain['DocService']['Endpoint']))
