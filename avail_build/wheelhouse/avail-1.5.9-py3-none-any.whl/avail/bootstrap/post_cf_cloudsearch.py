#!/usr/bin/env python
# Copyright 2019 AVAIL Authors. See AUTHORS.txt in the root of the repo.

"""After Troposphere/Cloudformation create Cloudsearch which is not CF-able.

Idempotently create CloudSearch domain and indices, updating only if needed.
This version uses the albums-oriented indices, not the original single-item.

In the 2013 CloudSearch API, Literal fields are now case-sensitive which makes
them useless for user-entered data like nasa_id, center, and keywords. We'll
have to use Text fields for them; if we had controlled vocabularies for Center
and Keywords, we could enforce lowercase and standard names, but we can't for
this application.  Text fields preclude using them as Facets; Facets seems not
useful for datetimes; if we had just years, it could be very useful, but not
for really for datetimes that go down to the millisecond.
"""

import json
import logging
from argparse import ArgumentDefaultsHelpFormatter, ArgumentParser

import boto3

from avail.metadata import PROPERTIES


# CloudSearch Names must match regex: ([a-z][a-z0-9_]*\*?|\*[a-z0-9_]*)
# so we use python names. These must match the names in avail.metadata.

FIELDS = {
    'album': {
        'IndexFieldName': 'album',
        'IndexFieldType': 'literal-array',
        'LiteralArrayOptions': {
            'FacetEnabled': True,
            'ReturnEnabled': True,
            'SearchEnabled': True,
        },
    },
    'album_text':  {
        'IndexFieldName': 'album_text',
        'IndexFieldType': 'text-array',
        'TextArrayOptions': {
            'AnalysisScheme': '_en_default_',
            'HighlightEnabled': False,
            'ReturnEnabled': False,  # search-only, no return or updates
            'SourceFields': 'album',
        },
    },
    'center': {
        'IndexFieldName': 'center',
        'IndexFieldType': 'text',
        'TextOptions': {
            'AnalysisScheme': '_en_default_',
            'SortEnabled': True,
            'HighlightEnabled': True,
            'ReturnEnabled': True,
        },
    },
    'date_created': {
        'IndexFieldName': 'date_created',
        'IndexFieldType': 'date',
        'DateOptions': {
            'SearchEnabled': True,
            'SortEnabled': True,
            'ReturnEnabled': True,
        },
    },
    'description': {
        'IndexFieldName': 'description',
        'IndexFieldType': 'text',
        'TextOptions': {
            'AnalysisScheme': '_en_default_',
            'SortEnabled': True,
            'HighlightEnabled': True,
            'ReturnEnabled': True,
        },
    },
    'description_508': {
        'IndexFieldName': 'description_508',
        'IndexFieldType': 'text',
        'TextOptions': {
            'AnalysisScheme': '_en_default_',
            'SortEnabled': True,
            'HighlightEnabled': True,
            'ReturnEnabled': True,
        },
    },
    'keywords': {
        'IndexFieldName': 'keywords',
        'IndexFieldType': 'text-array',
        'TextArrayOptions': {
            'AnalysisScheme': '_en_default_',
            'HighlightEnabled': True,
            'ReturnEnabled': True,
        },
    },
    'location': {
        'IndexFieldName': 'location',
        'IndexFieldType': 'text',
        'TextOptions': {
            'AnalysisScheme': '_en_default_',
            'SortEnabled': True,
            'HighlightEnabled': True,
            'ReturnEnabled': True,
        },
    },
    'media_type': {
        'IndexFieldName': 'media_type',
        'IndexFieldType': 'literal',
        'LiteralOptions': {
            'FacetEnabled': True,
            'SearchEnabled': True,
            'SortEnabled': True,
            'ReturnEnabled': True,
        },
    },
    'nasa_id': {
        'IndexFieldName': 'nasa_id',
        'IndexFieldType': 'text',
        'TextOptions': {
            'AnalysisScheme': '_en_default_',
            'SortEnabled': True,
            'HighlightEnabled': True,
            'ReturnEnabled': True,
        },
    },
    'nasa_id_exact': {
        'IndexFieldName': 'nasa_id_exact',
        'IndexFieldType': 'literal',
        'LiteralOptions': {
            'FacetEnabled': False,
            'SearchEnabled': True,
            'SortEnabled': False,
            'ReturnEnabled': False,
            'SourceField': 'nasa_id',
        },
    },
    'owner': {
        'IndexFieldName': 'owner',
        'IndexFieldType': 'literal',  # use lowercase AUID
        'LiteralOptions': {
            'FacetEnabled': True,
            'SearchEnabled': True,
            'SortEnabled': True,
            'ReturnEnabled': True,
        },
    },
    'photographer': {
        'IndexFieldName': 'photographer',
        'IndexFieldType': 'text',
        'TextOptions': {
            'AnalysisScheme': '_en_default_',
            'SortEnabled': True,
            'HighlightEnabled': True,
            'ReturnEnabled': True,
        },
    },
    'secondary_creator': {
        'IndexFieldName': 'secondary_creator',
        'IndexFieldType': 'text',
        'TextOptions': {
            'AnalysisScheme': '_en_default_',
            'SortEnabled': True,
            'HighlightEnabled': True,
            'ReturnEnabled': True,
        },
    },
    'title': {
        'IndexFieldName': 'title',
        'IndexFieldType': 'text',
        'TextOptions': {
            'AnalysisScheme': '_en_default_',
            'SortEnabled': True,
            'HighlightEnabled': True,
            'ReturnEnabled': True,
        },
    },
}

# Caution: API allows us to set bad access policies, like cloudsearch:BOGUS

ACCESS_BY_IP = {
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "Search, Suggest, Documents -- from ANYWHERE",
            "Effect": "Allow",
            "Principal": "*",  # don't need if Condition clause
            "Action": [
                "cloudsearch:search",
                "cloudsearch:suggest",
                "cloudsearch:document",
            ],
            "Condition": {"IpAddress": {"aws:SourceIp": "0.0.0.0/32"}},
        }
    ]
}

CSC = boto3.client('cloudsearch')
LOG = logging.getLogger(name=__name__)


def main():
    """Compare indices with AVAIL props, create domain and indices and reindex if needed.

    There is an entry point for this defined in setup.py.
    """
    logging.basicConfig(level=logging.INFO)
    parser = ArgumentParser(description=('Idempotently create CloudSearch domain and indices,'
                                         ' updating if needed; uses albums-oriented indices'),
                            formatter_class=ArgumentDefaultsHelpFormatter)
    parser.add_argument('-d', '--domain', required=True,
                        help='cloudsearch domain name')
    parser.add_argument('-n', '--dry-run', action='store_true', default=False,
                        help='Do not actually change indices, takes a long time, dangerous')
    args = parser.parse_args()

    # Ensure our CS indices match our AVAIL Properties
    _verify_indices()

    # If domain doesn't exist, create it and apply access control
    res = CSC.describe_domains(DomainNames=[args.domain])
    logging.info('Checking for existing domain=%s', args.domain)
    if not res['DomainStatusList']:
        logging.info('Creating domain=%s', args.domain)
        newdomain = CSC.create_domain(DomainName=args.domain)
        logging.info('domain={}'.format(newdomain))
        # Set the IP access restrictions on the domain
        logging.info('Creating access policies')
        CSC.update_service_access_policies(
            DomainName=args.domain,
            AccessPolicies=json.dumps(ACCESS_BY_IP),
        )

    # Create/update indexes if needed
    LOG.info('Updating indices...')
    fields_now = _get_fields(args.domain)
    need_reindex = False
    for name, field in sorted(FIELDS.items()):  # sort so album exists before album_text refs it
        if name in fields_now and field == fields_now[name]:
            LOG.info('Skipping same definition for field=%s' % name)
            continue
        LOG.info('Update field=%s' % name)
        if name not in fields_now:
            LOG.warning('Create  field=%s' % field)
        else:
            LOG.warning('Update  field=%s' % field)
            LOG.warning('Current field=%s' % fields_now[name])
        if args.dry_run:
            LOG.warning('DRYRUN not changing field=%s' % field)
            continue
        res = CSC.define_index_field(DomainName=args.domain, IndexField=field)
        state = res['IndexField']['Status']['State']
        version = res['IndexField']['Status']['UpdateVersion']
        LOG.info('Index "%s" State=%s Version=%s' % (field['IndexFieldName'], state, version))
        if state == 'RequiresIndexDocuments':
            need_reindex = True

    # Reindex any indexes we changed
    LOG.info('Indexing docs...')
    if need_reindex and not args.dry_run:
        res = CSC.index_documents(DomainName=args.domain)
        LOG.warning('Indexing fields: %s' % res['FieldNames'])
    else:
        LOG.info('Indexing docs not needed')


def _verify_indices():
    """Compare indices with avail metadata properties.

    Our CloudSearch ``album_text`` is a mirror of ``album``, and
    ``nasa_id_exact`` mirrors ``nasa_id``, and not something in our AVAIL
    PROPERTIES, so omit them from the comparison.

    """
    indices = FIELDS.keys() - ['album_text', 'nasa_id_exact']
    missing_props = set(PROPERTIES) - set(indices)
    missing_indices = set(indices) - set(PROPERTIES)
    if missing_props:
        logging.critical("Metadata '{}' not found in indices".format(missing_props))
    if missing_indices:
        logging.critical("Indices '{}' not found in Metadata".format(missing_indices))
    if missing_props or missing_indices:
        raise RuntimeError("Metadata PROPERTIES doesn't match indices")
    LOG.info('Indexes match AVAIL PROPERTIES')


def _get_fields(domain):
    """Return dict of CloudSearch domain's fields and definitions.

    field_name: {'IndexFieldName': 'thename',
                 'IndexFieldType': 'thetype',
                 'TypeSpecificOptions': {...}}
    """
    res = CSC.describe_index_fields(DomainName=domain)['IndexFields']
    return {f['Options']['IndexFieldName']: f['Options'] for f in res}


if __name__ == '__main__':
    main()
