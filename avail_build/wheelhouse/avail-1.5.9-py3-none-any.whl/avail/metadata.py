"""
Read (later, and write) metadata from streams and files.

Copyright (c) 2015 - 2019 AVAIL Authors. See AUTHORS.txt in the root of the repo.
"""

import json
import os

from pprint import pformat

import dateutil

from zope.interface import implementer

from .interfaces import IMetadata

METADATA_FILENAME = "metadata.json"

# This PROPERTIES must match the @properties below, and the names of the
# indices defined in the CloudSearch creation
# (avail/avail/bootstrap/post_cf_setup.py). cloudsearch.create() and .find()
# reference this. Excluded from this are: city, country, state as we only
# search on 'location' which is a combined field.

PROP_MAP = {"album": "Album",
            "center": "Center",
            "date_created": "DateCreated",
            "description": "Description",
            "description_508": "Description508",
            "keywords": "Keywords",
            "location": "Location",
            "media_type": "MediaType",
            "nasa_id": "NASAID",
            "owner": "Owner",   # AUID
            "photographer": "Photographer",
            "secondary_creator": "SecondaryCreator",
            "title": "Title"}
PROPERTIES = PROP_MAP.keys()
AVAILNAMES = PROP_MAP.values()
LISTY_PROPS = ("album", "keywords")


@implementer(IMetadata)
class Metadata(object):
    r"""Access metadata by sections and accessors.

    Given a JSON string as returned by `exiftool` with attributes
    tagged by group name (e.g., "XMP:Creator": "NASA/Bill Ingalls"),
    provide accessors for each section (e.g., IPTC, XMP) as well as
    properties defined by our requirements (a.k.a. Idiots Guide) and
    spreadsheets mapping NASA Standards, IPTC specs, and UI labels.

    The JSON string is that returned from exiftool which can be
    invoked on the first 128K of the file, where the metadata should
    live, like::

      head -c 131072 2014102230003HQ.jpg | exiftool -sort -a -S -G -j -

    CloudSearch Names must match regex: ([a-z][a-z0-9_]*\*?|\*[a-z0-9_]*)
    so we use Python naming for our properties class.
    """

    def __init__(self, jsonstr):
        """Initialize.

        Load the jsonstr into a the _md dict.

        Create our private AVAIL:* attrs if not already there by looking for
        properties, which in turn search JSON names.

        We'd like a plain dict for our jsonstr, but exiftool gives us a list of
        dict; e.g., instead of {...}, it gives a [{...}]. We'll tolerate both
        as it's really confusing not to handle the listified dict.

        :param jsonstr: JSON string with groups as provided by `exiftool -j -G`
        :type  jsonstr: str
        """
        # Initialize some placeholders.
        self.PROPERTIES = PROPERTIES
        self._app14_items = None
        self._avail_items = None
        self._composite_items = None
        self._exif_items = None
        self._file_items = None
        self._icc_profile_items = None
        self._iptc_items = None
        self._photoshop_items = None
        self._xmp_items = None
        # Try to unserialize the JSON string that was passed in.
        try:
            self._md = json.loads(jsonstr)
        except ValueError:
            raise ValueError("Could not load JSON from string")
        # If a list containing a dictionary was passed in, extract the
        # dictionary to use as self._md.
        if type(self._md) is list:
            if len(self._md) != 1:
                raise ValueError("jsonstr list len={} must be 1".format(
                    len(self._md)))
            self._md = self._md[0]
        # Make sure self._md is a dictionary.
        if type(self._md) != dict:
            raise ValueError("jsonstr must be dict or list of dict")
        # Check for/set the NASA ID this metadata object belongs to. Fail if
        # this can't be done - NASA ID is absolutely required for a Metadata
        # object to be meaningful.
        if not self.nasa_id:
            # If there's enough information to set NASA ID, do so.
            fname = self.file('FileName')
            # When you stream from stdin, exiftool sets the filename equal to
            # '-' (stdin).
            if fname and fname != '-':
                # Compute NASA ID from filename.
                nasa_id = os.path.splitext(fname)[0]
                self._md['AVAIL:NASAID'] = nasa_id
            else:
                raise ValueError('No existing NASA ID and unusable filename={}.'.format(
                    fname))
        # Set all the "AVAIL:" keys. If there was sufficient information in the
        # input, set them to non-empty values. Otherwise, set them to empty
        # values that make sense based on the type we expect in the future.
        for prop, name in PROP_MAP.items():
            avail_name = "AVAIL:" + name
            if self._md.get(avail_name) in (None, '', [], ['']):  # empty values
                val = getattr(self, prop)
                # If there's already a non-falsey value, set it.
                if val and val != ['']:  # treat [''] as empty, falsey
                    self._set_md(name, val)
                # Otherwise, set a default value so all metadata has the full
                # "AVAIL:" shape. "" for non-keywords, and [] for keywords.
                elif prop not in LISTY_PROPS:
                    self._set_md(name, "")
                elif prop in LISTY_PROPS:
                    self._set_md(name, [])
            elif prop in LISTY_PROPS:  # Ensure album and keywords are lists
                    self._set_md(name, getattr(self, prop))

    def __str__(self):
        """Return human-readable summary of this instance."""
        return pformat(self._md)

    # Group individual entries

    def app14(self, key):
        """Return item matching `key` from APP14 group.

        :param key: key to find in the group
        :type  key: str
        """
        return self._md.get("APP14:{}".format(key), None)

    def avail(self, key):
        """Return items matching `key` from "AVAIL:" group.

        :param key: key to find in the group
        :type  key: str
        """
        return self._md.get("AVAIL:{}".format(key), None)

    def composite(self, key):
        """Return item matching `key` from Composite group.

        :param key: key to find in the group
        :type  key: str
        """
        return self._md.get("Composite:{}".format(key), None)

    def exif(self, key):
        """Return item matching `key` from EXIF group.

        :param key: key to find in the group
        :type  key: str
        """
        return self._md.get("EXIF:{}".format(key), None)

    def file(self, key):
        """Return item matching `key` from File group.

        :param key: key to find in the group
        :type  key: str
        """
        return self._md.get("File:{}".format(key), None)

    def icc_profile(self, key):
        """Return item matching `key` from ICC_Profile group.

        :param key: key to find in the group
        :type  key: str
        """
        return self._md.get("ICC_Profile:{}".format(key), None)

    def iptc(self, key):
        """Return item matching `key` from IPTC group.

        :param key: key to find in the group
        :type  key: str
        """
        return self._md.get("IPTC:{}".format(key), None)

    def photoshop(self, key):
        """Return item matching `key` from Photoshop group.

        :param key: key to find in the group
        :type  key: str
        """
        return self._md.get("Photoshop:{}".format(key), None)

    def xmp(self, key):
        """Return item matching `key` from XMP group.

        :param key: key to find in the group
        :type  key: str
        """
        return self._md.get("XMP:{}".format(key), None)

    # Group collections

    def _groupcollection(self, groupname):
        """Return dict of keys matching groupname prefix, with prefix removed.

        :param groupname: metadata prefix like "XMP" or "IPTC"
        :type  groupname: str
        """
        prefix = "{}:".format(groupname)
        items = {k[len(prefix):]: v for k, v in self._md.items()
                 if k.startswith(prefix)}
        return items

    def app14_items(self):
        """Return APP14 group metadata as a dict."""
        if self._app14_items is None:
            self._app14_items = self._groupcollection("APP14")
        return self._app14_items

    def avail_items(self):
        """Return avail group metadata as a dict."""
        if self._avail_items is None:
            self._avail_items = self._groupcollection("AVAIL")
        return self._avail_items

    def composite_items(self):
        """Return Composite group metadata as a dict."""
        if self._composite_items is None:
            self._composite_items = self._groupcollection("Composite")
        return self._composite_items

    def exif_items(self):
        """Return EXIF group metadata as a dict."""
        if self._exif_items is None:
            self._exif_items = self._groupcollection("EXIF")
        return self._exif_items

    def file_items(self):
        """Return File group metadata as a dict."""
        if self._file_items is None:
            self._file_items = self._groupcollection("File")
        return self._file_items

    def icc_profile_items(self):
        """Return ICC_Profile group metadata as a dict."""
        if self._icc_profile_items is None:
            self._icc_profile_items = self._groupcollection("ICC_Profile")
        return self._icc_profile_items

    def iptc_items(self):
        """Return IPTC group metadata as a dict."""
        if self._iptc_items is None:
            self._iptc_items = self._groupcollection("IPTC")
        return self._iptc_items

    def photoshop_items(self):
        """Return Photoshop group metadata as a dict."""
        if self._photoshop_items is None:
            self._photoshop_items = self._groupcollection("Photoshop")
        return self._photoshop_items

    def xmp_items(self):
        """Return XMP group metadata as a dict."""
        if self._xmp_items is None:
            self._xmp_items = self._groupcollection("XMP")
        return self._xmp_items

    def _search_md(self, search_list):
        """Given a search_list, return data the first place the key is found.

        :param search_list: ordered list spec'ing exiftool names
        :type  search_list: list of strings
        :return: None if nothing found
        """
        for s in search_list:
            if s in self._md:
                return self._md[s]
        return None

    def _set_md(self, key, val):
        """Set our private AVAIL:* attribute key with val.

        This lets us edit and save values while leaving Exiftool data alone.
        The stored name conforms to Exiftool patterns, e.g., DateCreated
        while the setter/getter uses the python spelling, e.g., date_created.
        The name of the key must be in our AVAILNAMES.

        Values are usually str, but Keywords is always list. Album was
        originally a str, but for the new multi-album feature, we'll accept the
        string or a list; we'll now always output albums as a list.

        :param str key: capitalized AVAIL attribute name (e.g., Center)
        :param val: the value, usually strings but keyword is a list of strings
        :type  val: all are strings except Keywords which must be a list
        :raises KeyError: key not in our AVAILNAMES
        :raises ValueError: value is not str or list

        """
        if key not in AVAILNAMES:
            raise KeyError("key={} not in AVAILNAMES={}".format(
                key, AVAILNAMES))
        # Keywords must be a list of strings.
        if key == "Keywords" and not isinstance(val, list):
            raise ValueError("Value for key={} must be a list of str".format(key))
        # Cast numerics to str to accommodate purely-numeric titles, album names, etc.
        if isinstance(val, int) or isinstance(val, float):
            val = str(val)
        # Albums must either be a list of strings or a single string.
        if key == "Album" and not isinstance(val, list) and not isinstance(val, str):
            raise ValueError("Value for key={} must be str or list of str".format(key))
        # Expose all Albums as a list of strings regardless of underlying JSON value.
        if key == "Album":
            # Convert a single string to a list containing one string.
            if not isinstance(val, list):
                # Map Nones, empty lists, and empty strings to an empty list.
                val = [val] if val else []
        # Do final validation.
        if key not in ('Keywords', 'Album') and not isinstance(val, str):
            raise ValueError('Value for key={} must be str, not val={}'.format(key, val))
        self._md["AVAIL:" + key] = val

    def as_dict(self):
        """Return a dict of present fields, useful for search index."""
        field_data = {}
        for field in PROPERTIES:
            if getattr(self, field):
                field_data[field] = getattr(self, field)
        return field_data

    def convert_date(self, date):
        """Convert Exiftool date to ISO-formatted string.

        Exiftool reports dates like "2014:10:23 17:55:26.70".
        CloudSearch et al expects ISO like "2014-10-23T17:55:26.70Z"
        with the trailing Z.
        We want to tolerate bare years that some clients may pass in, and
        dateutil parse converts "1984" to today's date in 1984, good enough.

        :param str date: Date from Exiftool or some other client
        :return: Date str in ISO format
        :raises ValueError: can't convert date
        """
        if date[4] == ":" and date[7] == ":":
            date = date.replace(":", "-", 2)
        try:
            # CloudSearch insists on UTC with trailing Z
            date_iso = dateutil.parser.parse(
                date,
                tzinfos=dateutil.tz.tzutc).isoformat().replace("+00:00", "Z")
            return date_iso
        except ValueError:
            msg = "Can't parse date={}".format(date)
            raise ValueError(msg)

    def validate_required_fields(self):
        """Validate the metadata has our required fields.

        We require: nasa_id, title, date_created, and media_type;
        and one of: description, keyword.

        If we are missing something, raise exception reporting field.

        :raise ValueError: missing field(s)
        :return: boolean
        """
        for f in ("nasa_id", "title", "date_created", "media_type"):
            if not getattr(self, f):
                raise ValueError("Missing field={}".format(f))
        try:
            self.convert_date(self.date_created)
        except ValueError:
            raise ValueError("Could not parse date_created date={}".format(
                self.date_created))
        if self.media_type not in ("audio", "image", "video"):
            raise ValueError(
                "media_type mediatype={} must be audio, image, or video".format(
                    self.media_type))
        if not getattr(self, "description") and not getattr(self, "keywords"):
            raise ValueError("Missing field=description|keywords")
        return True

    # Properties from Reed's list:
    # https://docs.google.com/document/d/1eEwxVmvmn6CyCVjCCJ1BV9sSvGmeXaQmwm1hTDPm4_U/
    # We're told the order should be: 1=IPTC, 2=EXIF, 3=XMP
    # This does NOT include attributes from NASA STD 2822.

    @property
    def album(self):
        """Return avail-specific album as a list."""
        alb = self._search_md([
            "AVAIL:Album",
        ])
        if isinstance(alb, str):
            alb = [alb]
        return alb

    @property
    def center(self):
        """Return avail-specific NASA center."""
        return self._search_md([
            "AVAIL:Center",
        ])

    @property
    def city(self):
        """Return city."""
        return self._search_md([
            "IPTC:City",
            "XMP:City",
        ])

    @property
    def country(self):
        """Return country."""
        return self._search_md([
            "IPTC:Country-PrimaryLocationName",
            "XMP:Country",
        ])

    @property
    def date_created(self):
        """Return date created (and time, maybe)."""
        # - Need to separate into date and time? combine?
        # - Do we want to strip any time from the date?
        # - If we do this wrong we'll stomp time on combined native fields:
        #   "EXIF:CreateDate": "2014:10:23 17:55:26",
        #   "EXIF:DateTimeOriginal": "2014:10:23 17:55:26",
        #   "EXIF:ModifyDate": "2014:10:23 20:34:01",
        #   "IPTC:DateCreated": "2014:10:23",
        #   "IPTC:DigitalCreationDate": "2014:10:23",
        #   "IPTC:DigitalCreationTime": "17:55:26",
        #   "IPTC:TimeCreated": "17:55:26",
        #   "XMP:CreateDate": "2014:10:23 17:55:26.70",
        #   "XMP:DateCreated": "2014:10:23 17:55:26.70",
        #   "XMP:HistoryWhen": "2014:10:23 20:34:01-04:00",
        #   "XMP:MetadataDate": "2014:10:23 20:34:01-04:00",
        #   "XMP:ModifyDate": "2014:10:23 20:34:01-04:00",
        return self._search_md([
            "AVAIL:DateCreated",
            "IPTC:DateCreated",
            "EXIF:DateTimeOriginal",
            "XMP:DateCreated"
        ])

    @property
    def description(self):
        """Return description."""
        return self._search_md([
            "AVAIL:Description",
            "IPTC:Description",
            "IPTC:Caption-Abstract",
            "EXIF:ImageDescription",
            "XMP:Description",
        ])

    @property
    def keywords(self):
        """Return keywords as a list."""
        # Exiftool sometimes returns flat string XMP:Keywords and
        # IPTC:Keywords.  Even with -struct, IPTC:Keywords can still be a
        # string. Ensure we always return a list.
        kw = self._search_md([
            "AVAIL:Keywords",
            "IPTC:Keywords",
            "XMP:Subject",
        ])
        if isinstance(kw, str):
            kw = [kw]
        return kw

    @property
    def location(self):
        """Return generic location."""
        location = self._search_md([
            "AVAIL:Location",
            "IPTC:Sub-location",
            "XMP:Location",
        ])
        if location:
            return location
        locs = []
        if self.city:
            locs.append(self.city)
        if self.state:
            locs.append(self.state)
        if self.country:
            locs.append(self.country)
        return ", ".join(locs)

    @property
    def media_type(self):
        """Return media type (image, video, audio), not full mime type.

        It's tempting to validate the type, but leave that to the validator.
        If we don't find a "/" return whatever we got.
        """
        mime_type = self._search_md([
            "AVAIL:MediaType",
            "XMP:Format",
            "File:MIMEType",
        ])
        if mime_type and "/" in mime_type:
            return mime_type.split("/")[0]
        return mime_type

    @property
    def owner(self):
        """Return NASA owner, the Agency UID."""
        return self._search_md([
            "AVAIL:Owner",
        ])

    @property
    def nasa_id(self):
        """
        Return NASA ID.

        Only look in one place: AVAIL:NASAID.
        """
        # We set a custom metadata key in the __init__ method; look for that.
        nasa_id = self._search_md(["AVAIL:NASAID", ])
        # If the custom key was found, return it.
        if nasa_id:
            return nasa_id
        # If the custom key wasn't found, return the empty string.
        return ''

    @property
    def photographer(self):
        """Return Photographer."""
        photog = self._search_md([
            "AVAIL:Photographer",
            "IPTC:By-line",
            "EXIF:Artist",
            "XMP:Creator",
            "XMP:Artist",
        ])
        # Some photos contain a list of names for IPTC:By-line or XMP:Creator,
        # even though EXIF:Artist is shown as a semi-colon-separated string, so
        # turn any list into a string, since our CloudSearch index expects a
        # single string. Use semi so we don't confuse names like Fred Smith, Jr.
        if type(photog) is list:
            photog = "; ".join(photog)
        return photog

    @property
    def secondary_creator(self):
        """Return avail-specific NASA center."""
        return self._search_md([
            "AVAIL:SecondaryCreator",
        ])

    @property
    def state(self):
        """Return State or province."""
        return self._search_md([
            "IPTC:Province-State",
            "XMP:State",
        ])

    @property
    def title(self):
        """
        Return Title.

        First, check the various keys we expect to find a title in. If that
        fails, fall back to NASA ID.
        """
        title = self._search_md([
            "AVAIL:Title",
            "IPTC:ObjectName",
            "IPTC:Headline",
            "XMP:Title",
            "XMP:Headline",
        ])
        if not title:
            title = self.nasa_id
        return title

    @property
    def description_508(self):
        """Return 508 Description. Needed by the UI."""
        return self._search_md([
            "AVAIL:Description508",
        ])
