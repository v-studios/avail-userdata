"""Copyright 2015 AVAIL Authors. See AUTHORS.txt in the root of the repo.

All rights reserved. Use of this source code is governed by a
proprietary license that can be found in the LICENSE file.
"""
# Use deepcopy everywhere to avoid tests cross-contaminating this module's constants.
from copy import deepcopy
from datetime import (datetime, timedelta)
import random

from unittest import TestCase
from unittest.mock import (Mock, PropertyMock,)

from pyramid import testing
from retrying import (Attempt, RetryError,)

from avail.asset import (VIDEO_PERCENTS, VIDEO_THUMB_SIZES, make_video_thumb_fname, )
from avail.exception import (AVAILDatabaseReadError, AVAILDatabaseWriteError,)

TEST_ASSET_FNAME = "assetid~orig.jpg"
TEST_AUDIO_ASSET_FNAME = "assetid~orig.mp3"
TEST_VIDEO_ASSET_FNAME = "assetid~orig.mp4"
TEST_ASSET_NASA_ID = "assetid"
TEST_ASSET_PREFIX = "image/assetid"
TEST_ASSET_AUDIO_PREFIX = "audio/assetid"
TEST_ASSET_VIDEO_PREFIX = "video/assetid"

DUMMY_NEW_ASSET_DICT = {
    'nasaId': TEST_ASSET_NASA_ID ,
    'assetPrefix': TEST_ASSET_PREFIX,
    'owner': 'ccbeebe',
}

DUMMY_NEW_AUDIO_ASSET_DICT = {
    'nasaId': TEST_ASSET_NASA_ID ,
    'assetPrefix': TEST_ASSET_AUDIO_PREFIX,
    'owner': 'ccbeebe',
}

DUMMY_NEW_VIDEO_ASSET_DICT = {
    'nasaId': TEST_ASSET_NASA_ID ,
    'assetPrefix': TEST_ASSET_VIDEO_PREFIX,
    'owner': 'ccbeebe',
}

DUMMY_NEW_JOB_DICT = {
    'fname': TEST_ASSET_FNAME,
    'userId': 'ccbeebe',
}

DUMMY_NEW_AUDIO_JOB_DICT = {
    'fname': TEST_AUDIO_ASSET_FNAME,
    'userId': 'mjkane',
}

DUMMY_NEW_VIDEO_JOB_DICT = {
    'fname': TEST_VIDEO_ASSET_FNAME,
    'userId': 'cshenton',
}

DUMMY_EXISTING_JOB_DICT = {
    'assetId': 'alex',
    'assetPath': 'image/' + TEST_ASSET_FNAME,
    'deadlettered': 0,
    'error': 0,
    'fname': TEST_ASSET_FNAME,
    'history': [],
    'incomplete': 0,
    'job': '00a177a5-3774-4dc2-9f91-34afd859dc21',
    'mediaType': 'image',
    'mtime': '2015-07-11T21:18:17.593916',
    'state': 'Uploading',
    'states': ['Uploading', 'Uploaded', 'Transcoded', 'Published', 'Indexed'],
    'userId': 'ccbeebe',
}

DUMMY_EXISTING_VIDEO_JOB_DICT = {
    'assetId': 'alex',
    'assetPath': 'video/' + TEST_VIDEO_ASSET_FNAME,
    'deadlettered': 0,
    'error': 0,
    'fname': TEST_VIDEO_ASSET_FNAME,
    'history': [],
    'incomplete': 0,
    'job': '00a177a5-3774-4dc2-9f91-34afd859dc21',
    'mediaType': 'video',
    'mtime': '2015-07-11T21:18:17.593916',
    'state': 'Uploading',
    'states': ['Uploading', 'Uploaded', 'Transcoded', 'Published', 'Indexed'],
    'userId': 'ccbeebe',
}

S3_SUCCESS_RESP = {
    'ResponseMetadata': {
        'HTTPStatusCode': 200,
    },
}
S3_ERROR_RESP = {
    'ResponseMetadata': {
        'HTTPStatusCode': 500,
    },
}

settings = {
    "authentication_policy.secret": "So seekrit!",
    "authentication_policy.audience": "https://images.nasa.gov",
    "authentication_policy.extend_session_by_units": 'minutes',
    "authentication_policy.extend_session_by_value": '15',
    "authentication_policy.jwt.duration": 4,
    "avail.aws.s3.prod.bucket.name": "test-pubbucket-name",
    "avail.aws.s3.tmp.bucket.name": "test-tmp-bucketname",
    "avail.aws.dynamodb.assetdb.table_name": "test-asset-table",
    "avail.aws.dynamodb.jobdb.table_name": "testing-testing",
    "avail.aws.dynamodb.userdb.table_name": "test-user-table",
    "avail.aws.sqs.published": "pubby-q",
    "avail.aws.sqs.transcoded": "tranny-q",
    "avail.aws.cloudsearch.doc": "cs-doc",
    "avail.aws.cloudsearch.search": "cs-search",
    "avail.aws.region": "us-east-1",
}


def make_random_date_str(start_year=1970, end_year=datetime.utcnow().year):
    """Return a random datetime string in the shape of Asset.mtime.

    Synced with string format used in avail.Asset.__init__ in avail/asset.py.
    """
    year = random.choice(range(start_year, end_year))
    month = random.choice(range(1, 13))
    day = random.choice(range(1, 29))
    hour = random.choice(range(1, 24))
    minute = random.choice(range(1, 60))
    second = random.choice(range(1, 60))
    micros = random.choice(range(1, 1000000))
    return datetime(year, month, day, hour, minute, second, micros).isoformat()


def make_dummy_existing_asset_dict(media_type='image'):
    """Return a data dict that can be used to reconstitute a dummmy Asset."""
    nasa_id = 'alex'
    asset_prefix = '{}/{}'.format(media_type, nasa_id)
    random_mtime = make_random_date_str()
    return {
        'nasaId': nasa_id,
        'assetPrefix': asset_prefix,
        'owner': 'foo',
        'popularity': random.randint(0, 100),
        'mtime': random_mtime,
    }


# Put a couple of constants down here (in the wrong place) because flake8 pretends the function
# they use has to be defined before they are created (which isn't true in Python....).
DUMMY_EXISTING_ASSET_DICT = make_dummy_existing_asset_dict()

DUMMY_EXISTING_VIDEO_DICT = make_dummy_existing_asset_dict(media_type='video')


class RestTestBase(TestCase):

    def setUp(self):
        self.config = testing.setUp(settings={"config_uri": "config:/a/path"})

    def tearDown(self):
        testing.tearDown()

    def _make_request(self, fs=None, tmpfs=None, *args, **kw):
        request = testing.DummyRequest(*args, **kw)
        if fs:
            request.fs = fs
        if tmpfs:
            request.tmpfs = fs
        return request

    def _get_class(self):
        raise NotImplementedError("To be implemented in subclasses")

    def _make_one(self, *args, **kw):
        cls = self._get_class()
        return cls(*args, **kw)


def make_dummy_job(new=True):
    from avail.job import Job
    mock_table = make_mock_table('job')
    if new is True:
        job_dict = deepcopy(DUMMY_NEW_JOB_DICT)
    elif new is False:
        job_dict = deepcopy(DUMMY_EXISTING_JOB_DICT)
    else:
        raise
    return Job(mock_table, job_dict, new=new)


def make_dummy_audio_job(new=True):
    from avail.job import Job
    mock_table = make_mock_table('job')
    job_dict = deepcopy(DUMMY_NEW_AUDIO_JOB_DICT)
    return Job(mock_table, job_dict, new=new)


def make_dummy_video_job(new=True, has_captions=False, thumbs_created=False, nasa_id=''):
    from avail.job import Job
    mock_table = make_mock_table('job')
    if new:
        job_dict = deepcopy(DUMMY_NEW_VIDEO_JOB_DICT)
    else:
        job_dict = deepcopy(DUMMY_EXISTING_VIDEO_JOB_DICT)
    if nasa_id:
        # Make sure the job.asset_id matches the requested NASA ID.
        job_dict['assetId'] = nasa_id
        # Make sure the job.fname matches the requested NASA ID.
        asset_fname = job_dict['fname']
        new_asset_fname = asset_fname.replace('assetid', nasa_id)
        job_dict['fname'] = new_asset_fname
    job = Job(mock_table, job_dict, new=new)
    if has_captions:
        from avail.aws.s3 import get_private_s3_artifact_key
        job.captions_path = get_private_s3_artifact_key(
            job.id, job._data['fname'], job.asset_id + '.vtt')
    if thumbs_created is True:
        sname = random.choice(list(VIDEO_THUMB_SIZES.keys()))
        timeids = range(1, 1+len(VIDEO_PERCENTS))
        thumb_fnames = {sname: [make_video_thumb_fname(
            job.asset_id, sname, timeid) for timeid in timeids]}
        thumb_fnames['prefix'] = 'video/%s' % job.asset_id
        job.thumb_paths = thumb_fnames
    return job


def make_mock_table(table_name, **kwargs):
    """
    Return a Mock that behaves like a boto3 dynamo Table resource.

    Use the same signature (one required arg) as the faked method.
    """
    mock_table = Mock()
    status = PropertyMock(return_value="ACTIVE")
    type(mock_table).table_status = status
    mock_table.put_item.return_value = {
        'ResponseMetadata': {
            'HTTPStatusCode': 200,
        },
    }
    mock_table.update_item.return_value = {
        'ResponseMetadata': {
            'HTTPStatusCode': 200,
        },
    }
    mock_table.delete_item.return_value = {
        'ResponseMetadata': {
            'HTTPStatusCode': 200,
        },
    }
    if 'asset' in table_name.lower():
        dummy_asset_dict = make_dummy_existing_asset_dict()
        mock_table.get_item.return_value = {
            'ResponseMetadata': {
                'HTTPStatusCode': 200,
            },
            'Item': dummy_asset_dict,
        }
        dummy_asset_dicts = [make_dummy_existing_asset_dict() for i in range(5)]
        mock_table.scan.return_value = {
            'ResponseMetadata': {
                'HTTPStatusCode': 200,
            },
            'Items': dummy_asset_dicts,
        }
        return mock_table
    elif 'job' in table_name.lower():
        mock_table.get_item.return_value = {
            'ResponseMetadata': {
                'HTTPStatusCode': 200,
            },
            'Item': deepcopy(DUMMY_EXISTING_JOB_DICT),
        }
        mock_table.scan.return_value = {
            'ResponseMetadata': {
                'HTTPStatusCode': 200,
            },
            'Items': [deepcopy(DUMMY_EXISTING_JOB_DICT), ] * 3,
        }
        mock_table.query.return_value = {
            'ResponseMetadata': {
                'HTTPStatusCode': 200,
            },
            'Items': [deepcopy(DUMMY_EXISTING_JOB_DICT), ] * 3,
        }
        return mock_table
    elif 'user' in table_name.lower():
        return mock_table
    else:
        raise ValueError('Got unacceptable table_name={}'.format(table_name))

def make_mock_jobdb(error_method=None, error_type=None, retry_error=False):
    from avail.job import JobDB
    job_table = make_mock_table('job')
    jobdb = JobDB(job_table)
    if error_method and error_type:
        side_effect = make_property_side_effect(error_type, retry_error=retry_error)
        mock_method = Mock(side_effect=side_effect)
        setattr(jobdb, error_method, mock_method)
    return jobdb

def make_dummy_asset(new=True):
    from avail.asset import Asset
    mock_table = make_mock_table('asset')
    if new is True:
        asset_dict = deepcopy(DUMMY_NEW_ASSET_DICT)
    elif new is False:
        asset_dict = deepcopy(DUMMY_EXISTING_ASSET_DICT)
    else:
        raise
    return Asset(mock_table, asset_dict, new=new)


def make_dummy_audio_asset(new=True):
    from avail.asset import Asset
    mock_table = make_mock_table('asset')
    asset_dict = deepcopy(DUMMY_NEW_AUDIO_ASSET_DICT)
    return Asset(mock_table, asset_dict, new=new)


def make_dummy_video_asset(new=True, has_captions=False, nasa_id=''):
    from avail.asset import Asset
    mock_table = make_mock_table('asset')
    if new:
        asset_dict = deepcopy(DUMMY_NEW_VIDEO_ASSET_DICT)
    else:
        asset_dict = deepcopy(DUMMY_EXISTING_VIDEO_DICT)
    if nasa_id:
        asset_dict['nasaId'] = nasa_id
        asset_prefix = asset_dict['assetPrefix']
        new_asset_prefix = asset_prefix.replace('assetid', nasa_id)
        asset_dict['prefix'] = new_asset_prefix
    asset = Asset(mock_table, asset_dict, new=new)
    if has_captions:
        from avail.aws.s3 import get_public_s3_artifact_key
        fake_asset_fname = asset.id + '.mp4'
        asset.captions_path = get_public_s3_artifact_key(fake_asset_fname, asset.id + '.vtt')
    return asset


def get_dummy_object_body():
    """Return an unread filepointer for each test, cf. `fs.get`."""
    from io import BytesIO
    return {'Body': BytesIO(b'{"foo": "bar"}')}

def make_mock_boto3_resource(service_name=None, table_name='job', mock_bucket=True, **kwargs):
    """
    Return a mock boto3.resource with passable Resource factories.

    The 'service_name' arg is necessary to absorb values like 's3', 'dynamodb', etc. by non-test
    callers which believe they're communicating with the real object.

    For test callers...

    ...if a 'table_name' string is specified, return a boto3 resource that will use make_mock_table to reply
    to requests for a Table with a mocked version, e.g., a mocked Job table. For available
    mocked table types, see make_mock_table.

    ...if a 'mock_bucket' bool is specified, return a boto3 resource that will use make_mock_bucket to reply
    to requests for a Bucket.

    ...use kwargs to pass in parameters to the mock factory functions.
    """
    mock_boto3 = Mock()
    # Though the function sets a default, check in case the caller overwrote that to a falsey
    # value because they don't want fake Tables.
    if table_name:
        mock_boto3.Table = Mock(return_value=make_mock_table(table_name, **kwargs))
    if mock_bucket:
        mock_boto3.Bucket = Mock(return_value=make_mock_bucket(**kwargs))
    return mock_boto3


def make_mock_boto3_client(list_objects_return_value=None, copy_side_effect=None, **kwargs):
    """
    Return a mock boto3.client with passable S3 client methods.

    :param dict list_objects_return_value: The dict that a call to .list_objects will return.
    :param Exception copy_side_effect: An exception (or `None`) to raise when the .copy method
    is called.
    """
    mock_client = Mock()
    if list_objects_return_value is None:
        list_objects_return_value = {
            'Contents': [
                {
                    'Key': 'foo~orig.png',
                }
            ],
        }
    mock_client.list_objects.return_value = list_objects_return_value
    mock_client.copy.side_effect = copy_side_effect
    return mock_client


# TODO (as needed): If callers want to turn off some of these mocked returns, implement
# opt-out kwargs like:
#
#   if kwargs.get('mock_generate_presigned_url', True):
#       mock_bucket.meta.client.generate_presigned_url.return_value = ...
#
def make_mock_bucket(**kwargs):
    """
    Return a mock which is a passable factory for a boto3.Bucket resource.

    :param bucket_name (optional): A value to set on bucket.name.
    :param create_multipart_upload_return_value (optional): A value to return when
        create_multipart_upload is called.
    :param get_presigned_url_return_value (optional): A value to return when get_presigned_url
        is called.
    :param head_object_side_effect (optional): A side effect for calls to head_object.
    :param list_objects_return_value (optional): A value to return when list_objects is called.
    :param object_get_return_value (optional): A value to return when Object.get is called.
    :param object_get_side_effect (optional): A side effect for calls to Object.get.
    :param object_put_return_value (optional): A value to return when Object.put is called.
    """
    mock_bucket = Mock()
    # Set a bucket name.
    mock_bucket.name = kwargs.get('bucket_name', 'bucketname')
    # Default to successfully creating a multipart upload.
    mock_bucket.meta.client.create_multipart_upload.return_value = kwargs.get(
        'create_multipart_upload_return_value', {'UploadId': 'UPLOADID'})
    # Default to successfully generating a pre-signed URL.
    mock_bucket.meta.client.generate_presigned_url.return_value = kwargs.get(
        'get_presigned_url_return_value', 'foo')
    # Default to not finding keys, e.g., metadata files.
    mock_bucket.meta.client.head_object.side_effect = kwargs.get('head_object_side_effect',
                                                                 KeyError)
    # Default to finding objects, e.g., resized images.
    mock_bucket.meta.client.list_objects.return_value = kwargs.get('list_objects_return_value',
        {
            'Contents': [
                {
                    'Key': 'foo',
                },
                {
                    'Key': 'bar',
                },
            ],
        }
    )
    # Mock Bucket.Object by default.
    mock_s3_object = Mock()
    # Set a side_effect or a return_value on the Object.get mock, but not both.
    object_get_return_value = kwargs.get('object_get_return_value')
    object_get_side_effect = kwargs.get('object_get_side_effect')
    if object_get_return_value and object_get_side_effect :
        raise ValueError('Cannot have both a return_value and a side_effect for Object.get')
    # Default to finding an object via Object.get, e.g., calls to (tmp)fs.get.
    if not object_get_return_value and not object_get_side_effect:
        mock_s3_object.get.return_value = deepcopy(get_dummy_object_body())
    # If an Object.get return value is given, use it.
    elif object_get_return_value:
        mock_s3_object.get.return_value = object_get_return_value
    # If an Object.get side effect is given, use it.
    elif object_get_side_effect:
        mock_s3_object.get.side_effect = object_get_side_effect
    # Default to succeeding on Object.Put calls, e.g., via (tmp)fs.put.
    mock_s3_object.put.return_value = kwargs.get('object_put_return_value',
        {
            'ResponseMetadata': {
                'HTTPStatusCode': 200
            },
        }
    )
    mock_bucket.Object.return_value = mock_s3_object
    return mock_bucket

def make_dummy_client_error(retryable=True, *args, **kwargs):
    from botocore.exceptions import ClientError
    code = 'ProvisionedThroughputExceededException'
    if not retryable:
        code = 'NotRetryable'
    return ClientError({
        'Error': {
            'Code': code,
            'Message': 'Test message.'
        }
    }, operation_name='UnitTest')

def raise_dummy_client_error(*args, **kwargs):
    raise make_dummy_client_error(*args, **kwargs)

def make_property_side_effect(error_type, retry_error=False, default_rv=True):
    if error_type == 'assertion':
        error = AssertionError('foo')
    if error_type == 'client':
        error = make_dummy_client_error()
    if error_type == 'read':
        error = AVAILDatabaseReadError('foo')
    if error_type == 'value':
        error = ValueError('foo')
    if error_type == 'write':
        error = AVAILDatabaseWriteError('foo')
    if retry_error is True:
        attempts = 42
        attempt = Attempt([error.__class__, error, None], attempts, True)
        error = RetryError(attempt)
    def side_effect(*args, **kwargs):
        if args or kwargs:
            raise error
        return default_rv
    return side_effect
