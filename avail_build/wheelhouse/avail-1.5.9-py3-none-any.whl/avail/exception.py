"""Copyright (c) 2015 AVAIL Authors. See AUTHORS.txt in the root of the repo.

All rights reserved. Use of this source code is governed by a
proprietary license that can be found in the LICENSE file.
"""


class AVAILException(Exception):

    """AVAILException is the base exception for avail* packages."""

    pass


class AVAILMetadataException(AVAILException):
    """Something bad with the metadata."""


class AVAILMetadataJsonException(AVAILMetadataException):
    """Could not parse the JSON metadata representation."""


class AVAILDatabaseWriteError(AVAILException):
    """Could not write to database."""


class AVAILDatabaseConflictError(AVAILException):
    """Could not insert new record into database."""


class AVAILDatabaseReadError(AVAILException):
    """Could not read from database."""
