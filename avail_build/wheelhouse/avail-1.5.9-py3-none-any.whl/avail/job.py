# Copyright (c) 2015 AVAIL Authors. See AUTHORS.txt in the root of the repo.
"""AVAIL job class and helpers."""
import logging

import os
from collections import Sequence
from datetime import datetime
from uuid import uuid4

from boto3.dynamodb.conditions import (And, Attr, Key, )

from botocore.exceptions import ClientError

from retrying import (RetryError, retry,)

from zope.interface import implementer

from avail.asset import (RETRYABLE_EXCEPTIONS, VIDEO_THUMB_SIZES, check_video_thumb_fname, )
from avail.aws.s3 import get_file_type_assetid_ext
from avail.exception import (AVAILDatabaseReadError, AVAILDatabaseWriteError,)
from avail.interfaces import (IJob, IJobDB)
from avail.metadata import METADATA_FILENAME

log = logging.getLogger(__name__)

DEFAULT_STATES = ["Uploading", "Uploaded", "Transcoded", "Published", "Indexed"]
"""States essentially represent where in the pipeline a job is."""

ERROR = "Error"
INCOMPLETE = "Incomplete"


# TODO: should this go in a config file?
ERROR_MTIME_INDEX = "error-mtime-index"
INCOMPLETE_MTIME_INDEX = "incomplete-mtime-index"

CAPTIONS_EXTS = {".srt": "application/x-subrip",
                 ".vtt": "text/vtt"}

# TODO: Figure out how to move these parameters (which are used by the retry decorator) to an
# ini file.
WAIT_BASE_MS = 1000  # ms
WAIT_MAX_MS = 64000  # ms
MAX_RETRIES = 100


def retry_on_retryable(err):
    """Return True if boto3 Error is retryable."""
    # Handle non-boto3 errors.
    if not hasattr(err, 'response'):
        return False
    # Dig out the 'Code' from a boto3 error.
    code = err.response.get('Error', {}).get('Code')
    return code in RETRYABLE_EXCEPTIONS


@implementer(IJob)
class Job:
    """Job implements the `IJob` interface.

    :type table: A ``boto3.dynamodb.Table``
    :param table: The dynamo JobDB table.
    :type job_data: dict
    :param job_data: A dict with the job data from Dynamo if existing or with
                     user_id asset_path if new.
    :type new: bool
    :param new: A boolean indicating if this is a new Job.
    :type states: list
    :param states: A list of strings containing the states this Job can occupy.

    We expect a Job to only be created by JobDB, so we aren't defensive in the
    ctor.
    """

    def __init__(self, table, job_data=None, new=False, states=DEFAULT_STATES):
        """Class constructor."""
        self._data = job_data
        self._table = table
        self.log = log

        if new:
            # A new job must have these.
            for attr in ("fname", "userId"):
                assert attr in self._data
                assert isinstance(attr, str)
            # But a new job shouldn't have this stuff yet.
            for attr in ("job", "mtime", "state", "states"):
                assert attr not in self._data
            # States should be 'indexable'
            assert isinstance(states, Sequence)

            self._data["job"] = str(uuid4())
            self._set_path_parts()
            self._data["states"] = states
            self._data["state"] = self._data["states"][0]
            self._data["error"] = 0
            self._data["incomplete"] = 0
            self._data["deadlettered"] = 0
            self._touch()
            self._data["history"] = []
            try:
                self.save()
            except RetryError as e:  # pragma: no cover
                # Look up how many attempts were made.
                attempts = e.last_attempt.attempt_number
                # Unpack the class of the Exception associated with the final attempt.
                orig_err = e.last_attempt.value[1]
                # If the final error was a ClientError, then the write failed despite the
                # backoff attempt.
                if isinstance(orig_err, ClientError):
                    error_msg = 'Job.__init__: save failed after {} backoff' \
                        'attempts'.format(attempts)
                    self.log.error(error_msg)
                # If the final error was an AVAILDatabaseWriteError, then the write got through
                # but failed.
                if isinstance(orig_err, AVAILDatabaseWriteError):
                    error_msg = 'Job.__init__: save received error from Dynamo.'
                    self.log.error(error_msg)
                # Re-raise the fatal error.
                self.log.error('Final error={}'.format(orig_err))
                raise orig_err

        else:  # Existing jobs should have this info at a minimum
            # TODO: Make more robust tests, this should have assetId and
            # mediaType, too. Maybe even fname.
            for attr in ("assetPath", "history", "job", "mtime", "state",
                         "states", "userId"):
                assert attr in self._data

    def __eq__(self, job):
        """
        Return True if `job` is a Job and its underlying data is equal to self._data.

        Otherwise, return False.
        """
        # Use 'getattr' instead of trying to check _data directly because it's safe and won't
        # raise an AttributeError if the target object doesn't have a _data attribute.
        return self._data == getattr(job, '_data', None) and isinstance(job, self.__class__)

    def __str__(self):  # pragma: no cover
        """Return a representation of a job."""
        return "{}(job_id={},asset_path={})".format(self.__class__, self.id,
                                                    self.asset_path)

    def _touch(self):
        self._data["mtime"] = datetime.utcnow().isoformat()

    def _set_path_parts(self):
        """Set path parts for assets; empty for metadata updates."""
        fname = self._data["fname"]
        if fname.endswith(".json"):
            # For metadata updates, we can't use the asset name helpers because
            # metadata is JSON, not a media type; we have to set values to
            # satisfy the constructor and it can't be empty string or DynamoDB
            # will reject.
            media_type, asset_id, metadata_json = fname.split("/")
            self._data["mediaType"] = media_type
            self._data["assetId"] = asset_id
            self._data["assetPath"] = fname  # media_type/asset_id/metadata.json
        else:
            # Presume we're making an asset upload job
            try:
                (ftype, asset_id, ext) = get_file_type_assetid_ext(fname)
            except ValueError as e:
                log.error('Could not create job for filename={}'.format(fname))
                raise e
            if asset_id.endswith("~orig"):
                asset_id = asset_id[:-len("~orig")]
            pubpath = os.path.join(ftype, asset_id, asset_id + "~orig." + ext)
            self._data["assetPath"] = os.path.join(self.id, pubpath)
            self._data["mediaType"] = ftype
            self._data["assetId"] = asset_id

    ###########################################################################
    # Public methods and their private implementions: alphabetical

    # Make the JobDB retry using exponential backoff w/ decorrelated jitter. See the wrapper
    # around Job.save for more explanation of parameters.
    @retry(wait_exp_decorr_jitter_base=WAIT_BASE_MS,
           wait_exp_decorr_jitter_max=WAIT_MAX_MS,
           retry_on_exception=retry_on_retryable,
           stop_max_attempt_number=MAX_RETRIES,
           wrap_exception=True,)
    def delete(self):  # pragma: no cover
        """Expose a decorated version of self._delete with retries configured."""
        return self._delete()

    def _delete(self):
        """
        Delete self.id from Dynamo.

        Raise `ClientError` if write fails temporarily. Raise `AVAILDatabaseWriteError` if write
        fails permanently.

        Return True if delete succeeded.
        """
        # Make a call to delete_item using a dict containing the job's pkey.
        try:
            resp = self._table.delete_item(Key={'job': self.id})
        except ClientError as e:
            # Log the error, then re-raise it so it'll be retried.
            log.error('Job._delete for jobid={} got error={}'.format(self.id, e))
            raise
        # Check the response code from the AWS API.
        resp_code = resp.get("ResponseMetadata", {}).get("HTTPStatusCode")
        # If the AWS API doesn't return a 200, then the delete request wasn't
        # accepted.
        if resp_code != 200:
            error_msg = "Job._delete received errorcode={} response deleting {}.".format(
                resp_code, self._data)
            log.error(error_msg)
            raise AVAILDatabaseWriteError(error_msg)
        # If the response code was 200, then the delete will succeed.
        return True

    # Make the JobDB retry using exponential backoff w/ decorrelated jitter. Set a base of
    # 1000ms, max of 64000ms, and limit to 100 attempts (according to the AWS blog post should
    # resolve connections for at least 10 competing clients). Also, default to retrying on
    # retryable exceptions as defined by AWS. Enable exception wrapping by retrying so we'll
    # know when we've failed due to maxing out retries vs. when we've failed for other reasons.
    @retry(wait_exp_decorr_jitter_base=WAIT_BASE_MS,
           wait_exp_decorr_jitter_max=WAIT_MAX_MS,
           retry_on_exception=retry_on_retryable,
           stop_max_attempt_number=MAX_RETRIES,
           wrap_exception=True,)
    def save(self):  # pragma: no cover
        """Expose a decorated version of self._save with retries configured."""
        self._save()

    def _save(self):
        """
        Write self._data to Dynamo.

        Raise `ClientError` if write fails temporarily. Raise `AVAILDatabaseWriteError` if write
        fails permanently.
        """
        try:
            resp = self._table.put_item(Item=self._data)
        except ClientError as err:
            # Log the error, then re-raise it so it'll be retried.
            log.error('Job._save for jobid={} got error={}'.format(self.id, err))
            raise
        resp_code = resp.get("ResponseMetadata", {}).get("HTTPStatusCode")
        # If the write was unsuccessful, raise.
        if resp_code != 200:
            error_msg = 'Job._save received errorcode={} response saving {}'.format(resp_code,
                                                                                    self._data)
            log.error(error_msg)
            raise AVAILDatabaseWriteError(error_msg)

    @retry(wait_exp_decorr_jitter_base=WAIT_BASE_MS,
           wait_exp_decorr_jitter_max=WAIT_MAX_MS,
           retry_on_exception=retry_on_retryable,
           stop_max_attempt_number=MAX_RETRIES,
           wrap_exception=True,)
    def update(self, attr_vals):  # pragma: no cover
        """Expose a decorated version of self._update with retries configured."""
        self._update(attr_vals)

    def _update(self, attr_vals):
        """Update Dynamo with only the attrs specified, not entire item as in _save().

        We do not change _data here, so we expect the attr_vals to be a dict of
        just the parts of _data we want updated.  We expect that _data will
        have 'mtime' changed outside this and passed to us if we want the
        _touch() to be effective: while we could do this here with a named
        parameter, our tests don't know that we get back the data from the DDB
        and update _data with it, so they'll fail. So we do things the more
        cumbersome, verbose way.

        TODO: use update_item(ReturnValues='ALL_NEW') to update _data cache.
        We'll have to rework a lot of mocks to support this behavior.

        :param dict attr_vals: attribute names and values to set
        :param bool update_mtime: if True, update the 'mtime' to now.
        """
        kv = attr_vals.copy()
        ue = 'SET ' + ', '.join('#{} = :{}'.format(k, k) for k in kv.keys())
        ean = {'#' + k: k for k in kv}
        eav = {':' + k: v for k, v in kv.items()}
        try:
            resp = self._table.update_item(Key={"job": self.id},
                                           UpdateExpression=ue,
                                           ExpressionAttributeNames=ean,
                                           ExpressionAttributeValues=eav)
        except ClientError as err:
            log.error('Job._update for jobid={} got error={}'.format(self.id, err))
            raise  # retry the operation
        resp_code = resp.get("ResponseMetadata", {}).get("HTTPStatusCode")
        if resp_code != 200:
            error_msg = 'Job._update received errorcode={} response saving {}'.format(
                resp_code, self._data)
            log.error(error_msg)
            raise AVAILDatabaseWriteError(error_msg)

    def transition(self):
        """Move the Job to the next state.

        Move the Job to the next state.
        TODO: How do we transition across state boundaries such as Error and
        TODO: Incomplete.
        """
        # append most recent state onto history
        self._data["history"].append([self.state, self.last_modified])
        # advance state if there is one after the current one
        if self.next_state:
            self._data['state'] = self.next_state
        else:  # TODO shouldn't this nuke the job? else it'll be stuck in current state forever
            log.warn("transition: no next_state for jobid={} assetpath={}".format(
                self.id, self.asset_path))
        self._touch()
        try:
            self.update({'history': self._data['history'],
                         'state': self._data['state'],
                         'mtime': self._data['mtime']})
        except RetryError as e:
            # Look up how many attempts were made.
            attempts = e.last_attempt.attempt_number
            # Unpack the class of the Exception associated with the final attempt.
            orig_err = e.last_attempt.value[1]
            # If the final error was a ClientError, then the write failed despite the backoff
            # attempt.
            if isinstance(orig_err, ClientError):
                error_msg = 'Job.transition: save failed after {} backoff ' \
                    'attempts'.format(attempts)
                self.log.error(error_msg)
            # If the final error was an AVAILDatabaseWriteError, then the write got through but
            # failed.
            if isinstance(orig_err, AVAILDatabaseWriteError):
                error_msg = 'Job.transition: save received error from Dynamo.'
                self.log.error(error_msg)
            # Re-raise the fatal error.
            self.log.error('Final error={}'.format(orig_err))
            raise orig_err

    ###########################################################################
    # Properties: alphabetical

    @property
    def asset_id(self):
        """Return the asset id, AKA nasa id."""
        return self._data["assetId"]

    @property
    def asset_path(self):
        """Return the path of this job's associated asset."""
        return self._data["assetPath"]

    @property
    def captions_path(self):
        """S3 key where the captions file lives, or None.

        Could be in incoming or public bucket, depending on state.
        """
        # Who handles it on the upload side to incoming s3?
        # and how do they know it's name, *.srt vs *.vtt?
        return self._data.get("captionsPath")

    @captions_path.setter
    def captions_path(self, val):
        """Set it to the S3 key where the caption lives.

        It's basename must be lowercase assetid.srt or assetid.vtt.

        :param str val: S3 key where the captions file lives
        """
        if not isinstance(val, str):
            raise TypeError("job.captions_path must be str, got val={}".format(val))
        base = os.path.basename(val)
        cid, ext = os.path.splitext(base)
        if cid != self.asset_id:
            raise ValueError("job.captions_path={} must match NASA ID={}".format(
                val, self.asset_id))
        if ext not in CAPTIONS_EXTS:
            raise ValueError("job.captions_path={} must end in: {}".format(
                val, ", ".join(CAPTIONS_EXTS.keys())))
        self._data['captionsPath'] = val
        self._touch()
        try:
            self.update({'captionsPath': self._data['captionsPath'],
                         'mtime': self._data['mtime']})
        except RetryError as e:
            # Look up how many attempts were made.
            attempts = e.last_attempt.attempt_number
            # Unpack the class of the Exception associated with the final attempt.
            orig_err = e.last_attempt.value[1]
            # If the final error was a ClientError, then the write failed despite the backoff
            # attempt.
            if isinstance(orig_err, ClientError):
                error_msg = 'Job.captions_path: save failed after {} backoff ' \
                    'attempts'.format(attempts)
                self.log.error(error_msg)
            # If the final error was an AVAILDatabaseWriteError, then the write got through but
            # failed.
            if isinstance(orig_err, AVAILDatabaseWriteError):
                error_msg = 'Job.captions_path: save received error from Dynamo.'
                self.log.error(error_msg)
            # Re-raise the fatal error.
            self.log.error('Final error={}'.format(orig_err))
            raise orig_err

    @property
    def deadlettered(self):
        """
        Return True if the Job's SQS message reached the DeadLetterQueue.

        Otherwise, return False.
        """
        return self._data["deadlettered"] == 1

    @deadlettered.setter
    def deadlettered(self, val):
        """
        Set `deadlettered`, which cannot be stored as a `bool`.

        DynamoDB refuses to index a boolean field, so use [0,1] instead.

        :param bool val: If True, then deadlettered will be set to 1. If False,
        then it will be set to 0.
        """
        if not isinstance(val, bool):
            raise TypeError(
                "Must use a `bool` to set `deadlettered`; got val={}.".format(
                    val))
        self._data['deadlettered'] = 1 if val else 0  # 1 if Truthy, else 0 (Falsey)
        self._touch()
        try:
            self.update({'deadlettered': self._data['deadlettered'],
                         'mtime': self._data['mtime']})
        except RetryError as e:
            # Look up how many attempts were made.
            attempts = e.last_attempt.attempt_number
            # Unpack the class of the Exception associated with the final attempt.
            orig_err = e.last_attempt.value[1]
            # If the final error was a ClientError, then the write failed despite the backoff
            # attempt.
            if isinstance(orig_err, ClientError):
                error_msg = 'Job.deadlettered: save failed after {} backoff ' \
                    'attempts'.format(attempts)
                self.log.error(error_msg)
            # If the final error was an AVAILDatabaseWriteError, then the write got through but
            # failed.
            if isinstance(orig_err, AVAILDatabaseWriteError):
                error_msg = 'Job.deadlettered: save received error from Dynamo.'
                self.log.error(error_msg)
            # Re-raise the fatal error.
            self.log.error('Final error={}'.format(orig_err))
            raise orig_err

    @property
    def error(self):
        """Return True if the Job is in an error state, else False."""
        return self._data["error"] == 1

    @error.setter
    def error(self, val):
        """Set the error attribute.

        :type val: int (0 or 1)
        :param val: This should always be true (1), but could be anything, or nothing.
        """
        self._data["history"].append([self.state, self.last_modified])
        self._data['error'] = 1 if val else 0
        self._touch()
        try:
            self.update({'history': self._data['history'],
                         'error': self._data['error'],
                         'mtime': self._data['mtime']})
        except RetryError as e:
            # Look up how many attempts were made.
            attempts = e.last_attempt.attempt_number
            # Unpack the class of the Exception associated with the final attempt.
            orig_err = e.last_attempt.value[1]
            # If the final error was a ClientError, then the write failed despite the backoff
            # attempt.
            if isinstance(orig_err, ClientError):
                error_msg = 'Job.error: save failed after {} backoff ' \
                    'attempts'.format(attempts)
                self.log.error(error_msg)
            # If the final error was an AVAILDatabaseWriteError, then the write got through but
            # failed.
            if isinstance(orig_err, AVAILDatabaseWriteError):
                error_msg = 'Job.error: save received error from Dynamo.'
                self.log.error(error_msg)
            # Re-raise the fatal error.
            self.log.error('Final error={}'.format(orig_err))
            raise orig_err

    @property
    def history(self):
        """Return the Job history."""
        return self._data["history"]

    @property
    def id(self):
        """Return the Job path."""
        return self._data["job"]

    @property
    def incomplete(self):
        """Return True if the Job is in an incomplete state, else False."""
        return self._data["incomplete"] == 1

    @incomplete.setter
    def incomplete(self, val):
        """Set the incomplete attribute.

        :param bool val: Whether the job is incomplete or not.
        """
        self._data["history"].append([self.state, self.last_modified])
        self._data['incomplete'] = 1 if val else 0
        self._touch()
        try:
            self.update({'history': self._data['history'],
                         'incomplete': self._data['incomplete'],
                         'mtime': self._data['mtime']})
        except RetryError as e:
            # Look up how many attempts were made.
            attempts = e.last_attempt.attempt_number
            # Unpack the class of the Exception associated with the final attempt.
            orig_err = e.last_attempt.value[1]
            # If the final error was a ClientError, then the write failed despite the backoff
            # attempt.
            if isinstance(orig_err, ClientError):
                error_msg = 'Job.incomplete: save failed after {} backoff ' \
                    'attempts'.format(attempts)
                self.log.error(error_msg)
            # If the final error was an AVAILDatabaseWriteError, then the write got through but
            # failed.
            if isinstance(orig_err, AVAILDatabaseWriteError):
                error_msg = 'Job.incomplete: save received error from Dynamo.'
                self.log.error(error_msg)
            # Re-raise the fatal error.
            self.log.error('Final error={}'.format(orig_err))
            raise orig_err

    @property
    def last_modified(self):
        """Return the last time this Job was modified."""
        return self._data["mtime"]

    @property
    def metadata_path(self):
        """Return `str` which is the key to this job's asset's metadata, in S3.

        TODO: Move this somewhere more appropriate. By its description it
        TODO: seems to belong on an asset object or its metadata object.

        This value is where the metadata JSON file should live - if there
        hasn't been any metadata uploaded yet, then a GetObject call to S3
        using this method's return value will return nothing (or raise an
        error, whatever boto feels like doing these days). Use with caution.

        We used to start the MD file in the private bucket but realized the
        client couldn't edit it there, so now it goes straight to public s3, so
        we only need to look there.
        """
        rv = os.path.join(self.media_type, self.asset_id, METADATA_FILENAME)
        return rv

    @property
    def media_type(self):
        """Return the media type."""
        return self._data["mediaType"]

    @property
    def next_state(self):
        """Return the next state for the Job."""
        next_index = self._data["states"].index(self._data["state"]) + 1
        return self._data["states"][next_index] if next_index < len(
            self._data["states"]) else None

    @property
    def owner(self):
        """Return the User ID of whoever initiated this job."""
        return self._data["userId"]

    @property
    def prefix(self):
        """Return the prefix for this jobs files."""
        return os.path.join(self.id, self.media_type, self.asset_id, "OUT")

    @property
    def previous_state(self):
        """Return the previous_state for the Job."""
        prev_index = self._data["states"].index(self._data["state"]) - 1
        return self._data["states"][prev_index] if prev_index >= 0 else None

    @property
    def previous_states(self):
        """Return the names of the states this job has been in."""
        return [i[0] for i in self.history]

    @property
    def state(self):
        """Return the current state."""
        return self._data["state"]

    @property
    def thumb_paths(self):
        """Get public S3 keys where the thumbnail files reside, or None.

        This is a dict, grouping same-size files and includes URL prefix.
        """
        return self._data.get("thumbPaths")

    @thumb_paths.setter
    def thumb_paths(self, val):
        """Set it to the public S3 keys where the thumbnails live.

        This is a dict so the consumer (e.g., front-end) can easly get just the
        sizes the current UI element needs; it also includes a URL prefix so
        they don't have to look for it and so our keys don't have to be full
        URLs. Sizes are from avail.VIDEO_THUMB_SIZES. For example:

        {"small":  [aid~small.jpg,  aid~small_1.jpg,  ... aid~small_5.jpg],
         "thumb":  [aid~thumb.jpg,  aid~thumb_1.jpg,  ... aid~thumb_5.jpg],
         "medium": [aid~medium.jpg, aid~medium_1.jpg, ... aid~medium_5.jpg],
         "large":  [aid~large.jpg,  aid~large_1.jpg,  ... aid~large_5.jpg],
         "prefix": "video/aid/"}

        We may not have all sizes: if the video's small, large thumbs may not be created.

        :param dict val: size and list of keys, plus URL prefix.
        """
        ok_keys = list(VIDEO_THUMB_SIZES.keys()) + ['prefix']
        if not isinstance(val, dict):
            raise TypeError('job.thumb_paths must be dict, got val={}'.format(val))
        if 'prefix' not in val.keys():
            raise ValueError('job.thumb_paths must include "prefix" key, got val={}'.format(
                val))
        for key in val.keys():
            if key not in ok_keys:
                raise ValueError('job.thumb_paths must have keys={}, got val={}'.format(
                    ok_keys, val))
            # Check each size key's thumb fnames.
            if key in VIDEO_THUMB_SIZES.keys():
                for fname in val[key]:
                    check_video_thumb_fname(fname)
        self._data['thumbPaths'] = val
        self._touch()
        try:
            self.update({'thumbPaths': self._data['thumbPaths'],
                         'mtime': self._data['mtime']})
        except RetryError as e:
            attempts = e.last_attempt.attempt_number
            orig_err = e.last_attempt.value[1]
            if isinstance(orig_err, ClientError):
                msg = 'Job.thumb_paths: save failed after {} backoff attempts'.format(attempts)
                self.log.error(msg)
            if isinstance(orig_err, AVAILDatabaseWriteError):
                msg = 'Job.thumb_paths: save received error from Dynamo.'
                self.log.error(msg)
            self.log.error('Final error={}'.format(orig_err))
            raise orig_err


@implementer(IJobDB)
class JobDB:
    """``JobDB`` wraps the dynamo job table."""

    def __init__(self, table):
        """Class constructor."""
        self._table = table
        self.log = log

    # Make the JobDB retry using exponential backoff w/ decorrelated jitter. See the wrapper
    # around Job.save for more explanation of parameters.
    @retry(wait_exp_decorr_jitter_base=WAIT_BASE_MS,
           wait_exp_decorr_jitter_max=WAIT_MAX_MS,
           retry_on_exception=retry_on_retryable,
           stop_max_attempt_number=MAX_RETRIES,
           wrap_exception=True,)
    def query(self, **kwargs):  # pragma: no cover
        """
        Return Jobs from a DynamoDB query to this environment's Job table.

        Do so by safely calling self._query with exponential backoff.

        When calling this method in a try/except block, anticipate catching RetryErrors. See
        JobDB.unfinished and .incomplete for examples of how to introspect into those wrapper
        errors to uncover the original fatal error.
        """
        return self._query(**kwargs)

    def _query(self, **kwargs):
        """
        Return a list of Jobs from a response to self._table.query.

        Automatically page through entire query cursor; accordingly, overwrite any
        {'ExclusiveStartKey': '...'} pair passed in explicitly by a caller via **kwargs.
        """
        # Check for required args.
        if kwargs.get('KeyConditionExpression') is None and kwargs.get('KeyConditions') is None:
            error_msg = 'JobDB._query requires either a KeyConditionExpression or KeyConditions'
            self.log.error(error_msg)
            raise ValueError(error_msg)
        # Recursively page through query results in a single try/except.
        try:
            res = self._table.query(**kwargs)
            items = res.get('Items', [])
            # If (while) there's an LEK, ask for another page of results.
            while res.get('LastEvaluatedKey'):
                res = self._table.query(ExclusiveStartKey=res['LastEvaluatedKey'], **kwargs)
                # Avoid creating a nested list by using list.extend instead of list.append.
                items.extend(res.get('Items', []))
        except ClientError as e:
            # Log the error, then re-raise it so it'll be retried.
            self.log.error('JobDB._query for kwargs={} got error={}'.format(kwargs, e))
            raise
        # If Dynamo gave a non-"OK" response, raise.
        resp_code = res.get('ResponseMetadata', {}).get('HTTPStatusCode')
        if resp_code != 200:
            error_msg = 'JobDB._query received errorcode={} querying dynamodb '
            'with kwargs={}.'.format(resp_code, kwargs)
            self.log.error(error_msg)
            raise AVAILDatabaseReadError(error_msg)
        return [Job(self._table, job_data=item) for item in items]

    # Make the JobDB retry using exponential backoff w/ decorrelated jitter. See the wrapper
    # around Job.save for more explanation of parameters.
    @retry(wait_exp_decorr_jitter_base=WAIT_BASE_MS,
           wait_exp_decorr_jitter_max=WAIT_MAX_MS,
           retry_on_exception=retry_on_retryable,
           stop_max_attempt_number=MAX_RETRIES,
           wrap_exception=True,)
    def scan(self, **kwargs):  # pragma: no cover
        """
        Return Jobs from a DynamoDB scan to this environment's Job table.

        Do so by safely calling self._scan with exponential backoff.

        When calling this method in a try/except block, anticipate catching RetryErrors. See
        JobDB.unfinished and .incomplete for examples of how to introspect into those wrapper
        errors to uncover the original fatal error.
        """
        return self._scan(**kwargs)

    def _scan(self, **kwargs):
        """
        Return a list of Jobs from a response to self._table.scan.

        Automatically page through entire scan cursor; accordingly, overwrite any
        {'ExclusiveStartKey': '...'} pair passed in explicitly by a caller via **kwargs.
        """
        # Recursively page through scan results in a single try/except.
        try:
            res = self._table.scan(**kwargs)
            items = res.get('Items', [])
            # If (while) there's an LEK, ask for another page of results.
            while res.get('LastEvaluatedKey'):
                res = self._table.scan(ExclusiveStartKey=res['LastEvaluatedKey'], **kwargs)
                # Avoid creating a nested list by using list.extend instead of list.append.
                items.extend(res.get('Items', []))
        except ClientError as e:
            # Log the error, then re-raise it so it'll be retried.
            self.log.error('JobDB._scan for kwargs={} got error={}'.format(kwargs, e))
            raise
        # If Dynamo gave a non-"OK" response, raise.
        resp_code = res.get('ResponseMetadata', {}).get('HTTPStatusCode')
        if resp_code != 200:
            error_msg = 'JobDB._scan received errorcode={} scanning dynamodb ' \
                'with kwargs={}.'.format(resp_code, kwargs)
            self.log.error(error_msg)
            raise AVAILDatabaseReadError(error_msg)
        return [Job(self._table, job_data=item) for item in items]

    def by_id(self, job_id):
        """
        Return a Job with the given ID.

        If there is no such ID, return None.
        """
        # Use `query` instead of `get_item` beacuse we're using a complex
        # primary key. (To use `get_item` with a complex pkey, you must know
        # both the partition key value _and_ the sort key value.)
        try:
            items = self.query(KeyConditionExpression=Key('job').eq(job_id))
        except RetryError as e:
            # Look up how many attempts were made.
            attempts = e.last_attempt.attempt_number
            # Unpack the class of the Exception associated with the final attempt.
            orig_err = e.last_attempt.value[1]
            # If the final error was a ClientError, then the read failed despite the backoff
            # attempt.
            if isinstance(orig_err, ClientError):
                error_msg = 'JobDB.by_id failed after {} backoff attempts'.format(attempts)
                self.log.error(error_msg)
            # If the final error was an AVAILDatabaseReadError, then the read got through but
            # failed.
            if isinstance(orig_err, AVAILDatabaseReadError):
                error_msg = 'JobDB.by_id received error from Dynamo.'
                self.log.error(error_msg)
            # Re-raise the fatal error.
            self.log.error('Final error={}'.format(orig_err))
            raise orig_err
        return items[0] if items else None

    def unfinished(self, auid=''):
        """
        Return a list of Jobs that are not in a finished state.

        :param str auid: (optional) An AUID to use to further filter the
        returns of this query. Default: `''`.
        """
        # The default filter should be to exclude jobs whose state is the first
        # possible state.
        filter_expression = Attr("state").ne(DEFAULT_STATES[-1])
        # If there was an auid included, AND it with the default filter
        # expression.
        if auid:
            filter_expression = And(filter_expression,
                                    Attr('userId').eq(auid),
                                    )
        try:
            return self.query(
                IndexName=ERROR_MTIME_INDEX,
                KeyConditionExpression=Key("error").eq(0),
                ScanIndexForward=False,
                FilterExpression=filter_expression,
            )
        except RetryError as e:
            # Look up how many attempts were made.
            attempts = e.last_attempt.attempt_number
            # Unpack the class of the Exception associated with the final attempt.
            orig_err = e.last_attempt.value[1]
            # If the final error was a ClientError, then the read failed despite the backoff
            # attempt.
            if isinstance(orig_err, ClientError):
                error_msg = 'JobDB.unfinished failed after {} backoff attempts'.format(attempts)
                self.log.error(error_msg)
            # If the final error was an AVAILDatabaseReadError, then the read got through but
            # failed.
            if isinstance(orig_err, AVAILDatabaseReadError):
                error_msg = 'JobDB.unfinished received error from Dynamo.'
                self.log.error(error_msg)
            # Re-raise the fatal error.
            self.log.error('Final error={}'.format(orig_err))
            raise orig_err

    def incomplete(self):
        """Return a list of Jobs that are incomplete."""
        try:
            return self.query(
                IndexName=INCOMPLETE_MTIME_INDEX,
                KeyConditionExpression=Key("incomplete").eq(1),
                ScanIndexForward=False,
                FilterExpression=Attr("state").ne(DEFAULT_STATES[-1]),
            )
        except RetryError as e:
            # Look up how many attempts were made.
            attempts = e.last_attempt.attempt_number
            # Unpack the class of the Exception associated with the final attempt.
            orig_err = e.last_attempt.value[1]
            # If the final error was a ClientError, then the read failed despite the backoff
            # attempt.
            if isinstance(orig_err, ClientError):
                error_msg = 'JobDB.incomplete failed after {} backoff attempts'.format(attempts)
                self.log.error(error_msg)
            # If the final error was an AVAILDatabaseReadError, then the read got through but
            # failed.
            if isinstance(orig_err, AVAILDatabaseReadError):
                error_msg = 'JobDB.incomplete received error from Dynamo.'
                self.log.error(error_msg)
            # Re-raise the fatal error.
            self.log.error('Final error={}'.format(orig_err))
            raise orig_err

    def new(self, fname, user_id, states=DEFAULT_STATES):
        """Return a new Job.

        :param str asset_path: The path of the asset in this job
        :param str user_id: The user id of the authenicated user
        :param list states: A list of states for this job, defaults to
             DEFAULT_STATES. The default states are at the top of this file.
            If you have a different kind of job, you would only include the
            states that would be appropriate for that job. e.g. Uploading an
            updated metadata file migh tonly have ``["Uploading", "Published",
            "Indexed"]``.
        """
        if user_id is None:
            # TODO: Define this as system or raise exception?
            # TODO: The system may set up jobs itself, but we shouldn't blindly
            # TODO: assume that is the case. Where should we do it?
            user_id = "UnauthenticatedUser"
        j = {"fname": fname, "userId": user_id, }
        # Try to write a new job to the JobDB. If it fails, log & re-raise.
        try:
            job = Job(self._table, job_data=j, new=True, states=states)
        except RetryError as e:
            # Look up how many attempts were made.
            attempts = e.last_attempt.attempt_number
            # Unpack the class of the Exception associated with the final attempt.
            orig_err = e.last_attempt.value[1]
            # If the final error was a ClientError, then the write failed despite the backoff
            # attempt.
            if isinstance(orig_err, ClientError):
                error_msg = 'JobDB.new failed after {} backoff attempts'.format(attempts)
                self.log.error(error_msg)
            # If the final error was an AVAILDatabaseWriteError, then the write got through but
            # failed.
            if isinstance(orig_err, AVAILDatabaseWriteError):
                error_msg = 'JobDB.new received error from Dynamo.'
                self.log.error(error_msg)
            # Re-raise the fatal error.
            self.log.error('Final error={}'.format(orig_err))
            raise orig_err
        return job
