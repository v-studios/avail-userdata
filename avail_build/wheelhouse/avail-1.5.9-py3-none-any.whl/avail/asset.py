# Copyright (c) 2015 AVAIL Authors. See AUTHORS.txt in the root of the repo.
"""AVAIL Asset table and helpers."""

import logging
import os
import re

from datetime import datetime
from hashlib import sha256

from boto3.dynamodb.conditions import (And, Attr, Or)

from botocore.exceptions import BotoCoreError, ClientError

from zope.interface import implementer

from avail.exception import AVAILDatabaseConflictError
from avail.interfaces import (IAsset, IAssetDB)

RETRYABLE_EXCEPTIONS = ('ProvisionedThroughputExceededException',
                        'ThrottlingException')

MEDIA_TYPES = ['image', 'audio', 'video']
VIDEO_THUMB_SIZES = {'small': 200,
                     'thumb': 300,
                     'medium': 400,
                     'large': 800}
VIDEO_PERCENTS = (0, 5, 10, 25, 50)

log = logging.getLogger(__name__)

utcnow = datetime.utcnow


def check_video_thumb_sname(sname):
    """Raise ValueError if sname is invalid.

    Otherwise, do nothing.

    :param str sname: The sname component from a video thumb fname.
    """
    allowed_snames = VIDEO_THUMB_SIZES.keys()
    if sname not in allowed_snames:
        raise ValueError('sname=%s not in allowed_snames=%s' % (sname, allowed_snames))


def check_video_thumb_timeid(timeid):
    """Raise ValueError if timeid is invalid.

    Otherwise, do nothing.

    :param (str|int) timeid: The timeid component from a video thumb fname.
    """
    allowed_timeids = list(range(1, 1+len(VIDEO_PERCENTS)))
    # timeid could come in as a str or int; make sure it's an int before checking.
    if isinstance(timeid, str):
        try:
            timeid = int(timeid)
        except ValueError:
            # Raise after next check; error message should be the same either way.
            pass
    if timeid not in allowed_timeids:
        raise ValueError('timeid=%s not in allowed_timeids=%s' % (timeid, allowed_timeids))


def check_video_thumb_fname(fname):
    """Raise ValueError if fname is invalid.

    Otherwise, do nothing.

    :param str fname: A potential video thumb fname.
    """
    thumb_snames_regex = '|'.join(VIDEO_THUMB_SIZES.keys())
    # Video thumb regex: $NASA_ID~$SNAME_$TIMEID.jpg.
    video_thumb_regex = re.compile(r'(.+)~({})_?(\d)?\.jpg'.format(thumb_snames_regex))
    # Extract asset_id, sname, timeid from regex match groups.
    try:
        asset_id, sname, timeid = video_thumb_regex.match(fname).groups()
    # Catch exceptions indicating insufficient matches.
    except (AttributeError, ValueError):
        raise ValueError('fname={} does not match required pattern: '
                         '"nasa_id~sname_timeid.jpg"'.format(fname))
    # Check components.
    check_video_thumb_sname(sname)
    if timeid is not None:
        check_video_thumb_timeid(timeid)


def make_video_thumb_fname(asset_id, sname, timeid=None):
    """Return the filename for a video thumb.

    :param str asset_id: The unique ID of the video.
    :param str sname: The name of the size of video (see VIDEO_THUMB_SIZES).
    :param str timeid: (optional) The index of the Nth entry of VIDEO_PERCENTS. If excluded,
    makes the fname for the default thumb of that size.
    """
    check_video_thumb_sname(sname)
    if timeid is not None:
        check_video_thumb_timeid(timeid)
        return '%s~%s_%d.jpg' % (asset_id, sname, timeid)
    # No timeid, so return sname's default fname.
    return '%s~%s.jpg' % (asset_id, sname)


@implementer(IAsset)
class Asset:
    """`Asset` implements the IAsset interface.

    If a new asset create it in the DB. Typically this is only created by
    AssetDB.

    :param table: A dynamodb table
    :type table: `boto3.dynamodb.Table`
    :param dict data: The data for this asset -- from the asset table.
    :param bool new: If this is a new asset or an existing one.
    """

    def __init__(self, table, data={}, new=False):
        """Class constructor."""
        # Don't use the popularity setter here because it calls _save as a
        # side-effect, which modifies state mid-execution of __init__.
        self._data = data
        self._table = table
        if new:
            for k in ("nasaId", "assetPrefix", "owner"):
                if k not in self._data:
                    raise KeyError("Missing key {} in data.".format(k))
                if type(self._data[k]) != str:
                    raise TypeError(
                        "Got '{}' for {} but wanted 'str'".format(type(
                            self._data[k]), k))
                if len(self._data[k]) < 1:
                    raise ValueError(
                        "Expected a non-empty string for {}".format(k))
            for k in ("mtime", "deletedId", "jobs", "popularity"):
                if k in self._data:
                    raise ValueError(
                        "Can't accept '{}' when new=True".format(k))
            self._data["jobs"] = []
            self._data["popularity"] = 0
            self._data["mtime"] = utcnow().isoformat()
            self._save(insert_new=True)
        else:
            if data.get('popularity') is None:
                log.warn('__init__ called with no popularity value for assetid={}.'.format(
                    self.id))

    def _save(self, insert_new=False):
        """Write the _data to DDB; if insert_new, insist on unique nasaId."""
        kw = {'Item': self._data}
        # TODO: cache the data from the DDB:
        # kw = {'Item': self._data, 'ReturnValues': 'ALL_NEW'}
        if insert_new:
            kw['ConditionExpression'] = Attr("nasaId").not_exists()
        try:
            resp = self._table.put_item(**kw)
        except ClientError as e:
            if e.response.get("Error", {}).get("Code") == "ConditionalCheckFailedException":
                raise AVAILDatabaseConflictError(
                    "An asset with assetid={} already exists in DB.".format(self.id))
            # TODO Probably better to raise RuntimeError
            # raise RuntimeError('asset._save assetid={} boto error: {}'.format(self.id, e))
            raise e
        except BotoCoreError as e:
            # TODO add a test for this
            raise RuntimeError('asset._save assetid={} boto error: {}'.format(self.id, e))
        resp_code = resp.get("ResponseMetadata", {}).get("HTTPStatusCode")
        if resp_code != 200:
            error_msg = "Asset._save assetid={} received errorcode={} response: {}"
            log.error(error_msg.format(resp_code, self.id, resp))
            raise RuntimeError('asset._save assetid={} bad response: {}'.format(self.id, resp))
        # TODO cache the data from the DDB:
        # self._data = resp['Attributes']

    def _update(self, attr_vals):
        """Update Dynamo with only the attrs specified, not entire item as in _save().

        The _save() method saves an entire record; it has a race condition
        where more than one process reads a record, update their own attributes
        (e.g., captions_path and metadata), then write back the full record:
        the last to call _save() "wins", losing the data by the earlier calls.

        To avoid this, we'll update the DynamoDB item with only the given
        attributes and values. Since this doesn't overwrite other values, we
        avoid race conditions.

        We expect the attr_vals will be a subset of the _data that is set
        outside of this function call, since we don't attempt to update it here.

        We ask the DDB for the current data, which doesn't cost us provisioned
        capacity, and cache it in our _data so we're current.

        TODO: use update_item(..., ReturnValues='ALL_NEW') to refresh our _data
        cache from the DynamoDB, but this will take significant work on our
        mocks which don't expect returns from the DDB calls, nor other actors
        setting _data.

        :param dict attr_vals: attribute names and values from _data to set
        """
        # We need to specify update_item placeholder and values like:
        #   UpdateExpression='SET dt = :dt, #state = :state'
        #   ExpressionAttributeNames={'#state': 'state'}
        #   ExpressionAttributeValues={':dt': datetime.now().isoformat(), ':state': 'uploaded'}
        # We can't use any of the 572 "reserved words" like 'state', so we use
        # ExpressionAttributeNames prefixed with '#' to protect our attribute
        # names. Instead of trying to protect only the reserved names, we
        # prefix all our attribute names.
        kv = attr_vals.copy()
        ue = 'SET ' + ', '.join('#{} = :{}'.format(k, k) for k in kv.keys())
        ean = {'#' + k: k for k in kv}
        eav = {':' + k: v for k, v in kv.items()}
        try:
            resp = self._table.update_item(Key={"nasaId": self.id},
                                           UpdateExpression=ue,
                                           ExpressionAttributeNames=ean,
                                           ExpressionAttributeValues=eav)
        except (ClientError, BotoCoreError) as e:
            raise RuntimeError('asset._update assetid={} boto error: {}'.format(self.id, e))
        resp_code = resp.get("ResponseMetadata", {}).get("HTTPStatusCode")
        if resp_code != 200:
            msg = "Asset._update received errorcode={} response saving {}"
            log.critical('asset._update assetid={} bad response: {}'.format(self.id, resp))
            raise RuntimeError(msg)

    ###########################################################################
    # Public methods

    def delete(self):
        """Delete this item by creating a renamed copy and deleting the old.

        We can't change the nasaId as it's the primary key, but we want to keep
        a record of this asset. Since all our queries are against assetId, and
        don't check for nonexistence of some 'deleted' attribute, we do a
        switcheroo.  Create a new item with the assetid set to some hash and
        'deletedId' set to the old assetid; then delete the original.
        """
        self._data["deletedId"] = self.id
        hashable = "{}-{}-{}-{}".format(self.id, self.prefix, self.owner,
                                        self.last_modified).encode()
        # Perhaps we should use a uuid, but this should be damned unique
        self._data["nasaId"] = "deleted-{}".format(
            sha256(hashable).hexdigest())
        self._data["mtime"] = utcnow().isoformat()
        self._save()
        self._table.delete_item(Key={"nasaId": self.deleted_id})

    def increment_popularity(self):
        """Add ``1`` to this Asset's popularity."""
        self._data['popularity'] += 1
        self._update({'popularity': self._data['popularity']})

    def push_job(self, jobid):
        """Push job onto the list of jobs which have operated on this asset."""
        if type(jobid) != str:
            raise TypeError(
                "Got a '{}' for 'jobid' but wanted a 'str'".format(jobid))
        if len(jobid) < 1:
            raise ValueError(
                "Got an empty str for 'jobid', but it must be non empty")
        self._data['jobs'] = self.jobs + [jobid]
        self._data['mtime'] = utcnow().isoformat()
        self._update({'jobs': self._data['jobs'], 'mtime': self._data['mtime']})

    ###########################################################################
    # Properties

    @property
    def deleted_id(self):
        """Return the deleted id if there is one."""
        return self._data.get("deletedId")

    @property
    def id(self):
        """Return the asset id -- same as nasa id."""
        return self._data.get("nasaId")

    @property
    def jobs(self):
        """Return jobs that have operated on this asset."""
        return self._data.get("jobs")

    @property
    def last_modified(self):
        """Return the last modified time, if there."""
        return self._data.get("mtime")

    @property
    def nasa_id(self):
        """Return the nasa id (same as id)."""
        return self.id

    @property
    def owner(self):
        """Return the asset owner."""
        return self._data.get("owner")

    @property
    def popularity(self):
        """
        Return integer popularity count.

        Log a warning if popularity is found not to exist, which should never
        happen because it's set in `__init__` when initializing a new Asset.
        """
        popularity = self._data.get('popularity')
        if popularity is not None:
            # By default, Dynamo is storing this column as a `Decimal`. Convert
            # it to an `int`, since that's what we want in the first place.
            return int(popularity)
        else:
            log.warn('.popularity called for assetid={} but no popularity found.'.format(
                self.id))
            return 0

    @popularity.setter
    def popularity(self, new_value):
        """Set new integer popularity count."""
        if not isinstance(new_value, int):
            error_msg = 'Can only set popularity to an `int`; got a {}'.format(type(new_value))
            log.error(error_msg)
            raise TypeError(error_msg)
        self._data['popularity'] = new_value
        self._update({'popularity': self._data['popularity']})

    @property
    def prefix(self):
        """Return the asset prefix."""
        return self._data.get("assetPrefix")

    @property
    def media_type(self):
        """
        Return the media type, derived from the 'prefix'.

        Raise ValueError if the Asset is an unknown media type.
        """
        media_type = os.path.dirname(self.prefix)
        if media_type not in MEDIA_TYPES:
            error_msg = 'assetid={} has unknown mediatype={}'.format(self.id, media_type)
            log.error(error_msg)
            raise ValueError(error_msg)
        return media_type

    @property
    def captions_path(self):
        """
        Return the key to this Asset's captions file in S3.

        Raise ValueError if the Asset isn't a video.
        """
        if self.media_type != 'video':
            error_msg = 'assetid={} is mediatype={}, not video'.format(self.id, self.media_type)
            log.error(error_msg)
            raise ValueError(error_msg)
        return self._data.get('captionsPath')

    @captions_path.setter
    def captions_path(self, new_value):
        """Set new captions_path."""
        if self.media_type != 'video':
            error_msg = 'assetid={} is mediatype={}, not video'.format(self.id, self.media_type)
            log.error(error_msg)
            raise ValueError(error_msg)
        if not isinstance(new_value, str):
            error_msg = 'Can only set captions_path to a `str`; got a {}'.format(
                type(new_value))
            log.error(error_msg)
            raise TypeError(error_msg)
        self._data['captionsPath'] = new_value
        self._update({'captionsPath': self._data['captionsPath']})

    def __str__(self):  # pragma: no cover
        """Return a representation of a job."""
        return "{}(nasa_id={}, prefix={})".format(
            self.__class__, self.id, self.prefix)


@implementer(IAssetDB)
class AssetDB:
    """`AssetDB` wraps the dynamo asset table.

    :param table: A dynamodb table
    :type table: `boto3.dynamodb.Table`
    """

    def __init__(self, table):
        """Class constructor."""
        self._table = table

    def by_id(self, nasaid):
        """Get a Asset by nasaId.

        :return: A thin veneer around an asset table item
        :rtype: `Asset`
        """
        result = self._table.get_item(Key={"nasaId": nasaid})
        if result.get("ResponseMetadata", {}).get("HTTPStatusCode",
                                                  None) != 200:
            # TODO: Handle something here?
            log.error("AssetDB.by_id recieved non 200 response querying "
                      "dynamodb: errorcode={}".format(
                          result.get("ResponseMetadata", {})))
        item = result.get("Item")
        return Asset(self._table, data=item) if item else None

    def all(self):
        """Return a list of Assets that have not been deleted."""
        # TODO: this isn't actually complete, but the first 'page' of results
        try:
            result = self._table.query(
                IndexName="deletedId-mtime-index",
                ScanIndexForward=False,
                FilterExpression=Attr("deletedId").not_exists(), )
        except ClientError as err:
            code = err.response['Error']['Code']
            if code in RETRYABLE_EXCEPTIONS:
                raise RuntimeError('AssetDB.all query: {}'.format(code))
            raise
        rv = [Asset(self._table, data=i) for i in result["Items"]]
        return rv

    def new(self, nasaid, prefix, userid):
        """Create and return a new Asset.

        :param str nasaid: The NASA Id for this asset
        :param str prefix: The asset prefix, ex. `image/HQ1`
        :param str userid: The user that created this asset.
        :return: A thin veneer around an asset table item
        :rtype: `Asset`
        """
        for arg in ("nasaid", "prefix", "userid"):
            if type(locals()[arg]) != str:
                raise ValueError("Got <{}> for '{}', but want a <str>".format(
                    type(locals()[arg]).__name__, arg))
            if len(locals()[arg]) < 1:
                raise ValueError(
                    "Got and empty string for '{}', but need a non-empty "
                    "string".format(arg))

        a = {"assetPrefix": prefix, "nasaId": nasaid, "owner": userid}
        return Asset(self._table, data=a, new=True)

    def delete(self, nasaid):
        """Delete an asset from the table.

        Really move the id to deletedId and make a hash of the data for the id.
        Then save it.

        :param str nasaid: The nasaid.
        """
        asset = self.by_id(nasaid)
        asset.delete()
        return asset

    # TODO: we can do the scan once, and save both the Recent and Popular items
    # on the AssetDB, which might avoid a subsequent scan.

    def most_recent(self, max_results):
        """Return `max_results` most recently uploaded/updated Assets.

        Scan the entire table, which involves looping over pages of
        results, accumulating the asset data items. Sort the list by
        mtime, then truncate to the max results. Return the
        time-sorted list of Asset objects from those nasaIds.

        (The API will be reponsible for providing the client things it
        needs like C+J of collection.json URLs.)

        :param int max_results: limit how many assetIds are returned
        :returns: time-sorted `list` of `max_results` Asset objects
        :raises: HTTPInternalServerError on boto ClientError, most likely due
                 to ProvisionedThroughputExceededException
        """
        # Boto does a backoff but can still raise exception: catch and release
        filter_expression = And(Attr('deletedId').not_exists(),
                                Or(Attr('assetPrefix').begins_with('image'),
                                   Attr('assetPrefix').begins_with('video'),
                                   ))
        try:
            res = self._table.scan(FilterExpression=filter_expression)
            recent = res['Items']
            while res.get('LastEvaluatedKey'):
                res = self._table.scan(FilterExpression=filter_expression,
                                       ExclusiveStartKey=res['LastEvaluatedKey'])
                recent.extend(res['Items'])
        except ClientError as err:
            code = err.response['Error']['Code']
            log.error(err)
            if code in RETRYABLE_EXCEPTIONS:
                raise RuntimeError('AssetDB.most_recent scan: errorcode{}'.format(code))
            raise
        recent.sort(key=lambda i: i['mtime'], reverse=True)
        recent = recent[:max_results]
        assets = [Asset(table=self._table, data=asset) for asset in recent]
        return assets

    def most_popular(self, max_results):
        """Return `max_results` most popular Assets.

        Scan the entire table, which involves looping over pages of
        results, accumulating the asset data items. Sort the list by
        `popularity`, then truncate to the max results. Return the
        popularity-sorted list of Asset objects from those nasaIds.

        When we scan, we keep only assets that have popularity > 0, and this
        also filters out any which don't have that attribute set, so the
        subsequent sort will succeed. No point returning zero-popularity
        assets.

        (The API will be reponsible for providing the client things it
        needs like C+J of collection.json URLs.)

        :param int max_results: limit how many assetIds are returned
        :returns: popularity-sorted `list` of `max_results` Asset objects
        :raises: HTTPInternalServerError on boto ClientError, most likely due
                 to ProvisionedThroughputExceededException
        """
        # Boto does a backoff but can still raise exception: catch and release
        filter_expression = And(
            And(Attr('deletedId').not_exists(),
                Attr('popularity').gt(0)
                ),
            Or(Attr('assetPrefix').begins_with('image'),
               Attr('assetPrefix').begins_with('video'))
        )
        try:
            res = self._table.scan(FilterExpression=filter_expression)
            popular = res['Items']
            while res.get('LastEvaluatedKey'):
                res = self._table.scan(FilterExpression=filter_expression,
                                       ExclusiveStartKey=res['LastEvaluatedKey'])
                popular.extend(res['Items'])
        except ClientError as err:
            log.error(err)
            code = err.response['Error']['Code']
            if code in RETRYABLE_EXCEPTIONS:
                raise RuntimeError('AssetDB.most_popular scan errorcode={}'.format(code))
            raise
        popular.sort(key=lambda i: i['popularity'], reverse=True)
        popular = popular[:max_results]
        assets = [Asset(table=self._table, data=asset) for asset in popular]
        return assets
