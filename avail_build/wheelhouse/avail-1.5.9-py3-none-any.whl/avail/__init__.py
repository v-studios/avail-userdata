"""
The entry point for the egg and app.

Copyright (c) 2015 AVAIL Authors. See AUTHORS.txt in the root of the repo.
"""

from pyramid.config import Configurator

from avail.aws import register_assets
from avail.aws import register_fs
from avail.aws import register_jobs
from avail.aws import register_tmpfs
from avail.aws import register_users

from avail.system.predicates import ContentTypePredicate


def main(global_config, **settings):
    """main function returns a Pyramid WSGI application."""
    config = Configurator(settings=settings)
    # TODO: Do we need static files? We should prolly serve these from S3.
    # config.add_static_view('static', 'static', cache_max_age=3600)
    config.add_directive("register_fs", register_fs, action_wrap=True)
    config.add_directive("register_tmpfs", register_tmpfs, action_wrap=True)
    config.add_directive("register_assets", register_assets, action_wrap=True)
    config.add_directive("register_jobs", register_jobs, action_wrap=True)
    config.add_directive("register_users", register_users, action_wrap=True)
    config.register_fs()
    config.register_tmpfs()
    config.register_assets()
    config.register_jobs()
    config.register_users()
    config.add_view_predicate("content_type", ContentTypePredicate)

    config.add_route('home', '/{ass_type}/{key}')
    config.add_route('info', '/{ass_type}/{key}/json')
    config.add_route("post", "/asset")
    config.add_route("delete", "/{ass_type}/{key}")
    config.add_route('root', '/')

    config.scan()
    return config.make_wsgi_app()
