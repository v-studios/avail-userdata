bcdoc
=====

|Build Status|


Tools to help document botocore-based projects

.. |Build Status| image:: https://travis-ci.org/boto/bcdoc.png?branch=develop
   :target: https://travis-ci.org/boto/bcdoc


