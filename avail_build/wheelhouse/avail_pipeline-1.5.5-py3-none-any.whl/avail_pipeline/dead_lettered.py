#!/usr/bin/env python
"""Deal with Jobs whose messages have reached the DeadLetter queue."""
# Copyright 2015 AVAIL Authors. See AUTHORS.txt in the root of the repo.
import sys
from time import sleep

from botocore.client import ClientError

from zope.interface import implementer

from avail.exception import AVAILDatabaseWriteError
from avail_pipeline.cli import RunWorker
from avail_pipeline.interfaces import IWorker
from avail_pipeline.pipeline import Worker


@implementer(IWorker)
class DeadLetterWorker(Worker):
    """
    Flag a Job that's reached the DeadLetterQueue, then bail.

    Since Jobs are never sent to the DeadLetter queue on purpose, they will
    have died for some unknown reason. We want to preserve all their artifacts
    for future study, and we want to make a note somewhere more permanent than
    an SQS queue that this Job reached the DeadLetterQueue.

    * Consume messages from the DeadLetterQueue.
    * Reset message visibility when message read.
    * Invoke Handler to:
      + Set the Job's .deadlettered attr to True.
      + Upon successful finish: delete this message from the DeadLetterQueue.
    * Provide an entrypoint for supervisord.

    See pipeline.Worker for a list of inherited params, most of which won't be
    used explicitly in this subclass.

    :param str queue: Name of the SQS queue this Worker polls.
    """

    def __init__(self, queue, *args, **kwargs):
        """Class constructor."""
        super().__init__(queue, *args, **kwargs)

    def handle(self, task, *args, **kw):
        """
        Handle incoming messages from the DeadLetterQueue.

        See the class docstring for high-level details.

        :param task: A container task composed of the job and SQS message.
        :type  task: `avail_pipeline.task.SegmentTask`
        """
        job = task.job
        self.log.info("Handling jobid={}".format(job.id))
        if not job.deadlettered:
            self.log.debug("Setting job.deadlettered = True")
            try:
                job.deadlettered = True
            except (AVAILDatabaseWriteError, ClientError, ):
                error_msg = 'Error setting deadlettered=True for jobid={}.'.format(job.id)
                self.log.warn(error_msg)
                # If the JobDB couldn't be updated then this method can't complete, so bail.
                return False
        elif job.deadlettered:
            self.log.warn("This jobid={} has been deadlettered before".format(job.id))
        self.log.debug("Deleting this message from its queue.")
        task.msg.delete()
        self.log.debug("Deleted message `{}`.".format(task.msg.message_id))
        self.log.info("Finished handling jobid={}.".format(job.id))

    def handle_error(self, task, *args, **kwargs):
        """
        Do nothing.

        Override the parent class's .handle_error method because this Worker
        should never submit jobs to the ErrorQueue.
        """
        self.log.warn("Something caused DeadLetterWorker.handle_error to run.")
        pass

    def _run(self):
        """Run the DeadLetterWorker once."""
        if self.poll_interval:
            self.log.debug("Going to sleep for {} seconds.".format(
                self.poll_interval))
            sleep(self.poll_interval)
        # Worker.poll does a bunch of good logging. Not adding more.
        segment_task = self.poll()
        if segment_task:
            self.handle(segment_task)

    def run(self, run_forever=True):
        """
        Run the DeadLetterWorker.

        Override the parent class's .run method because this Worker should
        always call .handle, never .handle_error; it doesn't care about Job
        state like other Workers do.

        :param bool run_forever: If ``True``, then run this Worker forever. If
        ``False``, then run this Worker once. Default: ``True``.
        """
        if run_forever is True:  # pragma: no cover
            while True:
                self._run()
        else:
            self._run()


def worker():  # pragma: no cover
    """Entrypoint: start up an instance of the DeadLetterWorker.

    Reads .ini file name as first arg from command line to get our
    bucket names.
    """
    command = RunWorker(sys.argv, DeadLetterWorker)
    command.run()


if __name__ == "__main__":
    worker()
