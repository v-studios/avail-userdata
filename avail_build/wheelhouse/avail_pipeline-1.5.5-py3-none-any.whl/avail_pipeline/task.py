"""AVAIL pipeline CLI bits.

Copyright (c) 2015 AVAIL Authors.  See AUTHORS.txt in the repo root.
"""


class SegmentTask:
    """A container composed of SQS Message and Job.

    This may grow appendages, but hopefully not. Since it only has two attrs we
    aren't writing an interface. If it grows methods and attrs it should also
    have an interface defined.
    """

    def __init__(self, msg, job):
        """Class constructor.

        :type msg: ``boto3.resource.sqs.Message``
        :param msg: A message pulled from an sqs queue.
        :type job: ``avail.job.Job``
        :param job: A job pulled from the job db.
        """
        self.msg = msg
        self.job = job

    @property
    def et_job_id(self):
        """Return the msg.message_attributes["et_job_id"] value if one."""
        return self.msg.message_attributes.get("et_job_id", {}).get(
            "StringValue") if self.msg.message_attributes else None

    @property
    def job_id(self):
        """Return the job.id if there is a job."""
        return self.job.id if self.job else None

    @property
    def last_message_id(self):
        """Return the last message id.

        This is returned from the current message's message_attributes.
        """
        return self.msg.message_attributes.get("last_message_id", {}).get(
            "StringValue") if self.msg.message_attributes else None

    @property
    def last_receipt_handle(self):
        """Return the last message's receipt handle.

        This is returned from current message's msg_attributes.
        """
        return self.msg.message_attributes.get("last_receipt_handle", {}).get(
            "StringValue") if self.msg.message_attributes else None

    @property
    def common_attrs(self):
        """Return the common attribvutes we want to store on an SQS msg."""
        attrs = {
            "last_message_id": self.msg.message_id,
            "last_receipt_handle": self.msg.receipt_handle,
        }
        if self.job:
            attrs["job_id"] = self.job.id
        return attrs

    @property
    def waiting_for_metadata(self):
        """Return whether we're waiting for metadata file upload."""
        return self.msg.message_attributes.get("waiting_for_metadata", {}).get(
            "StringValue") if self.msg.message_attributes else None

    @property
    def waiting_for_captions(self):
        """Return whether we're waiting for captions file upload."""
        return self.msg.message_attributes.get("waiting_for_captions", {}).get(
            "StringValue") if self.msg.message_attributes else None

    def __str__(self):
        """Return a human-readable representation of this instance."""
        return "{}(msg={},job={})".format(self.__class__, self.msg.message_id,
                                          self.job.id)
