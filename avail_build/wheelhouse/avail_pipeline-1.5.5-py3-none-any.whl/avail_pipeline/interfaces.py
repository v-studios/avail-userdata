"""Copyright 2015 AVAIL Authors.  See AUTHORS.txt in the repo root.
"""

from zope.interface import (Attribute, Interface)


class IWorker(Interface):  # pragma: no cover
    """An ``IWorker`` impl manages an AVAIL pipeline segment.

    1. Initialize class
    2. poll queue for one job.
    3. look up job

        - Check if error
        - Remove from previousq
        - Handle error?
        - put in nextq (last queue?)
        - transition job (to next (previous?) state

    4. remove from previousq
    5. make queue message invisible
    6. perform work (handle)

        - If error
        - Mark job as error
        - Handle error (The Job should go and save itself.)
        - transition job
        - put in next queue

    """

    def __init__(queue, errq, previousq, nextq,
                 logger=None,
                 poll_interval=0,
                 max_poll_interval=0,
                 backoff_poll_interval=0,
                 settings={},
                 verbose=False,
                 get_jobdb_table_from_settings=None,
                 get_named_queue_from_settings=None):  # flake8: noqa
        """Class constructor."""

    def handle(task, *args, **kw):  # flake8: noqa
        """Handle a task.

        errq, previousq, nextq, queue, job,

        1. handle (in subprocess??)
        2. process result

            - Error
            - Set error on Job (This queue would pick up again and handle
            the error.)

            - Success
            - insert into nextq
            - transition job

        """

    def handle_error(task, *args, **kw):  # flake8: noqa
        """Handle an error.

        In subprocess:
        1. Clean up
        2. insert into nextq (previousq?)
        3. transition job
        4. Remove from queue

        """

    def run():  # flake8: noqa
        """Run the poller continuously."""

    jobs = Attribute("Return the JobDB table.")
    log = Attribute("Return the logger.")
    poll = Attribute("""Return a message from the queue if there is one.

        If the message's related job is in an error state, deal with it and
        return None. Otherwise return the message and the job (as a tuple or a
        containerclass?). Update the poll_interval to 0 if we had an item
        or increase by backoff until it reaches max_poll_interval.
        """)
    poll_interval = Attribute("Return the interval between queue polls.")
