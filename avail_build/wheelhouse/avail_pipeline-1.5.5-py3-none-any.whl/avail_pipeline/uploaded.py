"""Copyright 2015 AVAIL Authors.  See AUTHORS.txt in the repo root."""

import inspect
import json
import logging
import subprocess
import sys
import tempfile
import time

from os.path import (sep, split as pathsplit, splitext)

import boto3

from botocore.client import ClientError

from pyramid.exceptions import ConfigurationError

from requests import (Response, post)

from zope.interface import implementer

from avail.aws import get_et_pipeline_from_settings
from avail.aws.dynamodb import get_userdb_table_from_settings
from avail.aws.s3 import (fs_from_settings,
                          get_public_s3_artifact_key,
                          tmpfs_from_settings,
                          )
from avail.exception import AVAILDatabaseWriteError
from avail.job import CAPTIONS_EXTS
from avail.metadata import (METADATA_FILENAME, Metadata)

from avail_pipeline.cli import RunWorker
from avail_pipeline.config import RegistryShim
from avail_pipeline.interfaces import IWorker
from avail_pipeline.pipeline import Worker


image_resizer_host = "avail_imageresizer.host"

# An asset's job will come to this queue as 'Uploading', and an audio or video
# asset's job will get a duplicated queue message sent to this queue as
# 'Uploaded'.
TARGET_STATES = ['Uploading', 'Uploaded', ]


def linenum():
    """Return the current line number in our program."""
    return inspect.currentframe().f_back.f_lineno


class Transcoder:
    """A helper to unify transcoding/resizing calls.

    :param dict settings: A dict comprised of the settings from the ini file.
    :type get_et_pipeline_from_settings: func or `unittest.mock.Mock`
    :param get_et_pipeline_from_settings: For testing.
    :type post: func or `unittest.mock.Mock`
    :param post: For testing.
    """

    def __init__(self, settings,
                 get_et_pipeline_from_settings=get_et_pipeline_from_settings,
                 post=post):
        """Class constructor."""
        self._et_pipeline = get_et_pipeline_from_settings(settings)
        self._image_resizer_host = settings.get(image_resizer_host, None)
        if not self._image_resizer_host:
            raise ConfigurationError(
                "{} must be in settings".format(image_resizer_host))
        self.tmp_bucket_name = settings['avail.aws.s3.tmp.bucket.name']
        self._post = post
        self.log = logging.getLogger('{}.{}'.format(__name__, self.__class__.__name__))

    def __call__(self, keyin, prefix_out=""):
        """Send request to ET or imageresizer.

        Initiate the resize or transcode based on the type of asset.

        :param str keyin: The input key relative to its bucket.
        :param str prefix_out: Prefix for the output key
        :rtype: dict
        """
        if "/image/" in keyin:
            if not prefix_out:
                # No trailing slash here as it appears imageresizer adds the
                # slash after OUT. Though I don't think ET does.
                # NB: Not validating the keyin here as it should have been
                # validated by now, upstream as asset_path.
                # Uses os.path.split to remove the file name and joins the tail
                # together with "OUT" e.g.:
                # uuid/image/HQ1/HQ1.jpg -> uuid/image/HQ1/OUT
                keyout = sep.join([pathsplit(keyin)[0], "OUT"])

            payload = {"input_key": keyin, "output_key_prefix": keyout}
            try:
                # TODO: set a timeout to prevent the request from waiting for
                # a very long time.
                resp = self._post(
                    "http://{}/imageresizer".format(self._image_resizer_host),
                    data=json.dumps(payload),  # timeout=3
                )

            except Exception as e:
                # Could be multiple errors here, Connection, Timeout, others.
                raise RuntimeError(
                    "Couldn't reach the image resizer {}: {}".format(
                        self._image_resizer_host, e))

        elif "/video/" in keyin:
            width, height, fps = self._get_video_width_height(keyin)
            resp = self._et_pipeline.create_job(
                keyin, orig_width=width, orig_height=height, orig_fps=fps)
        elif "/audio/" in keyin:
            resp = self._et_pipeline.create_job(keyin)
        else:
            raise ValueError(
                "Unacceptable keyin {}. Expected keyin to contain one of "
                "'/audio/', '/image/', or '/video/'.".format(keyin))
        return resp

    def done(self, et_job_id):
        """Return if the provided et_job_id is done.

        This simply wraps the _et_pipeline done method.
        """
        return self._et_pipeline.done(et_job_id)

    def _get_video_width_height(self, priv_s3_key):
        """Get the WxH and Frame Per Second of the video so we don't upscale.

        Exiftool can get Composit:ImageSize but we may not have run it if the
        user supplied the metadata AVAIL needs. Instead, we run `mediainfo`
        compiled against `libcurl` so it can read the remote S3 object
        directly, pulling only the chunks it needs. We create a presigned URL
        to be able to read the media. See:

        https://aws.amazon.com/blogs/compute/extracting-video-metadata-using-lambda-and-mediainfo/

        We could also get the 'Codec' and reject ones ET can't handle.

        :param str priv_s3_key: key in private s3 bucket to analyze.
        :returns tuple: (width, height)
        """
        s3 = boto3.client('s3')
        psurl = s3.generate_presigned_url('get_object',
                                          Params={'Bucket': self.tmp_bucket_name,
                                                  'Key': priv_s3_key},
                                          ExpiresIn=1200)
        try:
            whc = subprocess.check_output([
                'mediainfo',
                '--Inform=Video;%Width% %Height% %FrameRate%',
                psurl,
            ])
        except (FileNotFoundError, subprocess.CalledProcessError) as e:
            msg = 'Invoking "mediainfo" failed on assetpath={}: error={}'.format(
                priv_s3_key, e)
            self.log.critical(msg)  # FileNotFound if our OS doesn't have the tool
            raise RuntimeError(msg)
        whc = whc.decode(encoding='UTF-8')
        try:
            (width, height, framerate) = whc.split()
        except ValueError as e:
            msg = 'Unpacking video attributes from whc={}: {}'.format(whc, e)
            self.log.critical(msg)
            raise RuntimeError(msg)
        self.log.info('video assetpath={} width={} height={} framerate={}'.format(
            priv_s3_key, width, height, framerate))
        # TODO: can't simply int('30.0') but framerate could be non-integral.
        return (int(width), int(height), int(float(framerate)))


@implementer(IWorker)
class UploadedWorker(Worker):
    """The pipeline manager for the uploaded queue.

    This Manager listens for work on the Uploaded Queue and performs the next
    step in the process -- Resizing.

    Inherited params:
    :type queue: str
    :param queue: The name of the queue this manager listens on.
    :type errq: str
    :param errq: The name of the error queue in this  pipeline.
    :type previousq: str
    :param previousq: The name of the prior queue in the pipeline.
    :type nextq: str
    :param nextq: The name of the next queue in the pipeline
    :type logger: logging.Logger
    :param logger: A logger to log with.
    :type poll_interval: int
    :param poll_interval: The interval at which to poll our queue in seconds.
    :type max_poll_interval: int
    :param max_poll_interval: The longest poll interval we will backoff to in
        seconds.
    :type backoff_poll_interval: int
    :param backoff_poll_interval: The amount in seconds we add to our
        ``poll_interval`` if the queue was empty.
    :param int visibility_timeout: The invisibility period of a recieved
        message.
    :param int wait_time_seconds: The period to wait for new messages after
        connecting to SQS.
    :type handler: callable
    :param handler: A callable which uses the information in a SegmentTask to
        process an Asset. If successful: transitions the SegmentTask's Job to
        its next state, updates that Job in the JobDB, in some cases posts a
        new message to the next SQS queue using the Job's state list, and
        finally deletes the SegmentTasks's associated SQS message. (In some
        workflow states, the step of posting a new message to the next SQS
        queue is handled implicitly by an AWS service, e.g., S3.) If
        unsuccessful: marks this Job as having an error, updates the Job in the
        JobDB, posts a new message to the SQS ErrorQueue or IncompleteQueue
        (depending on the details of processing), and finally deletes the
        SegmentTasks's associated SQS message.
    :type settings: dict
    :param  settings: A map of 'settings' for the ``Worker``.
    :type verbose: bool
    :param verbose: If more output should be logged.
    :type get_jobdb_table_from_settings: Mock or func
    :param get_jobdb_table_from_settings: A place to pass in a mock for
        testing.
    :type get_named_queue_from_settings: Mock or func
    :param get_named_queue_from_settings: A place to pass in a mock for
        testing.

    Local Params:
    :type transcoder: :class:`Transcoder` or :class:`unittest.mock.Mock`
    :param transcoder: A helper class to transcode.
    :type get_et_pipeline_from_settings: func or `unittest.mock.Mock`
    :param get_et_pipeline_from_settings: For testing.
    :type  get_userdb_table_from_settings
    :param get_userdb_table_from_settings: For testing.
    """

    def __init__(self, queue, errq, previousq, nextq,
                 get_et_pipeline_from_settings=get_et_pipeline_from_settings,
                 get_userdb_table_from_settings=get_userdb_table_from_settings,
                 transcoder=Transcoder, *args, **kw):
        """Class constructor."""
        super().__init__(queue, errq, previousq, nextq, *args, **kw)
        self._transcode = transcoder(
            kw.get("settings", {}),
            get_et_pipeline_from_settings=get_et_pipeline_from_settings,
            post=post)
        self._users = get_userdb_table_from_settings(RegistryShim(self._settings))
        self._tmpfs = tmpfs_from_settings(RegistryShim(self._settings))
        self._fs = fs_from_settings(RegistryShim(self._settings))

    def handle(self, task, *args, **kw):
        """Handle incoming messages from the uploaded queue.

        Transcode/resize assets and extract metadata if it's not provided.

        The asset is in private S3. We `transcode` it, which means we submit
        audio/video to ElasticTranscoder and images to our ImageResizer. Even
        tho we abstract 'Transcoder`, we are currently obliged to look at the
        task to see if its an ET job and handle it differently than image jobs.

        If the upload is a captions file, simply delete the message: a
        subsequent process will check for it and copy to public s3.

        The metadata.json file *may* have been uploaded too, sitting in public
        S3. If not, extract the metadata from the asset file using a local
        `exiftool` binary; we must scanning the entire file and enabling large
        file support to pick up blocks from TIFF and Video files we'd otherwise
        miss.

        :param task: A container task composed of the job and SQS message.
        :type task: `avail_pipeline.task.SegmentTask`
        """
        self.log.info("Handling sqsid={} sqstime={} sqscount={} "
                      "jobid={} in state={}".format(
                          task.msg.message_id,
                          task.msg.attributes['SentTimestamp'],
                          task.msg.attributes['ApproximateReceiveCount'],
                          task.job.id, task.job.state))

        # TODO: This stuff should become its own Pipeline worker. This worker should start with
        # the check for 'Records' in the message body.
        if task.et_job_id:  # no msg body in et_job waiting msg
            # This is an ET Pipeline Job for which we are awaiting completion.
            self.log.info('Got ET task with etjobid={} for jobid={}'.format(
                task.et_job_id, task.job.id))
            # Make sure this job hasn't already been processed.
            if task.job.state != 'Uploaded':
                # Log warning that job which has already been processed is being seen again.
                self.log.warn(
                    'ET jobs should be in state="Uploaded", but got jobid={} '
                    'in state={}'.format(task.job.id, task.job.state))
                # Delete associated queue message.
                self.log.debug('Deleting msgid={}'.format(task.msg))
                task.msg.delete()
                return
            # It hasn't been, so process it.
            self._handle_et_job(task)
            return
        msg_body = json.loads(task.msg.body)
        if 'Records' not in msg_body:
            self.log.critical('Got task.msg.body with no Records key: {}'.format(msg_body))
            self.handle_error(task)
            return False
        # Ignore messages caused by captions landing in S3.
        # We expect our upload name is forced to lowercase caption.{srt,vtt}
        # We also expect the API will store the key at upload time.
        uploaded_key = msg_body['Records'][0]['s3']['object']['key']
        if splitext(uploaded_key)[1] in CAPTIONS_EXTS:
            self.log.info('jobid={} got caption key={}, deleting msg to ignore'.format(
                task.job, uploaded_key))
            task.msg.delete()
            return
        # All media types' jobs come in as 'Uploading' because the upload to S3 just finished.
        # Transition them to 'Uploaded'.
        if task.job.state == 'Uploading':
            self.log.info('Transitioning jobid={} from Uploading to Uploaded.'.format(
                task.job.id))
            try:
                task.job.transition()
            except (AVAILDatabaseWriteError, ClientError, ):
                # If the job isn't transitioned, log & handle the error.
                error_msg = 'Error transitioning jobid={} to nextstate={}'.format(
                    task.job.id, task.job.next_state)
                self.log.warn(error_msg)
                self.handle_error(task)
                return False
        if task.job.state != 'Uploaded':
            self.log.critical('Got jobid={} in unexpected state={}'.format(task.job.id,
                                                                           task.job.state))
            self.handle_error(task)
            return False

        # Make this msg invisible for a long time so other instances won't pick
        # up the same message while we're downloading for an hour or more (14GB
        # takes 2h in Dev, 7 minutes in Stage).  We'll delete and transition if
        # successful; if the process aborts or instance gets killed, this will
        # allow another to pick up the work. We have to calc the remaining time
        # from first received to get the SQS max of 12 hours.
        #
        # TODO: calculation is NOT reliable, even when using SentTimestampe
        # instead of FirstReceivedTimestamp. I don't know how to calculate this
        # accurately, so I'm gonna drop the 12h to 10h. I don't think this will
        # *solve* the problem (e.g., msg submitted but never read for hours)
        # but may get us over the hump.
        #
        # TODO: we really need this wait-for-download-and-extract to be its own
        # worker and queue -- we're doing too much in this one.
        # received_ts = int(task.msg.attributes['ApproximateFirstReceiveTimestamp']) / 1000
        sent_ts = int(task.msg.attributes['SentTimestamp']) / 1000
        seconds_left = int(10 * 60 * 60 - (time.time() - sent_ts))
        self.log.debug('Setting msg visibilitytimeout={}'.format(seconds_left))
        task.msg.change_visibility(VisibilityTimeout=seconds_left)

        # Handle metadata, whether already uploaded or we have to extract
        user = self._users.by_auid(task.job.owner)

        try:
            self._handle_metadata(task.job.asset_path,
                                  media_type=task.job.media_type,
                                  nasa_id=task.job.asset_id,
                                  owner=task.job.owner,
                                  center=user.center)
        except (RuntimeError, ValueError) as err:
            # We can't extract to Metadata so mark the job errored
            self.log.error(
                '_handle_metadata taskid=%s jobid=%s nasaid=%s: %s',
                task, task.job.id, task.job.asset_id, err)
            # Mark the task as errored, do not continue processing
            self.handle_error(task)
            return              # return value not consumed

        # Transcode the asset (with ImageResizer or ElasticTranscoder)
        try:
            resp = self._transcode(task.job.asset_path)
            # If this was an image, the return value from _transcode will be a Response. If not,
            # then it will be a dict.
            if isinstance(resp, Response):
                # It is a requests.post response
                self.log.debug("Called transcoder to resize assetpath={}."
                               " Received response errorcode={}".format(
                                   task.job.asset_path, resp.status_code))
                # If the status code indicates an error, handle it.
                if resp.status_code >= 400:
                    self.handle_error(task)
                    return False
                # The resize succeeded.
                # Send a message to the TranscodedQueue. Set it to delay 5 seconds to avoid
                # race conditions where a TranscodedWorker picks up the message before its
                # state is updated to Transcoded.
                self.log.info("IR jobid={} done; sending to nextq={}.".format(
                    task.job.id, self._nextq.url.split('/')[-1]))
                self._send_message(self._nextq, string_attrs=task.common_attrs,
                                   delay_seconds=5,)
                # Delete this message.
                task.msg.delete()
                self.log.info('IR job transitioning from Uploaded to Transcoded; '
                              'jobid={}.'.format(task.job.id))
                try:
                    task.job.transition()
                except (AVAILDatabaseWriteError, ClientError, ):
                    # If the job isn't transitioned, log & handle the error.
                    error_msg = 'Error transitioning jobid={} to nextstate={}'.format(
                        task.job.id, task.job.next_state)
                    self.log.warn(error_msg)
                    self.handle_error(task)
                    return False
                return True
            # If this is a video or an audio....
            elif isinstance(resp, dict):
                # It is an et job
                self._wait_for_et_job(task, resp)
                return True
            else:
                raise RuntimeError(
                    'Unexpected return value from Transcoder for jobid={}: {}'.format(
                        task.job.id, resp))
        # TODO: Are exceptions always images?
        except (ValueError, RuntimeError) as e:
            self.log.error(
                "Calling transcoder for taskid={} received an error {}".format(task, e))
            self.handle_error(task)
            return              # return value not consumed
        except Exception as e:
            self.log.critical("Unexpected Exception raised: {} Continuing.".format(e))

    def _download_callback(self, nbytes):
        """Log the number of bytes that the download_fileobj() updates periodically."""
        self.downloaded_bytes += nbytes
        self.log.debug('_download_callback bytes={} downloadedbytes={}'.format(
            nbytes, self.downloaded_bytes))

    def _handle_metadata(self, asset_path, media_type=None, nasa_id=None, owner=None,
                         center=None):
        """If no S3 metadata.json file, extract from asset and store in S3.

        * Get metadata.json key and look for it on public s3.
        * If not there:
          - copy the asset to local disk
          - run `exiftool` on it to generate metadata dict
          - add AVAIL:MediaType, AVAIL:NASAID, AVAIL:Owner, AVAIL:Center
          - store to public S3

        If we have an existing metadata file, we don't need to extract. We don't validating
        pre-sent metadata since we know it's validated down the line.

        When we extract, we add media_type, nasa_id, owner and center so we should get enough to
        validate and for users to edit via the UI, but we don't validate here as it's not the
        right place to push the job to the Incomplete state.

        If we get an error trying to extract, we create a minimal MD file containing only
        AVAIL:MediaType, AVAIL:NASAID, AVAIL:Owner, AVAIL:Center since we have that info and
        it's enough to get the job in front of a human who can add more data.

        Pass successfully-extracted metadata through an AVAIL Metadata instance to populate the
        "AVAIL:" values. (The UI relies on this, as it's what the API used to do.)

        :param str asset_path: private S3 asset key
        :param str media_type: the AVAIL:MediaType to be added to the metadata
        :param str nasa_id: the AVAIL:NASAID to be added to the metadata
        :param str owner: the AVAIL:Owner to be added to the metadata
        :param str center: the AVAIL:Center to be added to the metadata

        :returns: nothing
        :raises ValueError: Called without nasa_id, owner or center
        :raises KeyError: asset file not found
        """
        if not media_type or not nasa_id or not owner or not center:
            raise ValueError('No media_type={} or nasa_id={} or owner={} or center={}'.format(
                media_type, nasa_id, owner, center))
        # TODO log jobid (how do we get it?)
        self.log.debug('Handle metadata mediatype={} assetid={}, userid={}, center={}'.format(
            media_type, nasa_id, owner, center))
        md_min = {'AVAIL:MediaType': media_type,
                  'AVAIL:NASAID': nasa_id,
                  'AVAIL:Owner': owner,
                  'AVAIL:Center': center}
        md_dict = {}        # default empty if we can't extract
        s3_md_key = get_public_s3_artifact_key(asset_path, METADATA_FILENAME)
        try:
            _fname, md_str = self._fs.get(s3_md_key)
            self.log.debug('Not extracting, existing assetid={} metadata={}'.format(
                nasa_id, s3_md_key))
            return
        except KeyError:
            # TODO log jobid (how do we get it?)
            self.log.debug('Extracting, no metadata assetid={} key={}'.format(
                nasa_id, s3_md_key))

        # This context manager removes tmp file when exited, after exiftool is done
        try:
            with tempfile.NamedTemporaryFile() as disk_fp:
                try:
                    self.log.info('Downloading for extraction assetid={}'.format(nasa_id))
                    self.downloaded_bytes = 0
                    self._tmpfs.bucket.meta.client.download_fileobj(
                        Bucket=self._tmpfs.bucket.name,
                        Key=asset_path,
                        Fileobj=disk_fp,
                        Callback=self._download_callback,
                    )
                    # TransferManager doesn't close(), so we flush() so exiftool gets
                    # everything; if we close(), the namedtempfile gets disappeared.
                    disk_fp.flush()
                    # If we fail on exiftool, fall thru with default empty dict
                    self.log.info('Downloaded for extraction assetid={} to '
                                  'namedtempfile={}'.format(nasa_id, disk_fp.name))
                    try:
                        md_dict = self._handle_exiftool(disk_fp.name)
                    except FileNotFoundError as e:
                        self.log.critical('Could not find `exiftool` e={}'.format(e))
                    except RuntimeError as e:
                        self.log.error('Could not extract assetpath={} err={}'.format(
                            asset_path, e))
                except (ClientError, OSError) as e:  # don't know how to detect disk full
                    self.log.critical('Download bucket={} key={} to disk: {}'.format(
                        self._tmpfs.bucket.name, asset_path, e))
        except OSError as e:  # don't know how to detect disk full
            self.log.critical('Download OSError bucket={} key={} to disk: {}'.format(
                self._tmpfs.bucket.name, asset_path, e))

        # Add our minimal AVAL info to exiftool's so have enough to Metadata-ize it
        md_dict.update(md_min)
        # Turn the combined info to Metadata so it can convert exif information
        # to AVAIL:* attributes we need.
        md_json_str = json.dumps(md_dict)
        try:
            metadata = Metadata(md_json_str)
        except ValueError as e:
            error_msg = 'exiftool output {} unusable: {}'.format(md_json_str[:256], e)
            self.log.error(error_msg)
            raise RuntimeError(error_msg)
        # Pull out a dictionary from the Metadata instance.
        md_json_dict = metadata._md

        # Could store string content with BytesIO acting as file:
        # md_bytes_fp = BytesIO(json.dumps(md_dict, indent=1).encode('utf-8'))
        # self._fs.put(s3_md_key, md_bytes_fp,
        #              cache_control='public, max-age=300, s-maxage=600')
        try:
            # Do cache metadata, edits need to be seen immediately (is 'no-cache' better?)
            self._fs.bucket.meta.client.put_object(
                Bucket=self._fs.bucket.name,
                Key=s3_md_key,
                Body=json.dumps(md_json_dict, indent=1).encode('utf-8'),
                CacheControl='public, max-age=300, s-maxage=600',
                ACL='public-read',
                ContentType='application/json',
            )
        except ClientError as e:
            self.log.error('Put key={} to bucket={} e={}'.format(
                s3_md_key, self._fs.bucket.name, e))
            # TODO: what do we do if we can't create the output?

        # Log AVAIL keys we extracted that we didn't supply
        avail_extracted_keys = set([k for k, v in metadata.avail_items().items() if v])
        avail_supplied_keys = set([k.replace('AVAIL:', '') for k in md_min.keys()])
        self.log.info('Extracted from assetpath={} new AVAIL keys: {})'.format(
            asset_path, avail_extracted_keys - avail_supplied_keys))

    def _handle_exiftool(self, fname):
        """Return media metadata by running `exiftool` on the file name.

        We now read a (tmp) disk file by name which is MUCH faster than reading an fp,
        and exiftool does not run out of RAM like reading the fp does for large videos.

        :param fname: temporary disk file name
        :returns dict: JSON of metadata
        :raises FileNotFoundError: could not find `exiftool`
        :raises RuntimeError: other problems running `exiftool` on our data
        """
        try:
            exiftool = subprocess.Popen(['exiftool',
                                         '-api', 'largefilesupport=1',
                                         '-sort', '-a', '-S', '-G',
                                         '-struct', '-j', fname],
                                        stdin=None,
                                        stdout=subprocess.PIPE,
                                        stderr=subprocess.PIPE)
        except FileNotFoundError as e:
            msg = 'Could not find exiftool error={}'.format(e)
            self.log.critical(msg)  # Our OS should have the tool dammit
            raise FileNotFoundError('Could not find exiftool e={}'.format(e))
        (json_bytes, stderr) = exiftool.communicate()
        if stderr != b'':
            raise RuntimeError('exiftool stderr: {}'.format(stderr))
        try:
            json_str = json_bytes.decode(encoding='UTF-8')
        except AttributeError as e:
            raise RuntimeError('Could not decode exiftool bytestring')
        try:
            json_dict = json.loads(json_str)
        except ValueError as e:
            raise RuntimeError('Decoding exiftool as JSON, e={} str={}'.format(e, json_str))
        if len(json_dict) != 1:
            raise RuntimeError('Expected 1-element list, json_dict_={}'.format(json_dict))
        return json_dict[0]

    def _handle_et_job(self, task):
        # Check if an et_pipeline job is done
        et_job_id = task.et_job_id
        try:
            if self._transcode.done(et_job_id):
                self.log.info("ET Done etjobid={} for jobid={} done; "
                              "sending to nextq={}.".format(
                                  et_job_id, task.job.id, self._nextq.url.split('/')[-1]))
                attrs = task.common_attrs
                # Send a message to the TranscodedQueue. Set it to delay 5 seconds to avoid
                # race conditions where a TranscodedWorker picks up the message before its
                # state is updated to Transcoded.
                self._send_message(self._nextq,
                                   string_attrs=attrs,
                                   delay_seconds=5,)
                task.msg.delete()
                self.log.info('ET job transitioning from Uploaded to Transcoded; '
                              'jobid={}.'.format(task.job.id))
                try:
                    task.job.transition()
                except (AVAILDatabaseWriteError, ClientError, ):
                    # If the job isn't transitioned, log & handle the error.
                    error_msg = 'Error transitioning jobid={} to nextstate={}'.format(
                        task.job.id, task.job.next_state)
                    self.log.warn(error_msg)
                    self.handle_error(task)
                    return False
                return
            # If the job is not done, keep waiting.
            else:
                # Submit a clone of this message which will get read in a minute. Then, delete
                # the original message. This allows us to avoid the SQS Queue's MaxReceiveCount,
                # which would implicitly impose a time limit on the duration of an ET job.
                attrs = task.common_attrs
                attrs["et_job_id"] = task.et_job_id
                self.log.info(
                    'Sending new wait message for etjobid={} jobid={} assetid={}'.format(
                        task.et_job_id, task.job.id, task.job.asset_id))
                self._send_message(
                    self._queue,
                    message_body=task.msg.body,
                    delay_seconds=60,
                    string_attrs=attrs)
                task.msg.delete()
                return
        except RuntimeError as e:
            self.log.error(
                "et_job_id: jobid={} was Canceled or Errored. Sending task.job.id "
                "jobid={} to error queue. Error: {}".format(task.et_job_id,
                                                            task.job.id, e))
            self.handle_error(task)
            return        # return value not consumed

    def _wait_for_et_job(self, task, et_job):
        """Setup a new message that waits for ET job to complete."""
        attrs = task.common_attrs
        attrs["et_job_id"] = et_job["Id"]
        # BUG etjobid=None -- task.et_job_id not saved until we _send_message?
        self.log.info('Sending message to wait for etjobid={} for jobid={}'.format(
            et_job['Id'], task.job.id))
        self._send_message(
            self._queue,
            message_body=json.dumps(et_job),
            delay_seconds=120,
            string_attrs=attrs)
        task.msg.delete()


def worker():  # pragma: no cover
    """Start up an instance of the UploadedWorker."""
    command = RunWorker(sys.argv, UploadedWorker)
    command.run()
