"""Configuration bits for avail_pipeline.

Copyright 2015 AVAIL Authors.  See AUTHORS.txt in the repo root.
"""
from configparser import ConfigParser


class RunnerConfigParser(ConfigParser):
    """Parse our config file and return the app settings as a dict."""

    def read(self, fname):
        """Read the given file, parse it and return the contents as a dict.

        :param str fname: The path to the config file.
        """
        super().read(fname)
        d = dict(self._sections)
        for k in d:
            d[k] = dict(self._defaults, **d[k])
            d[k].pop('__name__', None)
        return d["app:main"]


class RegistryShim:
    """RegistryShim acts like a registry for config purposes.

    We usually use ``pyramid`` to pass a registry in the configurator. We don't
    have a configurator here but want to reuse the get_*_from_settings methods
    to load up some connections. This shim provides a 'registry' like object
    that has a settings property.

    :type settings: dict
    :param settings: The settings read from an ini file.
    """

    def __init__(self, settings):
        """Class constructor."""
        self._settings = settings

    @property
    def settings(self):
        """Return the settings."""
        return self._settings
