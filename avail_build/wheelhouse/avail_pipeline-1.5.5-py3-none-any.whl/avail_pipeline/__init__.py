"""Copyright (c) 2015 AVAIL Authors. See AUTHORS.txt in the repo root."""
