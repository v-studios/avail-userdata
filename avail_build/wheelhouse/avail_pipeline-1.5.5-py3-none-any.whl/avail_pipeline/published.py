"""Index metadata for msgs in published q, then advance to the indexed q."""
# Copyright 2015 AVAIL Authors. See AUTHORS.txt in the root of the repo.

import sys

from botocore.client import ClientError

from zope.interface import implementer

from avail.aws import fs_from_settings
from avail.aws.cloudsearch import get_cloudsearch_from_settings
from avail.aws.dynamodb import (get_assetdb_table_from_settings as
                                assets_from_settings)
from avail.aws.s3 import (get_public_s3_artifact_key,
                          get_public_s3_artifact_prefix)
from avail.exception import (AVAILDatabaseConflictError, AVAILDatabaseWriteError,)
from avail.metadata import Metadata

from avail_pipeline.cli import RunWorker
from avail_pipeline.config import RegistryShim
from avail_pipeline.interfaces import IWorker
from avail_pipeline.pipeline import Worker


# An updated metadata file's job will come to this queue as 'Uploaded' (see
# API's metadata.py); an asset's job will come to this queue as 'Published'.
TARGET_STATES = ['Uploaded', 'Published', ]


@implementer(IWorker)
class PublishedWorker(Worker):
    """Index metadata for assets that have been published publicly.

    This also handles case where just the metadata has been updated.

    There is no nextq to send to: when we finish successfully, we're done.

    Inherited params: See :class:`avail_pipeline.pipeline.Worker`
    """

    def __init__(self, queue, errq, previousq, nextq,
                 get_assetdb_table_from_settings=assets_from_settings, *args,
                 **kw):
        """Class constructor."""
        super().__init__(queue, errq, previousq, nextq, *args, **kw)
        self._fs = fs_from_settings(RegistryShim(self._settings))
        self._cs = get_cloudsearch_from_settings(RegistryShim(self._settings))
        self._assets = get_assetdb_table_from_settings(RegistryShim(
            self._settings))

    def _fetch_metadata(self, key):
        _, fp = self._fs.get(key)
        return fp.read().decode("utf8")

    def _handle_updated_metadata(self, task):
        # Transition from uploaded to published.
        try:
            task.job.transition()
        except (AVAILDatabaseWriteError, ClientError, ):
            # If the job isn't transitioned, log & handle the error.
            error_msg = 'Error transitioning jobid={} to nextstate={}'.format(
                task.job.id, task.job.next_state)
            self.log.warn(error_msg)
            self.handle_error(task)
            return False
        asset_id = task.msg.message_attributes.get("asset_id", {}).get(
            "StringValue")
        key = task.msg.message_attributes.get("key", {}).get("StringValue")
        try:
            mdjson = self._fetch_metadata(key)
        except KeyError as e:
            self.log.critical(
                "Couldn't find an updated metadata file at key={} for assetid={}".format(
                    key, asset_id))
            try:
                task.job.error = True
            except (AVAILDatabaseWriteError, ClientError, ):
                error_msg = 'Error setting error=True for jobid={}.'.format(task.job.id)
                self.log.error(error_msg)
                # If the JobDB couldn't be updated then this error won't be handled correctly
                # downstream, so re-raise.
                raise RuntimeError(error_msg)
            task.msg.delete()
            raise e

        # TODO: failure in _cs.create() is handled differently for
        # _handle_update_metadata and _update_index. Shouldn't they both do the
        # same thing? Log error, return XOR raise, perhaps even set an error
        # and delete the task?

        try:
            nasa_id = self._cs.create(mdjson)
        except (ValueError, KeyError, RuntimeError) as e:
            try:
                task.job.error = True
            except (AVAILDatabaseWriteError, ClientError, ):
                error_msg = 'Error setting error=True for jobid={}.'.format(task.job.id)
                self.log.error(error_msg)
                # If the JobDB couldn't be updated then this error won't be handled correctly
                # downstream, so re-raise.
                raise RuntimeError(error_msg)
            task.msg.delete()
            raise e
        self.log.info("jobid={} updated_metadata event=index created for assetid={}".format(
            task.job.id, nasa_id))

        # Do not necessarily have a published asset.
        asset = self._assets.by_id(asset_id)
        if asset is not None:
            self.log.info("jobid={} Published new asset assetid={}".format(
                task.job.id, asset_id))
            asset.push_job(task.job_id)
        # Transition from published to indexed.
        try:
            task.job.transition()
        except (AVAILDatabaseWriteError, ClientError, ):
            # If the job isn't transitioned, log & handle the error.
            error_msg = 'Error transitioning jobid={} to nextstate={}'.format(
                task.job.id, task.job.next_state)
            self.log.warn(error_msg)
            self.handle_error(task)
            return False
        # Delete the queue message. There is no next queue to send to.
        task.msg.delete()

    def _update_index(self, task, mdjson):
        # Create the 'doc' in the search index
        try:
            nasa_id = self._cs.create(mdjson)
        except (ValueError, KeyError, RuntimeError) as e:
            self.log.critical("Error creating index for document {}:"
                              " {}".format(mdjson, e))
            self.handle_error(task)
            return False
        self.log.info("Created index for assetid={}".format(nasa_id))

    def handle(self, task, *args, **kw):
        """Handle incoming messages from the published queue.

        PublishedWorker handles tasks with SQS messages coming in from the
        published queue, sets asset.captions_path (for video), adds the
        associated published metadata.json to the search index. There is no
        next queue to send to, so we just remove hte msg when done.

        :param task: A container task composed of the job and SQS message.
        :type  task: `avail_pipeline.task.SegmentTask`

        """
        self.log.info("Handling sqsid={} sqstime={} sqscount={} "
                      "jobid={} in state={}".format(
                          task.msg.message_id,
                          task.msg.attributes['SentTimestamp'],
                          task.msg.attributes['ApproximateReceiveCount'],
                          task.job.id, task.job.state))
        if task.job.state not in TARGET_STATES:
            # Log warning that job which shouldn't be seen by this worker was
            # seen by this worker.
            self.log.warn('Want jobs in states={}, but got jobid={} in state={}.'.format(
                TARGET_STATES, task.job.id, task.job.state))
            # Delete associated queue message.
            self.log.debug('Deleting message msgid={}'.format(task.msg))
            task.msg.delete()
            return

        self.log.debug("Handling sqsid={} for jobid={}".format(
            task.msg.message_id, task.job.id))

        # If the Job is Indexed - or whatever its final state is - then
        # .next_state will be `None`. Do nothing.
        if task.job.next_state is None:
            self.log.info("task.job has reached its final state, deleting.")
            task.msg.delete()
            return
        try:
            if task.msg.message_attributes.get("is_updated_metadata") is not None:
                try:
                    self._handle_updated_metadata(task)
                    return
                except Exception as e:
                    self.log.critical(
                        "Unexpected exception handling updated metadata file: {}".format(e))
                    raise e

            # Get the metadata for the jobs asset
            md_key = get_public_s3_artifact_key(task.job.asset_path, "metadata.json")
            try:
                mdjson = self._fetch_metadata(md_key)
            except KeyError:
                self.log.critical(
                    "Couldn't find a metadata file at key={} for assetpath={}".format(
                        md_key, task.job.asset_path))
                self.handle_error(task)
                return

            # Add the asset info to the AssetDB.
            # Need: nasa_id, s3_prefix, and user_id.
            metadata = Metadata(mdjson)
            nasa_id = metadata.nasa_id
            prefix = get_public_s3_artifact_prefix(task.job.asset_path)

            self._update_assetdb(nasa_id, prefix, task)

            try:
                self._update_index(task, mdjson)
            except (ValueError, KeyError, RuntimeError):
                # already logged
                self.handle_error(task)
                return
            # Transition from published to indexed.
            try:
                task.job.transition()
            except (AVAILDatabaseWriteError, ClientError, ):
                # If the job isn't transitioned, log & handle the error.
                error_msg = 'Error transitioning jobid={} to nextstate={}'.format(
                    task.job.id, task.job.next_state)
                self.log.warn(error_msg)
                self.handle_error(task)
                return False
            # There is no next queue: delete msg since we've successfully reached the end
            task.msg.delete()
        except Exception as e:
            # catch any last errors so we don't exit.
            self.log.critical(
                "Unexpected error occurred trying to finalize "
                "publishing task for msgid={}, jobid={}: {}".format(
                    task.msg.message_id, task.job, e))

    def _update_assetdb(self, nasa_id, prefix, task):
        """Create an asset, set .captions_path if video has captions_path."""
        captions_path = None
        if task.job.captions_path:
            captions_path = get_public_s3_artifact_key(task.job.asset_path,
                                                       task.job.captions_path)
            self.log.debug('_update_assetdb captionspath={}'.format(captions_path))
            try:
                self._fs.get(captions_path)
            except KeyError as e:
                msg = '_update_assetdb jobid={} no file at captionspath={}: {}'.format(
                    task.job.id, captions_path, e)
                self.log.critical(msg)
                raise KeyError(msg)  # We're not cleaning up the mess
        try:
            asset = self._assets.new(nasa_id, prefix, task.job.owner)
        except AVAILDatabaseConflictError:
            # The asset already exists.
            asset = self._assets.by_id(nasa_id)
        if captions_path:
            asset.captions_path = captions_path
        asset.push_job(task.job_id)


def worker():  # pragma: no cover
    """Entrypoint: start up an instance of the PublishedWorker.

    Reads .ini file name as first arg from command line to get our
    bucket names.
    """
    command = RunWorker(sys.argv, PublishedWorker)
    command.run()
