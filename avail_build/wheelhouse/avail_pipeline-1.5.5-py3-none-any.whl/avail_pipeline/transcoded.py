#!/usr/bin/env python
"""Publish asset, artifacts and metadata that are in Transcoded queue."""
# Copyright 2015 AVAIL Authors. See AUTHORS.txt in the root of the repo.

import json
import os
import re
import sys
import time
from mimetypes import add_type, guess_type
from urllib.parse import urljoin

import boto3

from botocore.exceptions import ClientError

from zope.interface import implementer

from avail.asset import VIDEO_THUMB_SIZES
from avail.aws.s3 import (fs_from_settings, get_private_s3_artifact_prefix,
                          get_public_s3_artifact_key, tmpfs_from_settings, )
from avail.exception import AVAILDatabaseWriteError
from avail.metadata import Metadata

from avail_pipeline.cli import RunWorker
from avail_pipeline.config import RegistryShim
from avail_pipeline.interfaces import IWorker
from avail_pipeline.pipeline import Worker
from avail_pipeline.videothumb import publish_video_thumbs


SETTINGS_PRIVATE_BUCKET = "avail.aws.s3.tmp.bucket.name"
SETTINGS_PUBLIC_BUCKET = "avail.aws.s3.prod.bucket.name"
SETTINGS_REGION = "avail.aws.region"
SETTINGS_COLLECTION_ROOT = "avail.collection_root"
SETTINGS_METADATA_WAIT_TIME = "avail.metadata_wait_time"
# An asset's job will get sent to this queue as 'Transcoded'.
TARGET_STATES = ['Transcoded', ]


@implementer(IWorker)
class TranscodedWorker(Worker):
    """Publish assets that are Transcoded from Private to Public bucket.

    * Consume messages from the TranscodedQueue.
    * Reset message visibility when message read. TODO: ??? to what? why?
    * Invoke Hander to:
      + Log warning and retry later if no metadata.json file exists in the asset's S3
        directory; TODO: what do we do, let the message reappear later
        and hope we see the client upload the metadata later?
      + Log warning and retry later if asset is video and no srt/vtt file exists.
      + Copy original asset and the "/OUT" subdirectory artifacts from the s3
        private bucket to the asset's directory in the public bucket, sans
        job_id prefix and /OUT/ infix. Do not copy any top-level, uploaded but
        not processed metadata.json file. Make sure content-type is set properly:
        original media, resized and captions.
      + Create collection.json itemizing all assets and metadata files for
        public consumption.
      + Upon successful finish: delete the source hierarchy rooted on the
        job_id; insert SQS message into the next queue (PublishedQueue).
    * Provide an entrypoint for supervisord.

    Inherited params:
    :param str queue: Name of the queue this manager listens on.
    :param str errq: Name of the error queue in this  pipeline.
    :param str previousq: Name of the prior queue in the pipeline.
    :param str nextq: Name of the next queue in the pipeline.
    :type  logger: logging.Logger
    :param logger: A logger to log with.
    :param int poll_interval: Interval to poll the queue (seconds).
    :param int max_poll_interval: Longest poll interval to backoff to (secs)
    :param int backoff_poll_interval: Seconds added ``poll_interval`` if
                                      queue was empty.
    :param int visibility_timeout: Invisibility period of recieved message.
    :param int wait_time_seconds: period to wait for new messages after
                                  connecting to SQS.
    :type  handler: callable
    :param handler: A callable which uses the information in a SegmentTask to
        process an Asset. If successful: transitions the SegmentTask's Job to
        its next state, updates that Job in the JobDB, in some cases posts a
        new message to the next SQS queue using the Job's state list, and
        finally deletes the SegmentTasks's associated SQS message. (In some
        workflow states, the step of posting a new message to the next SQS
        queue is handled implicitly by an AWS service, e.g., S3.) If
        unsuccessful: marks this Job as having an error, updates the Job in the
        JobDB, posts a new message to the SQS ErrorQueue or IncompleteQueue
        (depending on the details of processing), and finally deletes the
        SegmentTasks's associated SQS message.
    :param dict settings: A map of 'settings' for the ``Worker``.
    :param bool verbose: If more output should be logged.
    :type get_jobdb_table_from_settings: Mock or func
    :param get_jobdb_table_from_settings: A place to pass in a mock for
                                          testing.
    :type  get_named_queue_from_settings: Mock or func
    :param get_named_queue_from_settings: A place to pass in a mock for
                                          testing.

    """

    def __init__(self, queue, errq, previousq, nextq, fs_from_settings=fs_from_settings,
                 tmpfs_from_settings=tmpfs_from_settings, *args, **kw):
        """Class constructor."""
        super().__init__(queue, errq, previousq, nextq, *args, **kw)
        self._settings = kw.get("settings")
        self._max_artifacts_expected = int(
            self._settings.get("max_artifacts_expected", 10))
        self._fs = fs_from_settings(RegistryShim(self._settings))
        self._tmpfs = tmpfs_from_settings(RegistryShim(self._settings))
        # We don't have access to list by prefix or copy between buckets on the
        # Tmpfs/Fs abstractions, so use native boto3 calls.
        self._fs_name = self._fs.bucket.name
        self._tmpfs_name = self._tmpfs.bucket.name
        self._collection_root = self._settings[SETTINGS_COLLECTION_ROOT]
        self._metadata_wait_time = int(
            self._settings[SETTINGS_METADATA_WAIT_TIME])
        if not guess_type('foo.vtt')[0]:  # python-3.4.3 doesn't know .vtt
            add_type('text/vtt', '.vtt')
        # Create an S3 client that's consistent to avoid read-after-list failures that
        # occasionally happen w/ long videos, i.e., large lists of objects.
        self.s3_client = boto3.client('s3', region_name='s3-external-1')

    def handle(self, task, *args, **kw):
        """Handle incoming messages from the Transcoded queue.

        From the task, get .job_id and .asset_path of the original. From that
        we use helpers to find "artifacts", generated media and metadata (in
        the /OUT/ subdirectory). Copy the original asset and the artifacts to
        the Public bucket, flattening the hierarchy in the destination.

        Create a collection.json in the Public bucket that identifies
        all the assets and metadata files.

        If we don't find a metadata.json in the *Public* $asstype/$assid/
        directory we have to bail for now: set the 'incomplete' flag and
        generate a new copy of the message in the queue, setting it invisible
        for a while so we'll see it later. This will eventually time out of the
        queue if nobody every provides metadata.json, and end up in the
        deadletter queue.

        For video assets, we also require a captions srt/vtt file in the
        private s3 /OUT/ directory. If we don't have it, set 'incomplete' and
        reinject the message as we do for missing metadata.

        Example, from Private bucket:

          job_id/image/assetid/assetid~orig.tiff
                              /OUT/assetid~large.jpg
                                  /assetid~medium.jpg
                                  /assetid~small.jpg
                                  /assetid~thumb.jpg

                                  /assetid.{srt,vtt}
        to Public bucket:

          image/assetid/assetid~large.jpg
                       /assetid~medium.jpg
                       /assetid~orig.tiff
                       /assetid~small.jpg
                       /assetid~thumb.jpg
                       /collection.json
                       /metadata.json

        For videos, add a OUT/assetid.{srt,vtt} -> .../assetid.{srt,vtt}
        to the above files.

        We'll have to add the metadata.json file in the public bucket to the
        collection, since it no longer ever hits the private bucket.

        :param task: A container task composed of the job and SQS message.
        :type  task: `avail_pipeline.task.SegmentTask`

        """
        job = task.job
        sqsid = task.msg.message_id
        sqstime = task.msg.attributes['SentTimestamp']                  # str, not int
        sqscount = int(task.msg.attributes['ApproximateReceiveCount'])  # str, not int
        msg = ('Handling jobid={} assetid={} state={}'
               ' sqsid={} sqstime={} sqscount={}').format(
                   job.id, job.asset_id, job.state,
                   sqsid, sqstime, sqscount)
        if sqscount > 1:
            self.log.warning('Seen already: {}'.format(msg))
        else:
            self.log.info(msg)

        if job.state not in TARGET_STATES:
            # Log warning that job which shouldn't be seen by this worker was
            # seen by this worker.
            self.log.warn('Want jobs in states={}, but got jobid={} in state={}'.format(
                TARGET_STATES, job.id, job.state))
            # Delete associated queue message.
            self.log.debug('Deleting msgid={}'.format(task.msg))
            task.msg.delete()
            return

        # Get a list of the original and artifacts from private S3, sanity check
        asset_path = job.asset_path
        artifact_prefix = get_private_s3_artifact_prefix(job.id, asset_path)
        objs = self.s3_client.list_objects(Bucket=self._tmpfs_name, Prefix=artifact_prefix)
        if "Contents" not in objs:
            self.log.error('No private artifacts found for assetid={} jobid={}'.format(
                job.asset_id, job.id))
            self.handle_error(task)
            return
        private_artifacts = [obj["Key"] for obj in objs["Contents"]]
        # Filter many video thumbnails, named like: foo~preview_thumb_00002.png
        non_thumb_arts = [a for a in private_artifacts if not re.search("_thumb_\d+.png$", a)]
        if len(non_thumb_arts) > self._max_artifacts_expected:
            self.log.critical(
                'Too many private artifacts ({}>{}) for assetid={} jobid={}'.format(
                    len(non_thumb_arts), self._max_artifacts_expected, job.asset_id, job.id))
            self.handle_error(task)
            return
        # If there are no private artifacts, mark this job as errored.
        # (Since metadata update jobs will never enter a 'Transcoded' state,
        # only asset upload jobs will get this far. Therefore, there should
        # always be at least one artifact in the private S3 bucket.)
        if not private_artifacts:
            self.log.critical('Found no private artifacts for assetid={} jobid={}'.format(
                job.asset_id, job.id))
            self.handle_error(task)
            return False
        self.log.debug("Found {} non-thumb artifact keys for jobid={}".format(
            len(non_thumb_arts), job.id))

        # Start collection in case this is a video job.
        collection = []
        # Publish video thumbs to the public bucket before caption and metadata checks. This
        # will give users the option of selecting a non-default thumb before the video
        # publishes.
        if job.media_type == 'video' and job.thumb_paths is None:
            dst_s3_prefix = urljoin('video/', job.asset_id)
            try:
                thumb_public_s3_keys = publish_video_thumbs(
                    log=self.log,
                    asset_id=job.asset_id,
                    src_s3_name=self._tmpfs_name,
                    src_s3_key=job.asset_path,
                    dst_s3_name=self._fs_name,
                    dst_s3_prefix=dst_s3_prefix
                )
            except FileNotFoundError as err:
                self.log.error('Could not create video thumb, marking errored'
                               ' jobid=%s assetid=%s: %s' % (job.id, job.asset_id, err))
                self.handle_error(task)
                return
            # Build the thumbPaths dict, which stores the S3 prefix and the S3 keynames
            # separately (for space savings).
            thumb_paths = {'prefix': dst_s3_prefix}
            # Remove path info from each S3 key, e.g., 'video/nasa_id/nasa_id~small_1.jpg'.
            thumb_fnames = [os.path.basename(key) for key in thumb_public_s3_keys]
            self.log.debug('jobid={} video thumb fnames={}'.format(job.id, thumb_fnames))
            # Add an sname-keyed list of thumbs for each possible size.
            for sname in VIDEO_THUMB_SIZES.keys():
                thumb_paths[sname] = [fname for fname in thumb_fnames if sname in fname]
            # Drop empty sizes.
            thumb_paths = {k: v for k, v in thumb_paths.items() if v}
            self.log.debug('jobid={} thumbpaths={} before JobDB'.format(job.id, thumb_paths))
            # Set the thumbPaths attr in the JobDB.
            job.thumb_paths = thumb_paths
            self.log.info('jobid={} wrote thumbpaths={} to JobDB'.format(
                job.id, job.thumb_paths))

        # Check for metadata in the public bucket.
        metadata_key = job.metadata_path
        try:
            self._fs.head(metadata_key)
        except KeyError:
            self.log.warn('No metadata file found for assetid={} jobid={}'
                          ' sqsid={} sqstime={} sqscount={}'.format(
                              job.asset_path, job.id,
                              sqsid, sqstime, sqscount))
            self._handle_missing_metadata(task)
            return
        # Since we now accept potentially-invalid metadata, also need to add a
        # validation check here; nothing should get published w/ invalid
        # metadata!
        _, fp = self._fs.get(metadata_key)
        mdjson = fp.read().decode("utf8")
        metadata = Metadata(mdjson)
        try:
            metadata.validate_required_fields()
        except ValueError as e:
            self.log.warn('Got invalid metadata for assetid={} jobid={} '
                          ' sqsid={} sqstime={} sqscount={}'
                          ':\n{}'.format(
                              job.asset_id, job.id,
                              sqsid, sqstime, sqscount,
                              e))
            if not job.incomplete:
                try:
                    job.incomplete = True
                except (AVAILDatabaseWriteError, ClientError, ):
                    # If the job isn't set incomplete this time it should come through and try
                    # to get set incomplete again, so don't re-raise and die; just log.
                    error_msg = 'Error setting incomplete=True for assetid={} jobid={}'.format(
                        job.asset_id, job.id)
                    self.log.warn(error_msg)
            # Bail, now. This asset can't keep being processed.
            self.log.info('Job.incomplete=True for assetid={} jobid={}'
                          ' sqsid={} sqstime={} sqscount={}'.format(
                              job.asset_id, job.id,
                              sqsid, sqstime, sqscount))
            return

        # If media is video and we're missing srt/vtt captions,
        # it's incomplete and we wait on it.
        if job.media_type == 'video':
            if not job.captions_path or job.captions_path not in private_artifacts:
                self.log.warning('No captionspath={} for jobid={} assetid={}'
                                 ' sqsid={} sqstime={} sqscount={}'
                                 ' private_artifacts={}'.format(
                                     job.captions_path, job.id, job.asset_id,
                                     sqsid, sqstime, sqscount,
                                     private_artifacts))
                self._handle_missing_captions(task)
                return

        # If the job had previously been waiting on metadata or captions
        # and was marked as incomplete, then mark it as no-longer-incomplete.
        if job.incomplete:
            try:
                job.incomplete = False
            except (AVAILDatabaseWriteError, ClientError, ):
                # If the job isn't set not-incomplete this time it should come through and try
                # to get set not-incomplete again, so return and let this queue message get
                # pulled again.
                error_msg = 'Error setting incomplete=False for jobid={}.'.format(job.id)
                self.log.warn(error_msg)
                return
            self.log.info('Job.incomplete=False for assetid={} jobid={}'
                          ' sqsid={} sqstime={} sqscount={}'.format(
                              job.asset_id, job.id,
                              sqsid, sqstime, sqscount))

        self.log.debug('jobid={} assetid={}'
                       ' sqsid={} sqstime={} sqscount={}'
                       ' prefix={} #private_artifacts={} nonthumbartifacts={}'.format(
                           job.id, job.asset_id,
                           sqsid, sqstime, sqscount,
                           artifact_prefix, len(private_artifacts), non_thumb_arts))

        # Copy ~orig asset, private_artifacts, captions to Public; make collection.
        # Collection URLs need S3 bucket root to get an absolute URL.
        # We'll use guess_type() since requesting orig takes more time.

        # This can take maybe 5-10 minutes for a big video, it's transcodes and thumbs
        # so set a 10m invisibility to prevent other processes also trying to handle it.
        sent_ts = int(task.msg.attributes['SentTimestamp']) / 1000
        seconds_left = int(10 * 60 - (time.time() - sent_ts))  # 10m < 12h max
        self.log.debug('Setting sqsid={} visibilitytimeout={}'.format(
            sqsid, seconds_left))
        task.msg.change_visibility(VisibilityTimeout=seconds_left)

        sources = [asset_path] + non_thumb_arts  # exclude ET-generated PNG thumbs
        self.log.info('Publishing assetid={} jobid={}'
                      ' sqsid={} sqstime={} sqscount={}'
                      ' sources={}'.format(
                          job.asset_id, job.id,
                          sqsid, sqstime, sqscount,
                          sources))
        for src in sources:
            content_type, _encoding = guess_type(src)
            if not content_type:
                content_type = 'application/octet-stream'
                self.log.warning('Could not get content_type for src assetpath={} assetid={}'
                                 ' jobid={}'.format(src, job.asset_id, job.id))
            dst = get_public_s3_artifact_key(asset_path, src)
            url = os.path.join(self._collection_root, dst)
            collection.append(url)
            self.log.debug("Publish src={} to dst={}".format(src, dst))
            # Use Boto3-1.4.0's "managed transfer" for single or multipart copy
            # We MUST spec MetadataDirective=REPLACE to set CacheControl and ContentType,
            # else they're silently ignored.
            # Unbelievably, there is no return value!
            # Note: despite vague suggestions to the contrary in the boto3 docs, this is
            # synchronous code in the Python SDK.
            try:
                self.s3_client.copy(
                    CopySource={'Bucket': self._tmpfs_name, 'Key': src},
                    Bucket=self._fs_name,
                    Key=dst,
                    ExtraArgs={'ACL': 'public-read',
                               'CacheControl': 'public, max-age=300, s-max-age=600',
                               'ContentType': content_type,
                               'MetadataDirective': 'REPLACE'})
            except ClientError as e:
                # We may have a race condition where another TranscodedWorker has already
                # copied and removed the source files; try to recover gracefully.
                # Get current Job status: if changed (published?), don't process, exit clean
                jobnow = self._jobs.by_id(job.id)
                if jobnow.state != job.state:  # if state changed by other process, we stop
                    self.log.warning('Job changed state externally, delete our msg:'
                                     ' jobid={} assetid={} state={} statenow={}'
                                     ' sqsid={} sqstime={} sqscount={}'.format(
                                         job.id, job.asset_id, job.state, jobnow.state,
                                         sqsid, sqstime, sqscount))
                    task.msg.delete()
                    return
                # If we haven't already seen it too many times, try when visible again.
                # We set our invisibility to 10m above, so this gives us max 100m = 1h40m.
                if sqscount <= 10:  # arbitrary count of what's too many
                    self.log.warning('Try when visible again to see if published'
                                     ' jobid={} assetid={} state={}'
                                     ' sqsid={} sqstime={} sqscount={}'.format(
                                         job.id, job.asset_id, job.state,
                                         sqsid, sqstime, sqscount))
                    return
                # Else we've tried too many times, treat as error and expunge job
                self.log.critical('Copying src={} to dst={} for assetid={} jobid={} state={}'
                                  ' sqsid={} sqstime={} sqscount={}'
                                  ':\n{}').format(
                                      src, dst, job.asset_id, job.id, job.state,
                                      sqsid, sqstime, sqscount,
                                      e)
                self.handle_error(task)
                return

        self.log.info('Published jobid={} for assetid={}'
                      ' sqsid={} sqstime={} sqscount={}'.format(
                          job.id, job.asset_id,
                          sqsid, sqstime, sqscount))

        # Add already-public artifacts to collection because they weren't copied.
        collection.append(os.path.join(self._collection_root, metadata_key))
        # If this is a video, add thumb URLs to collection now (since not all jobs will publish
        # a collection in the same pass they generate their thumbs).
        if job.media_type == 'video':
            keys_flat = []
            for sname in VIDEO_THUMB_SIZES.keys():
                # Use .get and default to [] to skip empty sizes.
                keys_flat.extend(job.thumb_paths.get(sname, []))
            prefix = job.thumb_paths['prefix']
            thumb_public_s3_keys = [os.path.join(prefix, k) for k in keys_flat]
            collection.extend(
                [os.path.join(self._collection_root, key) for key in thumb_public_s3_keys])
            self.log.info('jobid={} added thumbpaths={} to collection={}'.format(
                job.id, job.thumb_paths, collection))

        # JSONify & publish collection.json.
        collection_json = json.dumps(collection)
        dst = get_public_s3_artifact_key(asset_path, "collection.json")
        self._fs.bucket.meta.client.put_object(
            Bucket=self._fs_name,
            Key=dst,
            Body=collection_json,
            ACL='public-read',
            ContentType='application/json',
            CacheControl='public, max-age=300, s-maxage=600',
        )
        # Remove Private job.id/*; always returns HTTP 204 so we can't be sure.
        # We have to ask S3 for everything matching the jobid and this implies
        # we are omniscient about the S3 path naming convention :-(

        objs = self.s3_client.list_objects(Bucket=self._tmpfs_name, Prefix=job.id)
        keys = [obj["Key"] for obj in objs.get("Contents", [])]
        self.log.debug("Deleting {} keys for jobid={}".format(len(objs), job.id))
        for n, key in enumerate(keys, 1):
            self.log.debug("Deleting {} key={}".format(n, key))
            self._tmpfs.delete(key)
        self.log.info('Deleted sources from priv S3 for assetid={} jobid={}'.format(
            job.asset_id, job.id))

        # Move the msg to the nextq, and do a job.transition().

        # Send a message to the PublishedQueue. Set it to delay 5 seconds to avoid race
        # conditions where a PublishedWorker picks up the message before its state is updated to
        # Published. Delete it from this queue once it's sent so nobody sees it again.
        self._send_message(self._nextq, string_attrs=task.common_attrs, delay_seconds=5)
        task.msg.delete()
        self.log.info('Sent msg to nextq, deleted from thisq assetid={} jobid={}'.format(
            job.asset_id, job.id))
        # Transition the job. Handle JobDB update even if capacity has been exhausted.
        try:
            job.transition()
        except (AVAILDatabaseWriteError, ClientError, ):
            # If the job isn't transitioned, log & handle the error.
            error_msg = 'Error transitioning jobid={} to nextstate={} for assetid={}'.format(
                job.id, job.next_state, job.asset_id)
            self.log.warn(error_msg)
            self.handle_error(task)
        # Jobs should never show up as Published unless one of these statements shows up in the
        # logs.
        self.log.info('Job transitioned to state={} for assetid={} jobid={}'.format(
            job.state, job.asset_id, job.id))

    def _handle_missing_metadata(self, task):
        """Wait for metadata with a new task msg.

        To give clients time to upload metadata, don't immediately
        mark a job incomplete. Instead, if it doesn't have metadata
        the first time it's seen by a TranscodedWorker, then that
        TranscodedWorker should:
        - make a duplicate message (with same values as the original msg)
        - add some boolean attribute to the new message which a
          TranscodedWorker can use to answer the question: "Has the message
          I'm looking at already be re-created once to allow the user time to
          upload metadata for it?"
        - wait for a while (10 minutes seems like a good start; do this
          using the delay_seconds parameter in our code, not by trying to
          directly modify message visibility)
        - send the modified message to the TranscodedQueue
        - delete the original message from the TranscodedQueue
        This message duplication techinque is similar to the way an
        UploadedWorker waits for ElasticTranscoder jobs finish.

        :param task: a `pipeline.Task`.
        """
        # The first time, don't mark the job as incomplete - do the stuff the
        # docstring says.
        if not task.waiting_for_metadata:
            # Copy the original message.
            attrs = task.common_attrs
            # Add our bool.
            attrs["waiting_for_metadata"] = "true"
            newmsg = self._send_message(
                self._queue,
                delay_seconds=self._metadata_wait_time,
                string_attrs=attrs, )
            task.msg.delete()
            self.log.info('Sent new msgid={} to wait for metadata assetid={} jobid={}'.format(
                newmsg, task.job.asset_id, task.job.id))
            return True
        # Since task.waiting_for_metadata is truthy, we've seen this Job before.
        # Mark it incomplete, if it's not already. (Don't gratuitously mark
        # incomplete because (a) that causes database writes, and (b) no reason
        # to do it.)
        if (task.waiting_for_metadata) and (not task.job.incomplete):
            try:
                task.job.incomplete = True
            except (AVAILDatabaseWriteError, ClientError, ):
                # If the job isn't set not-incomplete this time it should come through and try
                # to get set not-incomplete again, so log and don't raise.
                error_msg = 'Error setting incomplete=True for jobid={} assetid={}'.format(
                    task.job.id, task.job.asset_id)
                self.log.warn(error_msg)
                return False
            return True

    def _handle_missing_captions(self, task):
        """Mark asset incomplete, wait on arrival of captions file.

        Like _handle_missing_metadata, we set a flag and reinject the message so it
        appears later.  I don't know why we don't just return and let the message
        reappear and try later when it does, instead of this added complexity.
        That's what AWS queue visibility is designed for!

        Note: we're recycling the avail.metadata_wait_time -- I see no reason to
        add additional knobs for this, we have no idea for a better value.
        """
        if not task.waiting_for_captions:
            attrs = task.common_attrs
            attrs["waiting_for_captions"] = "true"
            newmsg = self._send_message(
                self._queue,
                delay_seconds=self._metadata_wait_time,  # reuse same timer
                string_attrs=attrs)
            task.msg.delete()
            self.log.info('Sent new msgid={} to wait for captions assetid={} jobid={}'.format(
                newmsg, task.job.asset_id, task.job.id))
            return True
        if not task.job.incomplete:
            try:
                task.job.incomplete = True
            except (AVAILDatabaseWriteError, ClientError, ):
                # If the job isn't set not-incomplete this time it should come through and try
                # to get set not-incomplete again, so log and don't raise.
                error_msg = 'Error setting incomplete=True for jobid={} assetid={}'.format(
                    task.job.id, task.job.asset_id)
                self.log.warn(error_msg)
                return False
            return True


def worker():  # pragma: no cover
    """Entrypoint: start up an instance of the UploadedWorker.

    Reads .ini file name as first arg from command line to get our
    bucket names.
    """
    command = RunWorker(sys.argv, TranscodedWorker)
    command.run()


if __name__ == "__main__":
    worker()
