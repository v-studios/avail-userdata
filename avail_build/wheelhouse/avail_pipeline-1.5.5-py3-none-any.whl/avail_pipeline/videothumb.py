"""Create one or more JPEG thumbnails from a video."""
# Copyright 2018 AVAIL Authors.  See AUTHORS.txt in the repo root.

import json
import logging
import os
import subprocess
from time import time

import boto3

from botocore.exceptions import ClientError

from avail.asset import (VIDEO_PERCENTS, VIDEO_THUMB_SIZES, make_video_thumb_fname, )


FFPROBE = ('ffprobe -v quiet -print_format json -show_streams -select_streams v:0'
           ' -show_entries stream=width,height,duration')
SAMPLE_VIDEO_URL = 'https://s3.amazonaws.com/cshenton-in/PUMAS.mp4'


def _run(cmd_list):
    """Run the command and return stdout.

    :param list cmd_list: list of str for components of command
    :returns: string output of the command
    """
    # Let it raise exceptions to our caller; most likely couldn't find the URL
    ret = subprocess.check_output(cmd_list, stderr=subprocess.STDOUT)
    return ret.decode('utf8')


class VideoThumb:
    """Get video stream duration and size, keep URL for conversions."""

    def __init__(self, url, log=None, loglevel=logging.INFO):
        """Get the dimensions of the video, save in the object.

        :param str url: URL (e.g., S3 key) or local file path for video
        :param log: optional instantiated and configured logger with its own namespace
        """
        self.log = log
        if self.log is None:
            self.log = logging.getLogger('.'.join((__name__, self.__class__.__name__)))
            self.log.addHandler(logging.StreamHandler())
            self.log.setLevel(loglevel)
        ffprobe_cmd = FFPROBE.split()  # don't split the URL, may have embedded spaces
        ffprobe_cmd.append(url)
        try:
            out_json = _run(ffprobe_cmd)
        except subprocess.CalledProcessError as err:
            raise RuntimeError('Could not ffprobe url=%s err=%s' % (url, err))
        out = json.loads(out_json)
        stream = out['streams'][0]
        self.width = int(float(stream['width']))
        self.height = int(float(stream['height']))
        self.seconds = float(stream['duration'])
        self.url = url

    def frame_grab(self, seconds, outpath, width=None, height=None):
        """Output JPEG frame at seconds timepoint to outpath, optionally scaled to width * height.

        Note that ffmpeg will silently fail if it can't create an output from a
        truncated file; we can see this if we use "-v warning" but success code
        0 is still returned. Caller should check existence of output to ensure
        proper execution.

        :param int seconds: number of seconds into the video to grab
        :param str outpath: local disk location to output the JPEG
        :param int width: optional width to scale the image
        :param int height: optional height to scale the image

        """
        if seconds > self.seconds:
            raise RuntimeError('Requested seconds=%s > video duration seconds=%s' % (
                seconds, self.seconds))
        if height and height > self.height:
            raise RuntimeError('Requested height=%s > video height=%s' % (height, self.height))
        if width and width > self.width:
            raise RuntimeError('Requested width=%s > video width=%s' % (width, self.width))
        # Construct the command, only adding the optional scaling "-s WxH" if needed
        # ffmpeg -v quiet -y -ss 3.1416 -i $URL -vframes 1 -s 640x480 thumb.jpg
        ffmpeg_cmd = ['ffmpeg', '-v', 'quiet', '-y', '-ss', str(seconds),
                      '-i', self.url, '-vframes', '1']
        if width or height:
            if width is None:
                width = self.width
            if height is None:
                height = self.height
            ffmpeg_cmd.extend(['-s', '%sx%s' % (width, height)])
        ffmpeg_cmd.append(outpath)
        t_0 = time()
        try:
            _run(ffmpeg_cmd)
        except subprocess.CalledProcessError as err:
            raise RuntimeError('Could not ffmpeg err=%s' % err)
        self.log.debug('url=%s frame_grab_seconds=%s', self.url, time() - t_0)

    def make_thumbs(self, asset_id='ASSETID'):
        """Make frames at all timepoints and sizes, at /tmp/assetid~size_num.jpg.

        :raises: FileNotFoundError if ffmpeg didn't create an output
        :returns: list of str paths created
        """
        paths = []
        t_0 = time()
        for sname, size in VIDEO_THUMB_SIZES.items():
            if max(self.width, self.height) < size:
                self.log.info('Skip enlarge sizename=%s size=%s videowidth=%s videoheight=%s',
                              sname, size, self.width, self.height)
                continue
            scale = size / max(self.width, self.height)
            width = int(scale * self.width)
            height = int(scale * self.height)
            for timeid, percent in enumerate(VIDEO_PERCENTS, 1):
                seconds = percent * self.seconds / 100
                out = '/tmp/%s' % (make_video_thumb_fname(asset_id, sname, timeid))
                self.frame_grab(seconds, out, width=width, height=height)
                # Ensure ffmpeg created the output, not just failed silently
                if not os.path.isfile(out):
                    raise FileNotFoundError('ffmpeg did not create output=%s for seconds=%s'
                                            ' width=%s height=%s' % (
                                                out, seconds, width, height))
                paths.append(out)
        self.log.debug('url=%s frames=%s total_frame_grab_seconds=%s',
                       self.url, len(paths), time() - t_0)
        return paths


def publish_video_thumbs(log, asset_id,
                         src_s3_name, src_s3_key, dst_s3_name, dst_s3_prefix):
    """Create and publish to S3 thumbnails at multiple timepoints, sizes.

    From the original video, create thumbnails at multiple timepoints and
    multiple device screensizes; save them to public bucket and add them to
    collection.json; remove them from the filesystem to avoid clutter.  We
    use a presigned URL so ffmpeg can read directly from S3 and avoid a
    copy to this server; it's plenty fast, about 3s/thumb for a 1h11m
    video.

    :param log: preconfigured logger from client
    :param str asset_id: id of the asset, e.g., nasa123
    :param str src_s3_name: name of the s3 bucket the original video lives in
    :param str src_s3_key: key to the original video file
    :param str dst_s3_name: name of the s3 bucket to write the thumb images
    :param str dst_s3_prefix: key prefix to which to append thumb names, e.g., video/nasa123
    :returns: list of keys created in dst_s3_name bucket
    """
    s3c = boto3.client('s3')
    try:
        s3c.head_object(Bucket=src_s3_name, Key=src_s3_key)
    except ClientError:
        raise RuntimeError('Video not found in s3bucket=%s key=%s' % (src_s3_name, src_s3_key))
    ps_url = s3c.generate_presigned_url(ClientMethod='get_object',
                                        ExpiresIn=7200,
                                        Params={'Bucket': src_s3_name, 'Key': src_s3_key})
    log.debug('src ps_url=%s', ps_url)
    videothumb = VideoThumb(ps_url, log)
    keys = []
    paths = videothumb.make_thumbs(asset_id)
    for path in paths:
        dst = os.path.join(dst_s3_prefix, os.path.basename(path))
        log.debug('copy video thumb regular dst=%s', dst)
        s3c.upload_file(
            Filename=path, Bucket=dst_s3_name, Key=dst,
            ExtraArgs={'ACL': 'public-read',
                       'ContentType': 'image/jpeg',
                       'CacheControl': 'public, max-age=300, s-maxage=600'})
        keys.append(dst)
        # Copy the middle timepoint to a numberless thumb for default ~SIZE.jpg
        if dst.endswith('_3.jpg'):  # _3 is the 10% timepoint, our current default
            dst = dst[:-len('_3.jpg')] + '.jpg'  # remove _3 for default name
            log.debug('copy video thumb default dst=%s', dst)
            s3c.upload_file(
                Filename=path, Bucket=dst_s3_name, Key=dst,
                ExtraArgs={'ACL': 'public-read',
                           'ContentType': 'image/jpeg',
                           'CacheControl': 'public, max-age=300, s-maxage=600'})
            keys.append(dst)
        os.remove(path)
    log.info('Published thumbs to s3bucket=%s prefix=%s', dst_s3_name, dst_s3_prefix)
    return keys
