"""AVAIL pipeline CLI bits.

Copyright (c) 2015 AVAIL Authors.  See AUTHORS.txt in the repo root.
"""

import os
import textwrap

from argparse import ArgumentParser

from configparser import ConfigParser
from logging.config import fileConfig

from .config import RunnerConfigParser
from .pipeline import Worker


def add_standard_args(parser=None):
    """Parse command line arguments for the pipeline manager."""
    if parser is None:
        parser = ArgumentParser(
            description="Start an AVAIL pipeline manager "
            "(AKA Queue Poller and Handler AKA Bossy Pants).")

    parser.add_argument("config_file",
                        metavar="CONFIG_FILE",
                        help="The configuration (.ini) file to use.",
                        type=str)

    parser.add_argument("--verbose", "-v",
                        action="store_true",
                        default=False,
                        help="Show more output.")

    return parser


class RunWorker:
    """Run the given worker {}.

    This command takes an .ini file, loads, and runs the given worker.

    :param class worker: A subclass of :class:`avail_pipeline.pipeline.Worker`
    :param list argv: A list of command line args -- such as provided by
        :mod:`sys.argv`
    """

    def __init__(self, argv, worker):
        """Class constructor."""
        self.parser = add_standard_args(ArgumentParser(
            description=textwrap.dedent(self.__doc__.format(worker.__name__))))
        self.args = self.parser.parse_args(argv[1:])

        if worker.__base__ == Worker:
            self._worker = worker
        else:
            raise SystemExit("Expected an instance of {}, but got {}".format(
                Worker, worker.__qualname__))

    def _setup_logging(self):
        parser = ConfigParser()
        parser.read([self.args.config_file])
        if parser.has_section("loggers"):
            config_file = os.path.abspath(self.args.config_file)
            return fileConfig(
                config_file, dict(__file__=self.args.config_file,
                                  here=os.path.dirname(self.args.config_file)))

    def run(self):
        """Run the worker."""
        self._setup_logging()
        settings = RunnerConfigParser().read(self.args.config_file)
        kw = {}
        for k in ("poll_interval", "max_poll_interval",
                  "backoff_poll_interval", "visibility_timeout",
                  "wait_time_seconds"):
            try:
                kw[k] = int(settings[k])
            except KeyError:
                # It isn't insettings so ignore it
                pass

        self.worker = self._worker(
            settings.get("avail_pipeline.queue_name"),
            settings.get("avail_pipeline.error_queue_name"),
            settings.get("avail_pipeline.previous_queue_name"),
            settings.get("avail_pipeline.next_queue_name"),
            settings=settings,
            verbose=self.args.verbose, **kw)

        self.worker.run()
