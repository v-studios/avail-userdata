#!/usr/bin/env python
"""Clean up after assets that have errored out."""
# Copyright 2015 AVAIL Authors. See AUTHORS.txt in the root of the repo.
import sys
from time import sleep

from botocore.client import ClientError

from zope.interface import implementer

from avail.aws import get_cloudsearch_from_settings
from avail.aws.s3 import (fs_from_settings, get_private_s3_artifact_prefix,
                          get_private_s3_artifact_root,
                          get_public_s3_artifact_prefix, tmpfs_from_settings, )

from avail_pipeline.cli import RunWorker
from avail_pipeline.config import RegistryShim
from avail_pipeline.interfaces import IWorker
from avail_pipeline.pipeline import Worker


SETTINGS_PRIVATE_BUCKET = "avail.aws.s3.tmp.bucket.name"
SETTINGS_PUBLIC_BUCKET = "avail.aws.s3.prod.bucket.name"
SETTINGS_REGION = "avail.aws.region"


@implementer(IWorker)
class ErrorWorker(Worker):
    """Remove artifacts left behind while errored out job was being processed.

    Also, delete any associated messages from queues.

    * Consume messages from the ErrorQueue.
    * Reset message visibility when message read.
    * Invoke Handler to:
      + Un-index this asset's results from CloudSearch.
      + Delete this asset from the public S3 bucket.
      + Delete this Job's keys from the private S3 bucket.
      + Upon successful finish: delete this message from the ErrorQueue.
    * Provide an entrypoint for supervisord.

    This must be done in an idempotent way: we should be able to tolerate a
    duplicate message to clean up this job.

    Inherited params:
    :param str queue: Name of the queue this manager listens on.
    :param str errq: Name of the error queue in this  pipeline.
    :param str previousq: Name of the prior queue in the pipeline.
    :param str nextq: Name of the next queue in the pipeline.
    :type  logger: logging.Logger
    :param logger: A logger to log with.
    :param int poll_interval: Interval to poll the queue (seconds).
    :param int max_poll_interval: Longest poll interval to backoff to (secs)
    :param int backoff_poll_interval: Seconds added ``poll_interval`` if
                                      queue was empty.
    :param int visibility_timeout: Invisibility period of recieved message.
    :param int wait_time_seconds: period to wait for new messages after
                                  connecting to SQS.
    :type  handler: callable
    :param handler: A callable which uses the information in a SegmentTask to
        process an Asset. If successful: transitions the SegmentTask's Job to
        its next state, updates that Job in the JobDB, in some cases posts a
        new message to the next SQS queue using the Job's state list, and
        finally deletes the SegmentTasks's associated SQS message. (In some
        workflow states, the step of posting a new message to the next SQS
        queue is handled implicitly by an AWS service, e.g., S3.) If
        unsuccessful: marks this Job as having an error, updates the Job in the
        JobDB, posts a new message to the SQS ErrorQueue or IncompleteQueue
        (depending on the details of processing), and finally deletes the
        SegmentTasks's associated SQS message.
    :param dict settings: A map of 'settings' for the ``Worker``.
    :param bool verbose: If more output should be logged.
    :type get_jobdb_table_from_settings: Mock or func
    :param get_jobdb_table_from_settings: A place to pass in a mock for
                                          testing.
    :type  get_named_queue_from_settings: Mock or func
    :param get_named_queue_from_settings: A place to pass in a mock for
                                          testing.
    :param get_cloudsearch_from_settings: a Mock or a func for testing.
    """

    def __init__(self, queue, *args, **kwargs):
        """Class constructor."""
        super().__init__(queue, *args, **kwargs)
        self._settings = kwargs.get("settings")
        self._fs = fs_from_settings(RegistryShim(self._settings))
        self._tmpfs = tmpfs_from_settings(RegistryShim(self._settings))
        self.cs = get_cloudsearch_from_settings(RegistryShim(self._settings))

    def _unindex_asset(self, job):
        """Remove this job's asset from CloudSearch.

        :param job: An `avail.job.Job`.
        """
        self.log.debug("Starting to un-index jobid={}.".format(job.id))
        asset_id = job.asset_id
        # CloudSearch diesn't return success/failure, just HTTP success
        try:
            self.cs.delete(asset_id)
        except ClientError as e:
            self.log.error('jobid={} cloudsearch delete error={}'.format(
                job.id, e))
            return
        self.log.debug('jobid={} unindexed assetid={} from CloudSearch '.format(
            job.id, asset_id))

    def _unpublish_asset(self, job):
        """Delete this Job's asset's artifacts from the public S3 bucket.

        Now that we block submission of a job for an existing asset, we should
        be able to safely assume that anything in the asset's public bucket is
        destroyable. (Before this check, one could submit a job for an asset
        that was already published, so removing published artifacts would have
        destroyed successfully published assets).

        :param job: An `avail.job.Job`.
        """
        self.log.debug("jobid={} Starting to un-publish.".format(job.id))
        # OMG this is identical to the ill-named JobDB 'fname' attribute:
        s3_prefix = get_public_s3_artifact_prefix(job.asset_path)
        self.log.debug('jobid={} Deleting artifacts from public S3 bucket prefix={}'.format(
            job.id, s3_prefix))
        try:
            self._fs.delete(None, prefix=s3_prefix)
        except ClientError as e:
            self.log.error('jobid={} delete s3_prefix={} error={}'.format(
                job.id, s3_prefix, e))
            return
        self.log.info('jobid={} Un-published public s3_prefix={}'.format(job.id, s3_prefix))

    def _untranscode_asset(self, job):
        """Delete this Job's asset's artifacts from the private S3 bucket.

        The s3_prefix here is just for the artifacts, not the entire job.
        That's done in _unupload_asset().
        """
        self.log.debug('jobid={} Starting to un-transcode'.format(job.id))
        s3_prefix = get_private_s3_artifact_prefix(job.id, job.asset_path)
        self.log.debug('jobid={} Deleting artifacts from private s3_prefix={}'.format(
            job.id, s3_prefix))
        try:
            self._tmpfs.delete(None, prefix=s3_prefix)
        except ClientError as e:
            self.log.error('jobid={} delete private s3_prefix={} error={}'.format(
                job.id, s3_prefix, e))
            return
        self.log.info('jobid={} Un-transcoded s3_prefix={}'.format(job.id, s3_prefix))

    def _unupload_asset(self, job):
        self.log.debug('jobid={} Starting to un-upload'.format(job.id))
        s3_root = get_private_s3_artifact_root(job.id, job.asset_path)
        self.log.debug('jobid={} Deleting artifacts from private s3_root={}'.format(
            job.id, s3_root))
        try:
            self._tmpfs.delete(None, prefix=s3_root)
        except ClientError as e:
            self.log.error('jobid={} delete private s3_prefix={} error={}'.format(
                job.id, s3_root, e))
            return
        self.log.info('jobid={} Un-uploaded s3_root={}'.format(job.id, s3_root))

    def handle(self, task, *args, **kw):
        """Handle incoming messages from the ErrorQueue.

        Clean up after a Job which has reached the ErrorQueue. Issue deletes in
        all the previous stages it could have gone through.

        After cleanup is done, delete message from the ErrorQueue.

        Even though the error has been cleaned up, leave the job marked as
        .error=True so that the dashboard doesn't show irrecoverable jobs. Once
        we delete the msg from the queue, it should not be seen by the
        ErroredWorker again. If it does, our helpers will tolerate the already
        cleaned up job bits.

        :param task: A container task composed of the job and SQS message.
        :type  task: `avail_pipeline.task.SegmentTask`
        """
        self.log.info("Handling sqsid={} sqstime={} sqscount={} "
                      "jobid={} in state={}".format(
                          task.msg.message_id,
                          task.msg.attributes['SentTimestamp'],
                          task.msg.attributes['ApproximateReceiveCount'],
                          task.job.id, task.job.state))

        job = task.job
        previous_states = task.job.previous_states
        self.log.debug("jobid={} previous states: `{}`.".format(job.id, previous_states))
        self.log.warning("Starting to clean up jobid={}".format(job.id))
        if "Indexed" in previous_states:
            self.log.info("jobid={} reached 'Indexed' state; un-indexing assetid={}.".format(
                job.id, job.asset_id))
            self._unindex_asset(job)
        if "Published" in previous_states:
            self.log.info("jobid={} reached 'Published' state; un-publishing.".format(job.id))
            self._unpublish_asset(job)
        if "Transcoded" in previous_states:
            self.log.info("jobid={} reached 'Transcoded' state; un-transcoding.".format(job.id))
            self._untranscode_asset(job)
        if "Uploaded" in previous_states:
            self.log.info("jobid={} reached 'Uploaded' state; un-uploading.".format(job.id))
            self._unupload_asset(job)
        self.log.debug("Deleting this message from its queue.")
        task.msg.delete()
        self.log.debug("Deleted message `{}`.".format(task.msg.message_id))
        self.log.info("Finished handling jobid={}".format(job.id))

    def handle_error(self, task, *args, **kwargs):
        """
        Raise RuntimeError.

        Overwrite parent class's .handle_error method, since ErrorWorker.handle
        is the thing that should handle errors!
        """
        error_msg = "This method should never be called by an ErrorWorker, nuking msg."
        task.msg.delete()
        self.log.critical('jobid={} task.job.error={}: {}'.format(
            task.job.id, task.job.error, error_msg))
        raise RuntimeError(error_msg)

    def run(self):  # pragma: no cover
        """
        Run this ErrorWorker continuously.

        Overwrite parent class's .run method because ErrorWorker should call
        .handle when error = True, and .handle_error...never.
        """
        while True:
            if self.poll_interval:
                sleep(self.poll_interval)
            segment_task = self.poll()
            if segment_task:
                # Any Job associated with a message in the ErrorQueue should
                # have its .error attr set to True.
                if segment_task.job.error:
                    self.handle(segment_task)
                # This should never happen; if it does, then .handle_error will
                # raise.
                else:
                    self.handle_error(segment_task)


def worker():  # pragma: no cover
    """Entrypoint: start up an instance of the ErrorWorker.

    Reads .ini file name as first arg from command line to get our
    bucket names.
    """
    command = RunWorker(sys.argv, ErrorWorker)
    command.run()


if __name__ == "__main__":
    worker()
