# Copyright 2015 AVAIL Authors.  See AUTHORS.txt in the repo root.
"""Base class for pipeline managers."""

import json
import logging
import os
from time import sleep

from botocore.client import ClientError

from zope.interface import implementer

from avail.aws import (get_cloudsearch_from_settings,
                       get_jobdb_table_from_settings,
                       get_named_queue_from_settings,)
from avail.exception import (AVAILDatabaseReadError, AVAILDatabaseWriteError,)

from avail_pipeline.config import RegistryShim
from avail_pipeline.interfaces import IWorker
from avail_pipeline.task import SegmentTask


@implementer(IWorker)
class Worker:
    """A ``Worker`` manages an ``AVAIL`` pipeline segment.

    :type queue: str
    :param queue: The name of the queue this manager listens on.
    :type errq: str
    :param errq: The name of the error queue in this  pipeline.
    :type previousq: str
    :param previousq: The name of the prior queue in the pipeline.
    :type nextq: str
    :param nextq: The name of the next queue in the pipeline
    :type logger: logging.Logger
    :param logger: A logger to log with.
    :type poll_interval: int
    :param poll_interval: The interval at which to poll our queue in seconds.
    :type max_poll_interval: int
    :param max_poll_interval: The longest poll interval we will backoff to in
        seconds.
    :type backoff_poll_interval: int
    :param backoff_poll_interval: The amount in seconds we add to our
        ``poll_interval`` if the queue was empty.
    :param int visibility_timeout: The invisibility period of a received
        message.
    :param int wait_time_seconds: The period to wait for new messages after
        connecting to SQS.
    :type handler: callable
    :param handler: A callable which uses the information in a SegmentTask to
        process an Asset. If successful: transitions the SegmentTask's Job to
        its next state, updates that Job in the JobDB, in some cases posts a
        new message to the next SQS queue using the Job's state list, and
        finally deletes the SegmentTasks's associated SQS message. (In some
        workflow states, the step of posting a new message to the next SQS
        queue is handled implicitly by an AWS service, e.g., S3.) If
        unsuccessful: marks this Job as having an error, updates the Job in the
        JobDB, posts a new message to the SQS ErrorQueue or IncompleteQueue
        (depending on the details of processing), and finally deletes the
        SegmentTasks's associated SQS message.
    :type settings: dict
    :param  settings: A map of 'settings' for the ``Worker``.
    :type verbose: bool
    :param verbose: If more output should be logged.
    :type get_jobdb_table_from_settings: Mock or func
    :param get_jobdb_table_from_settings: A place to pass in a mock for
        testing.
    :type get_named_queue_from_settings: Mock or func
    :param get_named_queue_from_settings: A place to pass in a mock for
        testing.
    :param get_cloudsearch_from_settings: a Mock or a func for testing.
    """

    def __init__(self, queue, errq, previousq, nextq,
                 logger=None,
                 poll_interval=0,
                 max_poll_interval=60,
                 backoff_poll_interval=5,
                 visibility_timeout=120,  # AVAIL SQS config default
                 # TODO: determine if we want this longer for production > 1.0
                 wait_time_seconds=0,  # service default
                 settings={},
                 verbose=False,
                 get_jobdb_table_from_settings=get_jobdb_table_from_settings,
                 get_named_queue_from_settings=get_named_queue_from_settings,
                 get_cloudsearch_from_settings=get_cloudsearch_from_settings,
                 **kwargs):
        """Class constructor."""
        # __name__ becomes just 'avail_pipeline.pipeline' in subclasses :-(
        # Append class name to make it like 'avail_pipeline.pipeline.UploadedWorker'.
        # Retain 'avail_pipeline' so log config's 'qualname' will match our modules.
        if logger is None:
            logger = logging.getLogger('.'.join((__name__, self.__class__.__name__)))
        else:
            assert isinstance(logger, logging.Logger), (
                "{} got a {} but wanted a `logging.Logger`".format(
                    self.__class__.__name__, type(logger))
            )
        self._logger = logger
        # Validate and setup integer named args.
        for interval in ("poll_interval", "max_poll_interval",
                         "backoff_poll_interval", "visibility_timeout",
                         "wait_time_seconds"):
            assert isinstance(locals()[interval], int), (
                "{} init {} got an {} but expected an int.".format(
                    self.__class__.__name__, interval,
                    type(locals()[interval]))
            )
            setattr(self, "_{}".format(interval), locals()[interval])

        # Validate and setup the positional args (queues).
        for qname in ("queue", "errq", "previousq", "nextq"):
            if locals()[qname] is not None:  # None is start or end
                assert isinstance(locals()[qname], str), (
                    "{} init {} got an {} but expected a str".format(
                        self.__class__.__name__, qname, locals()[qname])
                )
                setattr(
                    self, "_{}".format(qname),
                    get_named_queue_from_settings(locals()[qname], settings))
            else:
                setattr(self, "_{}".format(qname), None)

        # Validate settings are a dict.
        assert isinstance(settings, dict), (
            "{} init settings got a {} but wanted a str".format(
                self.__class__.__name__, type(settings))
        )
        self._settings = settings
        self._jobs = get_jobdb_table_from_settings(RegistryShim(settings))

    def handle(self, task, *args, **kw):
        """Handle the ``avail.job.Job`` task(s) from a queue message.

        Both job id and state are defined in the message from the incoming
        queue.
        """
        raise NotImplementedError("To be implemented by subclasses.")

    def handle_error(self, task, *args, **kw):
        """Send msg to error queue, remove from current one, set error flag."""
        attrs = {}
        attrs = {
            "last_message_id": task.msg.message_id,
            "last_receipt_handle": task.msg.receipt_handle,
        }
        if task.job:
            # We can have an empty job, but can't have an empty string attr
            # on an SQS messagq
            attrs["job_id"] = task.job.id
        # TODO: Use a waiter to ensure placement in error queue
        if not self._errq:
            raise RuntimeError("self._errq is None, so can't handle error")
        # Send a message to the ErroredQueue. Set it to delay 5 seconds to avoid
        # race conditions where a ErroredWorker picks up the message before its
        # error attr is updated to True.
        resp = self._send_message(self._errq, string_attrs=attrs, delay_seconds=5)
        new_msg_id = resp.get('MessageId')
        if not new_msg_id:
            error_msg = 'Error sending a copy of msgid={} to the ErroredQueue'.format(
                task.msg.message_id)
            self.log.error(error_msg)
            # The handoff to the error handler has failed; raise.
            raise RuntimeError(error_msg)
        self.log.info('Placed copy msgid={} in the ErroredQueue for errored jobid={}'.format(
            new_msg_id, task.job.id))
        if task.job:
            try:
                task.job.error = True
            except (AVAILDatabaseWriteError, ClientError, ):
                error_msg = 'Error setting error=True for jobid={}.'.format(task.job.id)
                self.log.error(error_msg)
                # If the JobDB couldn't be updated then this error won't be handled correctly
                # downstream, so raise again.
                raise RuntimeError(error_msg)
        # Delete this message from its original queue, since a copy has been sent to the
        # ErroredQueue.
        task.msg.delete()
        self.log.info('Deleted original msgid={} for errored jobid={}'.format(
            task.msg.message_id, task.job.id))

    @property
    def jobs(self):
        """Return the job db handle."""
        return self._jobs

    @property
    def log(self):
        """Return the logger."""
        # This is stupid, just set self.log = logger in __init__()
        return self._logger

    def poll(self):
        """Return a message from the queue if there is one.

        Return the message and the job as an
        :class:`avail_pipeline.task.SegmentTask`. Update the `poll_interval` to
        0 if we had an item or increase by backoff until it is at
        `max_poll_interval`.

        :rtype: ``avail_pipeline.task.SegmentTask``
        :return: A container class composed of an ``avail.job.Job`` and a
            ``boto3.resource.sqs.Message``
        """
        msgs = self._queue.receive_messages(
            AttributeNames=["All"],        # get ApproximateFirstReciveTimeStamp, SentTimeStamp
            MessageAttributeNames=["All"],
            VisibilityTimeout=self._visibility_timeout,
            WaitTimeSeconds=self._wait_time_seconds)

        # uploadedworker seems to stop polling the queue after a while??
        # self.log.debug("poll found number of msgs={}".format(len(msgs)))

        if msgs:
            m = msgs[0]
            self.log.debug("Got sqsid={} sqstime={} sqscount={} with message "
                           "attributes: {} and body {}".format(
                               m.message_id,
                               m.attributes['SentTimestamp'],
                               m.attributes['ApproximateReceiveCount'],
                               m.message_attributes,
                               m.body))
            job = self._get_job(m)
            # The message was read without an error; reset the poll interval.
            self._poll_interval = 0
            # If there's no Job, bail.
            if not job:
                return None
            # If there is a Job, return a Task containing it.
            return SegmentTask(m, job)
        else:
            if self._poll_interval < self._max_poll_interval:
                self._poll_interval = self._poll_interval + self._backoff_poll_interval
            self.log.debug("queue={} no messages; waiting pollinterval={} seconds".format(
                os.path.basename(self._queue.url), self._poll_interval))

    def _get_job(self, msg):
        # Gets the job by job id if it is a message attribute.
        if msg.message_attributes:
            job_id = msg.message_attributes.get('job_id', {}).get('StringValue', None)
            # If there was no Job ID, don't query Dynamo for a Job.
            if not job_id:
                log_msg = 'Received msg msgid={}, attrs={}, body={}, but ' \
                    'not the associated job'.format(
                        msg.message_id, msg.message_attributes, msg.body)
                self.log.warn(log_msg)
                # This message doesn't have enough information and cannot be acted upon; delete
                # it.
                msg.delete()
                return None
            self.log.debug('Found jobid={} in the msgattrs={} of msgid={}'.format(
                job_id, msg.message_attributes, msg.message_id))
            try:
                job = self._jobs.by_id(job_id)
            except (AVAILDatabaseReadError, ClientError, ):
                self.log.warn('Error querying for jobid={}.'.format(job_id))
                # Don't delete the message; it should be retried, and hopefully next time the db
                # operation will succeed.
                return None
            if job is None:
                self.log.warn('Received job=None in response to query for jobid={}'.format(
                    job_id))
                # This message doesn't have enough information and cannot be acted upon; delete
                # it.
                msg.delete()
                return None
            self.log.debug('Received jobid={} in state={} for msgid={}.'.format(
                job.id, job.state, msg.message_id))
        else:
            # Otherwise try to get it from the json body in an s3 notification.
            job = self._get_job_from_json_msg_body(msg)
        return job

    def _get_job_from_json_msg_body(self, msg):
        try:
            msgjson = json.loads(msg.body)
            if len(msgjson.get("Records", [])) != 1:
                err_msg = "len(Records) !=1 for S3 SQS notification msgid={}: \
                        msgbody={}".format(msg.message_id, msg.body)
                self.log.warn(err_msg)
                # This message is ambiguous and cannot be acted upon; delete it.
                msg.delete()
                return None
        except ValueError as e:
            err_msg = ("The body of msgid={} was not valid JSON: {}".format(
                msg.message_id, msg.body))
            self.log.warn(err_msg)
            # This message doesn't have enough information and cannot be acted upon; delete it.
            msg.delete()
            return None
        record = msgjson["Records"][0]
        # Get the asset path to pluck the prefixed job.id from.
        asset_path = record.get("s3", {}).get("object", {}).get("key", None)
        if asset_path is None or len(asset_path) == 0:
            err_msg = 'No assetpath in S3 SQS notification msgid={}: msgbody={}'.format(
                msg.message_id, msg.body)
            self.log.warn(err_msg)
            # This message doesn't have enough information and cannot be acted upon; delete it.
            msg.delete()
            return None
        self.log.debug('Found assetpath={} in msgid={}'.format(asset_path, msg.message_id))
        if "/OUT/" in asset_path:
            # This is not a problem; it will happen when transcoded or non-media objects
            # generate an SNS notification, or if a media object with NASAID="OUT.ext" is
            # uplaoded. Either way, delete the message.
            log_msg = ('assetpath={} in S3 SQS notification msgid={} is not an original media '
                       'file. Ignoring and deleting from queue={}'.format(
                           msg.message_id, asset_path, self._queue.attributes["QueueArn"]))
            self.log.debug(log_msg)
            msg.delete()
            return None
        job_id = asset_path.split('/')[0]
        self.log.debug('Got jobid={} from assetpath={} in msgid={}'.format(
            job_id, asset_path, msg.message_id))
        try:
            job = self._jobs.by_id(job_id)
        except ValueError as e:
            # TODO: Nuke.
            # Raised as a side-effect of Job._set_path_parts, called by
            # Job.__init__.
            self.log.critical("Couldn't parse body as JSON in msgid={}. Body: {}"
                              " Error: {}".format(msg.message_id, msg.body, e))
            self.handle_error(SegmentTask(msg, None))
            return None
        except (AVAILDatabaseReadError, ClientError, ):
            self.log.warn('Error querying for jobid={}.'.format(job_id))
            # Don't delete the message; it should be retried, and hopefully next time the db
            # operation will succeed.
            return None
        if job is None:
            self.log.warn('Received job=None in response to query for jobid={}'.format(job_id))
            # This message doesn't have enough information and cannot be acted upon; delete it.
            msg.delete()
        else:
            self.log.debug('Received jobid={} in state={} for msgid={}.'.format(
                job.id, job.state, msg.message_id))
        return job

    def _fname_from_asset_path(self, key):
        assert "/" in key, "{} isn't a valid AVAIL key".format(key)
        infixed = key.split("/")[-1]
        filename = infixed.replace("~orig", "")
        return filename

    @property
    def poll_interval(self):
        """The interval between queue polls."""
        return self._poll_interval

    def run(self):  # pragma: no cover
        """Run this Worker continuously."""
        while True:
            if self.poll_interval:
                sleep(self.poll_interval)
            segment_task = self.poll()
            if segment_task:
                if not segment_task.job.error:
                    self.handle(segment_task)
                else:
                    self.handle_error(segment_task)

    # TODO: Add a _make_message method & make _send_message use it so we can
    # get use _make_message in unit tests to check the contents of what we're
    # sending to SQS.
    def _send_message(self, queue,
                      message_body="'{}'",
                      string_attrs={},
                      delay_seconds=0):
        if not queue:
            raise RuntimeError("queue cannot be empty")
        assert message_body or string_attrs, ("A message body or message"
                                              "attributes must be defined")
        attrs = {}
        for k, v in string_attrs.items():
            attrs[k] = {"StringValue": v, "DataType": "String"}
        return queue.send_message(MessageBody=message_body,
                                  MessageAttributes=attrs,
                                  DelaySeconds=delay_seconds)

    def _delete_message(self, queue, message_id, receipt_handle):
        return queue.delete_messages(
            Entries=[{"Id": message_id,
                      "ReceiptHandle": receipt_handle}])
